package Foo::Bar;
use base qw(Foo);

1;

