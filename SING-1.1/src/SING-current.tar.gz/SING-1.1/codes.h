/******************************************************/
/* Codes of ICMP error types.                         */
/******************************************************/
/* $Id: codes.h,v 1.1.1.1 2000/06/19 09:08:07 slay Exp $ */
/******************************************************/

#ifndef __CODES_H__
#define __CODES_H__

/******************/
/* Redirect codes */
/******************/
char *cod_redirect[]={ "net",
                       "host",
                       "serv-net",
                       "serv-host",
                       "max"
                     };

/***********************/
/* Time Exceeded codes */
/***********************/
char *cod_time[]={ "ttl",
                   "frag",
                   "max"
                 };

/****************************/
/* Time Exceeded long codes */
/****************************/
char *long_cod_time[]={"Time To Live Exceeded",
                       "Reassembly Time Exceeded",
                       "max"
                      };

/*****************************/
/* Destination Unreach codes */
/*****************************/                                      
char *cod_unreach[]={ "net-unreach",
                      "host-unreach",
                      "prot-unreach",
                      "port-unreach",
                      "frag-needed",
                      "sroute-fail",
                      "net-unknown",
                      "host-unknown",
                      "host-isolated",
                      "net-ano",
                      "host-ano",
                      "net-unr-tos", 
                      "host-unr-tos", 
                      "com-admin-prohib",
                      "host-precedence-viol",
                      "precedence-cutoff",
                      "max"
                    };

#endif