/**********************************************/
/* This is only the help part of the program. */
/* See the man page for further details.      */
/**********************************************/
#ifndef lint
static const char rcsid[] = 
       "$Id: help.c,v 1.10 2001/02/08 08:45:00 slay Exp $";
#endif

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdio.h>

void
help(void)
{
  printf("\nUsage: %s [-RnvqQOGBU] [-c count] [-T wait] [-p pattern] [-s garbagesize]\n", PACKAGE);
  printf("       [-t ttl] [-TOS tos] [-F bytes] [-i interface] [-S spoof addr] [-L file]\n");
  printf("       [-MAC hw_addr] [type] host\n");
  printf("Type:\n");
  printf("  -echo    Echo Request (default).   -reply  Echo Reply\n");
  printf("  -du      Destination Unreach.      -info   Information Request\n");
  printf("  -mask    Address Mask Request.     -param  Parameter Problem\n");
  printf("  -rta     Router Advertisement      -rts    Router Solicitation\n");
  printf("  -red     Redirect                  -sq     Source Quench\n"); 
  printf("  -tstamp  Timestamp                 -tx     Time Exceeded\n");
  printf("  -h       This help screen          -V      Program version\n");
  printf("  -v       Verbose mode on\n\n");
  printf("Host:\n");
  printf("   host                          Sending to a host.\n");
  printf("   router1%%router2%%router3%%host  Sending with Strict Source Routing.\n");
  printf("   router1@router2@router3@host  Sending with Loose Source Routing.\n\n");
  printf("Please, see the man page for a full list of options and many examples.\n");  
  printf("Send your bugs & suggestions to Alfredo Andres, Slay <aandres@s21sec.com>\n\n");  
  exit(0);
} 
