/***********************************************************/
/* Network device structure.                               */
/***********************************************************/
/* $Id: dev_struct.h,v 1.1.1.1 2000/06/19 09:08:10 slay Exp $ */
/***********************************************************/
#ifndef __DEV_STRUCT_H__
#define __DEV_STRUCT_H__

#ifndef IFNAMSIZ
#define IFNAMSIZ 16
#endif

struct mi_ifaz {  char   name[IFNAMSIZ]; /* Iface name */
                  short  flags;         /* Iface flags */
                  int    mtu;           /* Iface mtu   */
                  struct sockaddr ip;   /* IP address  */
               };

#ifdef LINUX
#define LOOPB "lo"
#else
#define LOOPB "lo0"
#endif

#endif