/* $Id: misc.h,v 1.1.1.1 2000/06/19 09:08:14 slay Exp $ */

#ifndef __MISC_H__
#define __MISC_H__

#define copymem( s, d, l)  memcpy( d, s, l)
#define initmem( d, l)  memset( d, 0, l)

#ifndef MAX_C
#define MAX_C(x)  ( sizeof(x)/sizeof(x[0]) )
#endif

#ifdef HVE_SOCKADDR_LEN
#ifndef MAX
#define MAX(x,y) ( ((x) > (y)) ? (x) : (y) )
#endif
#endif

#endif
