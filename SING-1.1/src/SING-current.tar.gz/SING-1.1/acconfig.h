/* Linux system */
#undef LINUX
#undef LINUX_20
#undef LINUX_21
#undef LINUX_22
#undef LINUX_24

/* Solaris system */
#undef SOLARIS

#undef SOLARIS_251
#undef SOLARIS_26
#undef SOLARIS_27

/* FreeBSD system */
#undef FREEBSD

/* NetBSD system */
#undef NETBSD

/* OpenBSD system */
#undef OPENBSD

/* OS has strange BSD byte */
#undef STRANGE_BSD_BYTE

/* Can do IP fragments */
#undef CAN_FRAGMENT

/* Package */
#undef PACKAGE

/* Program version */
#undef VERSION

/* Struct ip */
#undef HAVE_STRUCT_IP

/* Struct ip has ip_csum field */
#undef HAVE_IP_IP_CSUM

/* Struct ip has ip_sum field */
#undef HAVE_IP_IP_SUM

/* Struct sockaddr has sa_len field */
#undef HAVE_SOCKADDR_SA_LEN

/* Define if you have the getopt_long_only function */
#undef HAVE_GETOPTLONGONLY