/*******************************/
/* Program date and disclaimer */
/*******************************/
#ifndef lint
static const char rcsid[] = 
       "$Id: vers_date.c,v 1.20 2001/04/18 07:43:29 slay Exp $";
#endif

  char *vers_date = "by Alfredo Andres (Slay), 2001/04/18";

  char *disclaimer = "  Copyright (C) 1999, 2000, 2001 Alfredo Andres (Slay) <aandres@s21sec.com>\n\
  GNU SING comes with NO WARRANTY, to the extent permitted by law.\n\
  You may redistribute copies of GNU SING under the terms of the\n\
  GNU General Public License.\n\
  For more information about these matters, see the files named COPYING.\n";
