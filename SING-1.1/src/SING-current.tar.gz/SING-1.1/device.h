/* $Id: device.h,v 1.2 2001/04/16 15:47:00 slay Exp $ */

#ifndef __DEVICE_H__
#define __DEVICE_H__

#include "misc.h"
#include "packet.h"
#include "dev_struct.h"

#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN 64
#endif

#define MAX_IFCONF  20000

#ifdef SOLARIS
extern char *sys_errlist[];
#endif

extern struct my_pack packet;

/****************************/
/* Functions prototypes ... */
/****************************/
int get_iface_out( struct sockaddr_in *, struct sockaddr_in * );
int put_interface( int, char *, struct mi_ifaz * );
int look4dev( struct mi_ifaz * );
int first_nonloopback( struct mi_ifaz * );
void where2route( struct sockaddr_in * );

extern char *pasa( struct sockaddr_in * );
extern void go_out( short int, char *, ...);

#ifdef SOLARIS
extern int gethostname( char *, int );
#endif

/*******************************/
/* ...end functions prototypes */
/*******************************/


#endif
