/*
  secure_random.h - interface for secure random number generator
  (c) 2004 Zeljko Vrba <zvrba@globalnet.hr>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifndef SECURE_RANDOM_H__
#define SECURE_RANDOM_H__

/**
	@file
	This file defines the SRNG interface.
*/

/** Opaque structure used to hold secure random generator state. */
struct SRNG_st;

/**
	Initialize the secure random number generator.
	@return	Pointer to random state on success.

	An exception is thrown on error.
*/
struct SRNG_st *SRNG_init(void);

/**
	Obtain \e n bytes of randomness from the generator.

	@param	st		Pointer to generator state.
	@param	buf		Buffer to store random bytes.
	@param	n		Number of random bytes to retrieve.

	An exception is thrown on error.
*/
void SRNG_bytes(
	struct SRNG_st *st,
	void *buf,
	unsigned int n);

/** Free the RNG state. \e st is pointer returned by SRNG_init().  */
void SRNG_free(struct SRNG_st *st);

#endif	/* SECURE_RANDOM_H__ */
