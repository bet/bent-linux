/*
  secure_random_openssl.c - secure random number generator using OpenSSL
  (c) 2004 Zeljko Vrba <zvrba@globalnet.hr>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#include <stdlib.h>
#include <string.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/blowfish.h>
#include "xalloc.h"
#include "exceptions.h"

static char rcsid[] = "$Id: secure_random_openssl.c,v 1.6 2004/12/12 08:21:56 zvrba Exp $";

/*
	This implementation uses the Blowfish cipher and low-level interfaces
	usable both in SSLEay and OpenSSL (the latter is interesting in porting
	to e.g. PalmOS).
*/

/* Blowfish parameters. */
#define	KEY_SIZE	16	/* 128-bit key size */
#define BLOCK_SIZE	8	/* 64-bit block size */

struct SRNG_st {
	BF_KEY key;
	unsigned char rnd[2*BLOCK_SIZE];
	unsigned int idx;
};

struct SRNG_st *SRNG_init(void)
{
	struct SRNG_st *st = xalloc(sizeof(*st));
	unsigned char keydata[KEY_SIZE];

	if(!st) return NULL;

	/* XXX: return value added only since OpenSSL 0.9.5 */
	if(!RAND_bytes(keydata, sizeof(keydata))
	|| !RAND_bytes(st->rnd, sizeof(st->rnd))) {
		free(st);
		Throw(lib_openssl_exception);
	}

	BF_set_key(&st->key, sizeof(keydata), keydata);
	memset(keydata, 0, sizeof(keydata));
	st->idx = 0;
	return st;
}

void SRNG_bytes(
	struct SRNG_st *st,
	void *buf,
	unsigned int n)
{
	unsigned char *out = buf, *src, *dst;

	while(1) {
		src = st->rnd + st->idx;
		dst = st->rnd + (BLOCK_SIZE - st->idx);
		st->idx = BLOCK_SIZE - st->idx;

		BF_ecb_encrypt(src, dst, &st->key, BF_ENCRYPT);

		if(n < BLOCK_SIZE) {
			memcpy(out, dst, n);
			break;
		}

		memcpy(out, dst, BLOCK_SIZE);
		n -= BLOCK_SIZE; out += BLOCK_SIZE;
	}
}

void SRNG_free(struct SRNG_st *st)
{
	memset(st, 0, sizeof(*st));
	free(st);
}

