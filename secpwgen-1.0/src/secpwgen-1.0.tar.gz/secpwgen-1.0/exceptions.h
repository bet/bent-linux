/*
  exceptions.h - exception declarations for cexcept.h
  (c) 2004 Zeljko Vrba <zvrba@globalnet.hr>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#ifndef EXCEPTIONS_H__
#define EXCEPTIONS_H__

#include "cexcept.h"

/* The simplest approach is to have all exceptions defined in one place. */
enum exception_code {
	/* general exceptions */
	no_exception = 0,	/* used to exit the Try block */
	out_of_memory_exception,
	system_call_failed_exception,
	
	/* library exceptions */
	lib_openssl_exception
};

define_exception_type(enum exception_code);
extern struct exception_context *the_exception_context;

#endif	/* EXCEPTIONS_H__ */
