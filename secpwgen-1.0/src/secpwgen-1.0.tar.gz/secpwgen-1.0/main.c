/*
  main.c - main program
  (c) 2004 Zeljko Vrba <zvrba@globalnet.hr>

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/evp.h>
#include "secure_random.h"
#include "xalloc.h"
#include "exceptions.h"

static char rcsid[] = "$Id: main.c,v 1.17 2004/12/12 08:21:56 zvrba Exp $";
static struct exception_context exception_context;
struct exception_context *the_exception_context = &exception_context;

/******************************************************************************
 * Tables and entropy constants.
 *****************************************************************************/
enum characters {
	chr_alphanumeric = 1,
	chr_dec_digits = 2,
	chr_hex_digits = 4,
	chr_special = 8,
	chr_syllables = 16
};

static const char *t_alphanumeric[36] = {
	"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L",
	"M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X",
	"Y", "Z", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"
};

static const char *t_dec_digits[36] = {
	"0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
	"0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
	"0", "1", "2", "3", "4", "5", "6", "7", "8", "9",
	NULL, NULL, NULL, NULL, NULL, NULL
};

static const char *t_hex_digits[36] = {
	"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F",
	"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F",
	NULL, NULL, NULL, NULL
};

static const char *t_special[36] = {
	"!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "_",
	"+", "=", "[", "]", "{", "}", ";", ":", "'", "\"", ",", ".",
	"<", ">", "/", "?", "`", "~", "|", "\\", "--", "==", "..", "//"
};

static const char *t_syllables_lm[36] = {
	"B", "C", "D", "F", "G", "H",
	"J", "K", "L", "M", "N", "P",
	"QU", "R", "S", "T", "V", "W",
	"X", "Z", "CH", "CR", "FR", "ND",
	"NG", "NK", "NT", "PH", "PR", "RD",
	"SH", "SL", "SP", "ST", "TH", "TR"
};

static const char *t_syllables_r[6] = {
	"A", "E", "I", "O", "U", "Y"
};

#define	N_CHARACTER_CLASSES 5
static struct {
	enum characters chr;	/* character class */
	const char **dice12;	/* first two dice throws */
	const char **dice3;		/* possibly 3rd dice or NULL */
	float entropy;			/* entropy per element */
} character_classes[N_CHARACTER_CLASSES] = {
	{ chr_alphanumeric, t_alphanumeric, NULL, 5.17 },
	{ chr_dec_digits, t_dec_digits, NULL, 3.32 },
	{ chr_hex_digits, t_hex_digits, NULL, 4 },
	{ chr_special, t_special, NULL, 5.17 },
	{ chr_syllables, t_syllables_lm, t_syllables_r, 7.75 }
};

/* This is ONLY for passphrase enhancement. */
static const char t_passphrase_enh[36] = {
	'!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_',
	'+', '=', '[', ']', '{', '}', ';', ':', '\'', '\'', ',', '.',
	'<', '>', '/', '?', '`', '~', '|', '\\', 'U', 'O', 'E', 'Y'
};

/******************************************************************************
 * Methods for password generation.
 *****************************************************************************/

/* generate and ordinary or enhanced passphrase of n words */
static int gen_passphrase(
	struct SRNG_st *st,
	unsigned int n,
	int enhanced,
	const char *(*getwd)(unsigned int),
	unsigned int dict_size)
{
	const char *wd;
	char *buf = xalloc(1);
	unsigned int i, r, wl, idx = 0;
	float entropy = 0;

	*buf = 0;
	for(i = 0; i < n; i++) {
		SRNG_bytes(st, &r, sizeof(r));
		wd = getwd(r); wl = strlen(wd);
		buf = xrealloc(buf, idx + wl + 4);
		sprintf(buf + idx, "%s ", wd);
		entropy += log(dict_size) / log(2);
		
		if(enhanced) {
			unsigned int pos;

			/* add a random symbol at random position into each word */
			SRNG_bytes(st, &pos, sizeof(pos)); pos %= wl;
			SRNG_bytes(st, &r, sizeof(r)); r %= 36;
			buf[idx+pos] = t_passphrase_enh[r];

			/* 5.17 = log2(36) for each symbol */
			entropy += 5.17 + log(wl) / log(2);
		}
		idx += wl+1;
	}

	printf("%s\nENTROPY: %.2f bits\n", buf, entropy);

	xfree(buf);
	return 0;
}

/* generate raw passphrase of n bits and output base-64 encoded */
static int gen_raw(struct SRNG_st *st, unsigned int n)
{
	BIO *bio, *b64;
	unsigned char *buf;
	
	if(n&7) {
		fprintf(stderr, "ERROR: N must be a multiple of 8.\n");
		return 1;
	}
	n >>= 3;
	
	buf = xalloc(n);
	SRNG_bytes(st, buf, n);

	if(!(b64 = BIO_new(BIO_f_base64()))
	|| !(bio = BIO_push(b64, BIO_new_fp(stdout, BIO_NOCLOSE))))
		Throw(lib_openssl_exception);
	BIO_write(bio, buf, n);
	BIO_flush(bio);
	BIO_free_all(bio);

	printf("ENTROPY: %.2f bits\n", (float)(n<<3));

	xfree(buf);
	return 0;
}

static int gen_ascii(
	struct SRNG_st *st,
	unsigned int n,
	unsigned int characters)
{
	unsigned int i, r, d[2];
	char *buf;
	float entropy = 0;

	/* syllables are at most 3 chars long */
	buf = xalloc(3*n+1);
	buf[0] = 0;

	for(i = 0; i < n; i++) {
retry:
		/*
			randomly select the character class from selected classes. note
			that this is NOT a LCG so taking % is OK.
		*/
		do {
			SRNG_bytes(st, &r, sizeof(r));
			r %= N_CHARACTER_CLASSES;
		} while(!(characters & character_classes[r].chr));

		/* now "throw 3 dice" */
		SRNG_bytes(st, d+0, sizeof(*d)); d[0] %= 36;	/* 1st and 2nd dice */
		SRNG_bytes(st, d+1, sizeof(*d)); d[1] %= 6;		/* 3rd dice */
		
		/*
			yeah, I know strcat() in a loop has quadratic performance, but
			here I just don't care...
		*/
		if(character_classes[r].dice12[d[0]]) {
			strcat(buf, character_classes[r].dice12[d[0]]);
			if(!character_classes[r].dice3)
				entropy += character_classes[r].entropy;
		} else
			goto retry;

		if(character_classes[r].dice3) {
			if(character_classes[r].dice3[d[1]]) {
				strcat(buf, character_classes[r].dice3[d[1]]);
				entropy += character_classes[r].entropy;
			} else {
				goto retry;
			}
		}
	}
	
	printf("%s\nENTROPY: %.2f bits\n", buf, entropy);

	xfree(buf);
	return 0;
}

/******************************************************************************
 * Option processing and main program.
 *****************************************************************************/
static void usage(const char *argv0)
{
	fprintf(stderr, "USAGE: %s <-p[e] | -A[adhsyn] | -r | -s[e]> N\n", argv0);
	fprintf(stderr,
	    "\nPASSPHRASE of N words from Diceware dictionary\n"
		"  -p    generate passphrase\n"
		"  -pe   generate enhanced (with symbols) passphrase\n"
		"\nSKEY PASSWORD of N words from S/Key dictionary\n"
		"  -s    generate passphrase\n"
		"  -se   generate enhanced (with symbols) passphrase\n"
		"\nASCII RANDOM of N elements (at least one option MUST be present)\n"
		"  -A    Each letter adds the following random elements in output:\n"
	    "    a    alphanumeric characters\n"
		"    d    decimal digits\n"
		"    h    hexadecimal digits\n"
		"    s    special characters\n"
		"    y    3-4 letter syllables\n"
		"\nRAW RANDOM\n"
		"  -r    output BASE64 encoded string of N random BITS\n");
	exit(1);
}

int main(int argc, char **argv)
{
	const char *getDiceWd(unsigned int);
	const char *getSkeyWd(unsigned int);
	unsigned int n;
	struct SRNG_st *st;
	int retval;
	enum exception_code exception;

	if(argc != 3)
		usage(argv[0]);

	n = atoi(argv[2]);
	if(n < 1) {
		fprintf(stderr, "ERROR: N must be an integer > 0\n");
		usage(argv[0]);
	}

	Try {
		st = SRNG_init();

		if(!strcmp(argv[1], "-p"))
			retval = gen_passphrase(st, n, 0, getDiceWd, 8192);
		else if(!strcmp(argv[1], "-pe"))
			retval = gen_passphrase(st, n, 1, getDiceWd, 8192);
		else if(!strcmp(argv[1], "-r"))
			retval = gen_raw(st, n);
		else if(!strcmp(argv[1], "-s"))
			retval = gen_passphrase(st, n, 0, getSkeyWd, 2048);
		else if(!strcmp(argv[1], "-se"))
			retval = gen_passphrase(st, n, 1, getSkeyWd, 2048);
		else if(!strncmp(argv[1], "-A", 2)) {
			unsigned int characters = 0;
			char *p;

			for(p = argv[1]+2; *p; p++)
				switch(*p) {
				case 'a':
					characters |= chr_alphanumeric;
					break;
				case 'd':
					characters |= chr_dec_digits;
					break;
				case 'h':
					characters |= chr_hex_digits;
					break;
				case 's':
					characters |= chr_special;
					break;
				case 'y':
					characters |= chr_syllables;
					break;
				default:
					usage(argv[0]);
				}
				
			/* filter out some combinations for correct entropy estimation */
			if(characters & chr_alphanumeric)
				characters &= ~(chr_dec_digits | chr_hex_digits);
			if(characters & chr_hex_digits)
				characters &= ~chr_dec_digits;
			if((characters & chr_syllables)
			&& (characters & (chr_alphanumeric | chr_dec_digits | chr_hex_digits))) {
				characters &= ~(chr_alphanumeric | chr_dec_digits | chr_hex_digits);
				characters |= chr_dec_digits;
			}
			if(!characters)
				usage(argv[0]);
			retval = gen_ascii(st, n, characters);
		} else
			usage(argv[0]);
	} Catch(exception) {
		switch(exception) {
		case out_of_memory_exception:
			fprintf(stderr, "FATAL: out of memory\n");
			retval = 2;
			break;
		case lib_openssl_exception:
			ERR_print_errors_fp(stderr);
			retval = 2;
			break;
		default:
			fprintf(stderr, "FATAL: unhandled exception %u\n", exception);
			abort();
		}
	}

	return retval;
}
