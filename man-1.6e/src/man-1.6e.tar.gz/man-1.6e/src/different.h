int different_cat_file (const char *file);
int different_man_file (const char *file);
