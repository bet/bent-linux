/* version.h   */

#ifndef VERSION_H
#define VERSION_H
			/* retail */
#define VERSION_MAJOR 22
#define VERSION_MINOR 5
#define VERSION_EDIT  ".7.2"
#define VERSION_DATE "20-Aug-2003"

#endif
