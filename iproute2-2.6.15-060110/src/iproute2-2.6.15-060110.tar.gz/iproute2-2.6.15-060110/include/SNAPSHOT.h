static char SNAPSHOT[] = "060110";
