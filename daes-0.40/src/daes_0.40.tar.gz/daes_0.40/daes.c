#include <stdio.h>
#include <stdlib.h>
int keylength_nk[]={4,6,8};
int blocksize_nb[]={4,4,4};
int numberofrounds_nr[]={10,12,14};
typedef enum 
{
	MODE_128=0,
	MODE_192,
	MODE_256
} aesmode;
unsigned char w[60][4];
unsigned char SubByte[]={0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x1,0x67,0x2b,0xfe,0xd7,0xab,0x76,0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,0x4,0xc7,0x23,0xc3,0x18,0x96,0x5,0x9a,0x7,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,0x9,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,0x53,0xd1,0x0,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x2,0x7f,0x50,0x3c,0x9f,0xa8,0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,0xcd,0xc,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0xb,0xdb,0xe0,0x32,0x3a,0xa,0x49,0x6,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x8,0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,0x70,0x3e,0xb5,0x66,0x48,0x3,0xf6,0xe,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,0x8c,0xa1,0x89,0xd,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0xf,0xb0,0x54,0xbb,0x16};
unsigned char InvSubByte[]={0x52,0x9,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb,0x7c,0xe3,0x39,0x82,0x9b,0x2f,0xff,0x87,0x34,0x8e,0x43,0x44,0xc4,0xde,0xe9,0xcb,0x54,0x7b,0x94,0x32,0xa6,0xc2,0x23,0x3d,0xee,0x4c,0x95,0xb,0x42,0xfa,0xc3,0x4e,0x8,0x2e,0xa1,0x66,0x28,0xd9,0x24,0xb2,0x76,0x5b,0xa2,0x49,0x6d,0x8b,0xd1,0x25,0x72,0xf8,0xf6,0x64,0x86,0x68,0x98,0x16,0xd4,0xa4,0x5c,0xcc,0x5d,0x65,0xb6,0x92,0x6c,0x70,0x48,0x50,0xfd,0xed,0xb9,0xda,0x5e,0x15,0x46,0x57,0xa7,0x8d,0x9d,0x84,0x90,0xd8,0xab,0x0,0x8c,0xbc,0xd3,0xa,0xf7,0xe4,0x58,0x5,0xb8,0xb3,0x45,0x6,0xd0,0x2c,0x1e,0x8f,0xca,0x3f,0xf,0x2,0xc1,0xaf,0xbd,0x3,0x1,0x13,0x8a,0x6b,0x3a,0x91,0x11,0x41,0x4f,0x67,0xdc,0xea,0x97,0xf2,0xcf,0xce,0xf0,0xb4,0xe6,0x73,0x96,0xac,0x74,0x22,0xe7,0xad,0x35,0x85,0xe2,0xf9,0x37,0xe8,0x1c,0x75,0xdf,0x6e,0x47,0xf1,0x1a,0x71,0x1d,0x29,0xc5,0x89,0x6f,0xb7,0x62,0xe,0xaa,0x18,0xbe,0x1b,0xfc,0x56,0x3e,0x4b,0xc6,0xd2,0x79,0x20,0x9a,0xdb,0xc0,0xfe,0x78,0xcd,0x5a,0xf4,0x1f,0xdd,0xa8,0x33,0x88,0x7,0xc7,0x31,0xb1,0x12,0x10,0x59,0x27,0x80,0xec,0x5f,0x60,0x51,0x7f,0xa9,0x19,0xb5,0x4a,0xd,0x2d,0xe5,0x7a,0x9f,0x93,0xc9,0x9c,0xef,0xa0,0xe0,0x3b,0x4d,0xae,0x2a,0xf5,0xb0,0xc8,0xeb,0xbb,0x3c,0x83,0x53,0x99,0x61,0x17,0x2b,0x4,0x7e,0xba,0x77,0xd6,0x26,0xe1,0x69,0x14,0x63,0x55,0x21,0xc,0x7d};
int iteratekey=1;
int cryptnotdecrypt=1;
unsigned char inputfilename[255];
unsigned char outputfilename[255];
unsigned char keyfilename[255];

void warte()
{
        char b[2];
        fprintf(stderr,"...Please press <Enter> to read on...");
        fgets(b,sizeof(b),stdin);
}

void print_gpl()
{
printf("		    GNU GENERAL PUBLIC LICENSE\n");
printf("		       Version 2, June 1991\n");
printf("\n");
printf(" Copyright (C) 1989, 1991 Free Software Foundation, Inc.\n");
printf("                       59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n");
printf(" Everyone is permitted to copy and distribute verbatim copies\n");
printf(" of this license document, but changing it is not allowed.\n");
printf("\n");
printf("			    Preamble\n");
printf("\n");
printf("  The licenses for most software are designed to take away your\n");
printf("freedom to share and change it.  By contrast, the GNU General Public\n");
printf("License is intended to guarantee your freedom to share and change free\n");
printf("software--to make sure the software is free for all its users.  This\n");
printf("General Public License applies to most of the Free Software\n");
printf("Foundation's software and to any other program whose authors commit to\n");
printf("using it.  (Some other Free Software Foundation software is covered by\n");
printf("the GNU Library General Public License instead.)  You can apply it to\n");
printf("your programs, too.\n");
printf("\n");
printf("  When we speak of free software, we are referring to freedom, not\n");
printf("price.  Our General Public Licenses are designed to make sure that you\n");
printf("have the freedom to distribute copies of free software (and charge for\n");
printf("this service if you wish), that you receive source code or can get it\n");
warte();
printf("if you want it, that you can change the software or use pieces of it\n");
printf("in new free programs; and that you know you can do these things.\n");
printf("\n");
printf("  To protect your rights, we need to make restrictions that forbid\n");
printf("anyone to deny you these rights or to ask you to surrender the rights.\n");
printf("These restrictions translate to certain responsibilities for you if you\n");
printf("distribute copies of the software, or if you modify it.\n");
printf("\n");
printf("  For example, if you distribute copies of such a program, whether\n");
printf("gratis or for a fee, you must give the recipients all the rights that\n");
printf("you have.  You must make sure that they, too, receive or can get the\n");
printf("source code.  And you must show them these terms so they know their\n");
printf("rights.\n");
printf("\n");
printf("  We protect your rights with two steps: (1) copyright the software, and\n");
printf("(2) offer you this license which gives you legal permission to copy,\n");
printf("distribute and/or modify the software.\n");
printf("\n");
printf("  Also, for each author's protection and ours, we want to make certain\n");
printf("that everyone understands that there is no warranty for this free\n");
printf("software.  If the software is modified by someone else and passed on, we\n");
printf("want its recipients to know that what they have is not the original, so\n");
printf("that any problems introduced by others will not reflect on the original\n");
printf("authors' reputations.\n");
warte();
printf("\n");
printf("  Finally, any free program is threatened constantly by software\n");
printf("patents.  We wish to avoid the danger that redistributors of a free\n");
printf("program will individually obtain patent licenses, in effect making the\n");
printf("program proprietary.  To prevent this, we have made it clear that any\n");
printf("patent must be licensed for everyone's free use or not licensed at all.\n");
printf("\n");
printf("  The precise terms and conditions for copying, distribution and\n");
printf("modification follow.\n");
printf("		    GNU GENERAL PUBLIC LICENSE\n");
printf("   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n");
printf("\n");
printf("  0. This License applies to any program or other work which contains\n");
printf("a notice placed by the copyright holder saying it may be distributed\n");
printf("under the terms of this General Public License.  The \"Program\", below,\n");
printf("refers to any such program or work, and a \"work based on the Program\"\n");
printf("means either the Program or any derivative work under copyright law:\n");
printf("that is to say, a work containing the Program or a portion of it,\n");
printf("either verbatim or with modifications and/or translated into another\n");
printf("language.  (Hereinafter, translation is included without limitation in\n");
printf("the term \"modification\".)  Each licensee is addressed as \"you\".\n");
printf("\n");
warte();
printf("Activities other than copying, distribution and modification are not\n");
printf("covered by this License; they are outside its scope.  The act of\n");
printf("running the Program is not restricted, and the output from the Program\n");
printf("is covered only if its contents constitute a work based on the\n");
printf("Program (independent of having been made by running the Program).\n");
printf("Whether that is true depends on what the Program does.\n");
printf("\n");
printf("  1. You may copy and distribute verbatim copies of the Program's\n");
printf("source code as you receive it, in any medium, provided that you\n");
printf("conspicuously and appropriately publish on each copy an appropriate\n");
printf("copyright notice and disclaimer of warranty; keep intact all the\n");
printf("notices that refer to this License and to the absence of any warranty;\n");
printf("and give any other recipients of the Program a copy of this License\n");
printf("along with the Program.\n");
printf("\n");
printf("You may charge a fee for the physical act of transferring a copy, and\n");
printf("you may at your option offer warranty protection in exchange for a fee.\n");
printf("\n");
printf("  2. You may modify your copy or copies of the Program or any portion\n");
printf("of it, thus forming a work based on the Program, and copy and\n");
printf("distribute such modifications or work under the terms of Section 1\n");
printf("above, provided that you also meet all of these conditions:\n");
printf("\n");
printf("    a) You must cause the modified files to carry prominent notices\n");
warte();
printf("    stating that you changed the files and the date of any change.\n");
printf("\n");
printf("    b) You must cause any work that you distribute or publish, that in\n");
printf("    whole or in part contains or is derived from the Program or any\n");
printf("    part thereof, to be licensed as a whole at no charge to all third\n");
printf("    parties under the terms of this License.\n");
printf("\n");
printf("    c) If the modified program normally reads commands interactively\n");
printf("    when run, you must cause it, when started running for such\n");
printf("    interactive use in the most ordinary way, to print or display an\n");
printf("    announcement including an appropriate copyright notice and a\n");
printf("    notice that there is no warranty (or else, saying that you provide\n");
printf("    a warranty) and that users may redistribute the program under\n");
printf("    these conditions, and telling the user how to view a copy of this\n");
printf("    License.  (Exception: if the Program itself is interactive but\n");
printf("    does not normally print such an announcement, your work based on\n");
printf("    the Program is not required to print an announcement.)\n");
printf("These requirements apply to the modified work as a whole.  If\n");
printf("identifiable sections of that work are not derived from the Program,\n");
printf("and can be reasonably considered independent and separate works in\n");
printf("themselves, then this License, and its terms, do not apply to those\n");
printf("sections when you distribute them as separate works.  But when you\n");
printf("distribute the same sections as part of a whole which is a work based\n");
printf("on the Program, the distribution of the whole must be on the terms of\n");
warte();
printf("this License, whose permissions for other licensees extend to the\n");
printf("entire whole, and thus to each and every part regardless of who wrote it.\n");
printf("\n");
printf("Thus, it is not the intent of this section to claim rights or contest\n");
printf("your rights to work written entirely by you; rather, the intent is to\n");
printf("exercise the right to control the distribution of derivative or\n");
printf("collective works based on the Program.\n");
printf("\n");
printf("In addition, mere aggregation of another work not based on the Program\n");
printf("with the Program (or with a work based on the Program) on a volume of\n");
printf("a storage or distribution medium does not bring the other work under\n");
printf("the scope of this License.\n");
printf("\n");
printf("  3. You may copy and distribute the Program (or a work based on it,\n");
printf("under Section 2) in object code or executable form under the terms of\n");
printf("Sections 1 and 2 above provided that you also do one of the following:\n");
printf("\n");
printf("    a) Accompany it with the complete corresponding machine-readable\n");
printf("    source code, which must be distributed under the terms of Sections\n");
printf("    1 and 2 above on a medium customarily used for software interchange; or,\n");
printf("\n");
printf("    b) Accompany it with a written offer, valid for at least three\n");
printf("    years, to give any third party, for a charge no more than your\n");
warte();
printf("    cost of physically performing source distribution, a complete\n");
printf("    machine-readable copy of the corresponding source code, to be\n");
printf("    distributed under the terms of Sections 1 and 2 above on a medium\n");
printf("    customarily used for software interchange; or,\n");
printf("\n");
printf("    c) Accompany it with the information you received as to the offer\n");
printf("    to distribute corresponding source code.  (This alternative is\n");
printf("    allowed only for noncommercial distribution and only if you\n");
printf("    received the program in object code or executable form with such\n");
printf("    an offer, in accord with Subsection b above.)\n");
printf("\n");
printf("The source code for a work means the preferred form of the work for\n");
printf("making modifications to it.  For an executable work, complete source\n");
printf("code means all the source code for all modules it contains, plus any\n");
printf("associated interface definition files, plus the scripts used to\n");
printf("control compilation and installation of the executable.  However, as a\n");
printf("special exception, the source code distributed need not include\n");
printf("anything that is normally distributed (in either source or binary\n");
printf("form) with the major components (compiler, kernel, and so on) of the\n");
printf("operating system on which the executable runs, unless that component\n");
printf("itself accompanies the executable.\n");
printf("\n");
printf("If distribution of executable or object code is made by offering\n");
warte();
printf("access to copy from a designated place, then offering equivalent\n");
printf("access to copy the source code from the same place counts as\n");
printf("distribution of the source code, even though third parties are not\n");
printf("compelled to copy the source along with the object code.\n");
printf("  4. You may not copy, modify, sublicense, or distribute the Program\n");
printf("except as expressly provided under this License.  Any attempt\n");
printf("otherwise to copy, modify, sublicense or distribute the Program is\n");
printf("void, and will automatically terminate your rights under this License.\n");
printf("However, parties who have received copies, or rights, from you under\n");
printf("this License will not have their licenses terminated so long as such\n");
printf("parties remain in full compliance.\n");
printf("\n");
printf("  5. You are not required to accept this License, since you have not\n");
printf("signed it.  However, nothing else grants you permission to modify or\n");
printf("distribute the Program or its derivative works.  These actions are\n");
printf("prohibited by law if you do not accept this License.  Therefore, by\n");
printf("modifying or distributing the Program (or any work based on the\n");
printf("Program), you indicate your acceptance of this License to do so, and\n");
printf("all its terms and conditions for copying, distributing or modifying\n");
printf("the Program or works based on it.\n");
printf("\n");
printf("  6. Each time you redistribute the Program (or any work based on the\n");
printf("Program), the recipient automatically receives a license from the\n");
warte();
printf("original licensor to copy, distribute or modify the Program subject to\n");
printf("these terms and conditions.  You may not impose any further\n");
printf("restrictions on the recipients' exercise of the rights granted herein.\n");
printf("You are not responsible for enforcing compliance by third parties to\n");
printf("this License.\n");
printf("\n");
printf("  7. If, as a consequence of a court judgment or allegation of patent\n");
printf("infringement or for any other reason (not limited to patent issues),\n");
printf("conditions are imposed on you (whether by court order, agreement or\n");
printf("otherwise) that contradict the conditions of this License, they do not\n");
printf("excuse you from the conditions of this License.  If you cannot\n");
printf("distribute so as to satisfy simultaneously your obligations under this\n");
printf("License and any other pertinent obligations, then as a consequence you\n");
printf("may not distribute the Program at all.  For example, if a patent\n");
printf("license would not permit royalty-free redistribution of the Program by\n");
printf("all those who receive copies directly or indirectly through you, then\n");
printf("the only way you could satisfy both it and this License would be to\n");
printf("refrain entirely from distribution of the Program.\n");
printf("\n");
printf("If any portion of this section is held invalid or unenforceable under\n");
printf("any particular circumstance, the balance of the section is intended to\n");
printf("apply and the section as a whole is intended to apply in other\n");
printf("circumstances.\n");
warte();
printf("\n");
printf("It is not the purpose of this section to induce you to infringe any\n");
printf("patents or other property right claims or to contest validity of any\n");
printf("such claims; this section has the sole purpose of protecting the\n");
printf("integrity of the free software distribution system, which is\n");
printf("implemented by public license practices.  Many people have made\n");
printf("generous contributions to the wide range of software distributed\n");
printf("through that system in reliance on consistent application of that\n");
printf("system; it is up to the author/donor to decide if he or she is willing\n");
printf("to distribute software through any other system and a licensee cannot\n");
printf("impose that choice.\n");
printf("\n");
printf("This section is intended to make thoroughly clear what is believed to\n");
printf("be a consequence of the rest of this License.\n");
printf("  8. If the distribution and/or use of the Program is restricted in\n");
printf("certain countries either by patents or by copyrighted interfaces, the\n");
printf("original copyright holder who places the Program under this License\n");
printf("may add an explicit geographical distribution limitation excluding\n");
printf("those countries, so that distribution is permitted only in or among\n");
printf("countries not thus excluded.  In such case, this License incorporates\n");
printf("the limitation as if written in the body of this License.\n");
printf("\n");
printf("  9. The Free Software Foundation may publish revised and/or new versions\n");
warte();
printf("of the General Public License from time to time.  Such new versions will\n");
printf("be similar in spirit to the present version, but may differ in detail to\n");
printf("address new problems or concerns.\n");
printf("\n");
printf("Each version is given a distinguishing version number.  If the Program\n");
printf("specifies a version number of this License which applies to it and \"any\n");
printf("later version\", you have the option of following the terms and conditions\n");
printf("either of that version or of any later version published by the Free\n");
printf("Software Foundation.  If the Program does not specify a version number of\n");
printf("this License, you may choose any version ever published by the Free Software\n");
printf("Foundation.\n");
printf("\n");
printf("  10. If you wish to incorporate parts of the Program into other free\n");
printf("programs whose distribution conditions are different, write to the author\n");
printf("to ask for permission.  For software which is copyrighted by the Free\n");
printf("Software Foundation, write to the Free Software Foundation; we sometimes\n");
printf("make exceptions for this.  Our decision will be guided by the two goals\n");
printf("of preserving the free status of all derivatives of our free software and\n");
printf("of promoting the sharing and reuse of software generally.\n");
printf("\n");
printf("			    NO WARRANTY\n");
printf("\n");
printf("  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\n");
warte();
printf("FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\n");
printf("OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\n");
printf("PROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\n");
printf("OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\n");
printf("MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\n");
printf("TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\n");
printf("PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\n");
printf("REPAIR OR CORRECTION.\n");
printf("\n");
printf("  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\n");
printf("WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\n");
printf("REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\n");
printf("INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\n");
printf("OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\n");
printf("TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\n");
printf("YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\n");
printf("PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\n");
printf("POSSIBILITY OF SUCH DAMAGES.\n");
printf("\n");
printf("		     END OF TERMS AND CONDITIONS\n");
printf("	    How to Apply These Terms to Your New Programs\n");
printf("\n");
printf("  If you develop a new program, and you want it to be of the greatest\n");
warte();
printf("possible use to the public, the best way to achieve this is to make it\n");
printf("free software which everyone can redistribute and change under these terms.\n");
printf("\n");
printf("  To do so, attach the following notices to the program.  It is safest\n");
printf("to attach them to the start of each source file to most effectively\n");
printf("convey the exclusion of warranty; and each file should have at least\n");
printf("the \"copyright\" line and a pointer to where the full notice is found.\n");
printf("\n");
printf("    <one line to give the program's name and a brief idea of what it does.>\n");
printf("    Copyright (C) <year>  <name of author>\n");
printf("\n");
printf("    This program is free software; you can redistribute it and/or modify\n");
printf("    it under the terms of the GNU General Public License as published by\n");
printf("    the Free Software Foundation; either version 2 of the License, or\n");
printf("    (at your option) any later version.\n");
printf("\n");
printf("    This program is distributed in the hope that it will be useful,\n");
printf("    but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
printf("    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
printf("    GNU General Public License for more details.\n");
printf("\n");
printf("    You should have received a copy of the GNU General Public License\n");
printf("    along with this program; if not, write to the Free Software\n");
warte();
printf("    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n");
printf("\n");
printf("\n");
printf("Also add information on how to contact you by electronic and paper mail.\n");
printf("\n");
printf("If the program is interactive, make it output a short notice like this\n");
printf("when it starts in an interactive mode:\n");
printf("\n");
printf("    Gnomovision version 69, Copyright (C) year name of author\n");
printf("    Gnomovision comes with ABSOLUTELY NO WARRANTY; for details type `show w'.\n");
printf("    This is free software, and you are welcome to redistribute it\n");
printf("    under certain conditions; type `show c' for details.\n");
printf("\n");
printf("The hypothetical commands `show w' and `show c' should show the appropriate\n");
printf("parts of the General Public License.  Of course, the commands you use may\n");
printf("be called something other than `show w' and `show c'; they could even be\n");
printf("mouse-clicks or menu items--whatever suits your program.\n");
printf("\n");
printf("You should also get your employer (if you work as a programmer) or your\n");
printf("school, if any, to sign a \"copyright disclaimer\" for the program, if\n");
printf("necessary.  Here is a sample; alter the names:\n");
printf("\n");
printf("  Yoyodyne, Inc., hereby disclaims all copyright interest in the program\n");
warte();
printf("  `Gnomovision' (which makes passes at compilers) written by James Hacker.\n");
printf("\n");
printf("  <signature of Ty Coon>, 1 April 1989\n");
printf("  Ty Coon, President of Vice\n");
printf("\n");
printf("This General Public License does not permit incorporating your program into\n");
printf("proprietary programs.  If your program is a subroutine library, you may\n");
printf("consider it more useful to permit linking proprietary applications with the\n");
printf("library.  If this is what you want to do, use the GNU Library General\n");
printf("Public License instead of this License.\n");
exit(1);
}
void ende()
{
fprintf(stderr,"This program is free software; you can redistribute it and/or modify\n");
fprintf(stderr,"it under the terms of the GNU General Public License as published by\n");
fprintf(stderr,"the Free Software Foundation; either version 2 of the License, or\n");
fprintf(stderr,"(at your option) any later version.\n");
fprintf(stderr,"\n");
fprintf(stderr,"This program is distributed in the hope that it will be useful,\n");
fprintf(stderr,"but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
fprintf(stderr,"MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
fprintf(stderr,"GNU General Public License for more details.\n");
fprintf(stderr,"\n");
fprintf(stderr,"You should have received a copy of the GNU General Public License\n");
fprintf(stderr,"along with this program; if not, write to the Free Software\n");
fprintf(stderr,"Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n");
fprintf(stderr,"\n");
}
void AddRoundKey(unsigned char* state,unsigned char* key,aesmode a)
{
	int i;
	unsigned char c;
	for (i=0;i<(blocksize_nb[a]*blocksize_nb[a]);i++)
	{
		c=state[i]^key[i];
		state[i]=c;
	}
}
void SubBytes(unsigned char* state,aesmode a)
{
	int i;
	unsigned char c;
	for (i=0;i<(blocksize_nb[a]*blocksize_nb[a]);i++)
	{
		c=SubByte[(int)state[i]];
		state[i]=c;	
	}
}
void InvSubBytes(unsigned char* state,aesmode a)
{
	int i;
	unsigned char c;
	for (i=0;i<(blocksize_nb[a]*blocksize_nb[a]);i++)
	{
		c=InvSubByte[(int)state[i]];
		state[i]=c;	
	}
}
void ShiftRows(unsigned char* state,aesmode a)
{
	int i,j;
	unsigned char c[16];
	for (i=0;i<blocksize_nb[a]*blocksize_nb[a];i++)
	{
		c[i]=state[(i+(i%4)*4)%16];
	}	
	for (i=0;i<blocksize_nb[a]*blocksize_nb[a];i++)
	{
		state[i]=c[i];
		c[i]=0xAA;
	}
}
unsigned char xtime(unsigned char c)
{
	unsigned char t;
	t=(char)(((unsigned short)c<<1)&254);
	return (c&128)?(t^0x1B):t;
}
void MixColumns(unsigned char* state,aesmode a)
{
	int i,j;
	unsigned char c[4];
	for (i=0;i<blocksize_nb[a];i++)
	{
		c[0]=state[i*4+1]^state[i*4+2]^state[i*4+3]^xtime(state[i*4+0])^xtime(state[i*4+1]);
		c[1]=state[i*4+0]^state[i*4+2]^state[i*4+3]^xtime(state[i*4+1])^xtime(state[i*4+2]);
		c[2]=state[i*4+0]^state[i*4+1]^state[i*4+3]^xtime(state[i*4+2])^xtime(state[i*4+3]);
		c[3]=state[i*4+0]^state[i*4+1]^state[i*4+2]^xtime(state[i*4+3])^xtime(state[i*4+0]);
		state[i*4+0]=c[0];
		state[i*4+1]=c[1];
		state[i*4+2]=c[2];
		state[i*4+3]=c[3];
		c[0]=0x00;
		c[1]=0x00;
		c[2]=0x00;
		c[3]=0x00;
	}	
}
void keynext(unsigned char* key,int roundnum,aesmode a)
{
	unsigned char rc[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1B,0x36,0x6C,0xD8,0xAB,0x4D,0x9A,0x2F,0x5E,0xBC,0x63,0xC6,0x97};
	unsigned char t[4];
	int i,j;
	t[0]=key[13];
	t[1]=key[14];
	t[2]=key[15];
	t[3]=key[12];
	for (i=0;i<4;i++) t[i]=SubByte[(int)t[i]];
	t[0]=t[0]^rc[roundnum];
	for (i=0;i<keylength_nk[a]*4;i++)
	{
		key[i]=t[i%4]^key[i];
		t[i%4]=key[i];
	}	
	t[0]=0;t[1]=0;t[2]=0;t[3]=0;	
}
void aescrypt(unsigned char *text,unsigned char *key,aesmode a)
{
	int i;
	unsigned char local_key[32];
	for (i=0;i<keylength_nk[a]*4;i++) local_key[i]=key[i];
	AddRoundKey(text,local_key,MODE_128);
	for (i=0;i<numberofrounds_nr[MODE_128]-1;i++)
	{
		SubBytes(text,MODE_128);
		ShiftRows(text,MODE_128);
		MixColumns(text,MODE_128);
		keynext(local_key,i,MODE_128);
		AddRoundKey(text,local_key,MODE_128);
	}
	SubBytes(text,MODE_128);
	ShiftRows(text,MODE_128);
	keynext(local_key,i,MODE_128);
	AddRoundKey(text,local_key,MODE_128);
	if (iteratekey)
	{
		for (i=0;i<keylength_nk[a]*4;i++) key[i]=local_key[i];
	}
}
void InvShiftRows(unsigned char* state,aesmode a)
{
	int i,j;
	unsigned char c[16];
	for (i=0;i<blocksize_nb[a]*blocksize_nb[a];i++)
	{
		c[i]=state[(i+(i%4)*12)%16];
	}	
	for (i=0;i<blocksize_nb[a]*blocksize_nb[a];i++)
	{
		state[i]=c[i];
		c[i]=0xAA;
	}
}
void InvMixColumns(unsigned char* state,aesmode a)
{
	int i,j;
	unsigned char b[4];
	unsigned char c[4];
	unsigned char d[4];
	unsigned char e[4];
	for (i=0;i<blocksize_nb[a];i++)
	{
		for (j=0;j<4;j++)
		{
			c[j]=xtime(state[i*4+j]);
			d[j]=xtime(c[j]);
			e[j]=xtime(d[j]);
		}
		b[0]=e[0]^d[0]^c[0]^ e[1]^c[1]^state[i*4+1]^ e[2]^d[2]^state[i*4+2]^ e[3]^state[i*4+3];
		b[1]=e[1]^d[1]^c[1]^ e[2]^c[2]^state[i*4+2]^ e[3]^d[3]^state[i*4+3]^ e[0]^state[i*4+0];
		b[2]=e[2]^d[2]^c[2]^ e[3]^c[3]^state[i*4+3]^ e[0]^d[0]^state[i*4+0]^ e[1]^state[i*4+1];
		b[3]=e[3]^d[3]^c[3]^ e[0]^c[0]^state[i*4+0]^ e[1]^d[1]^state[i*4+1]^ e[2]^state[i*4+2];
		state[i*4+0]=b[0];
		state[i*4+1]=b[1];
		state[i*4+2]=b[2];
		state[i*4+3]=b[3];
		b[0]=0x00;
		b[1]=0x00;
		b[2]=0x00;
		b[3]=0x00;
		c[0]=0x00;
		c[1]=0x00;
		c[2]=0x00;
		c[3]=0x00;
		d[0]=0x00;
		d[1]=0x00;
		d[2]=0x00;
		d[3]=0x00;
		e[0]=0x00;
		e[1]=0x00;
		e[2]=0x00;
		e[3]=0x00;
	}	
}
void aesdecrypt(unsigned char *text,unsigned char *key,aesmode a)
{
	int i,j;
	unsigned char local_key[15][32];
	unsigned char local_key2[32];
	for (i=0;i<keylength_nk[a]*4;i++) {
		local_key[0][i]=key[i];
		local_key2[i]=key[i];
	}
	for (j=1;j<=numberofrounds_nr[a];j++)
	{
		keynext(local_key2,j-1,a);
		for (i=0;i<keylength_nk[a]*4;i++) {
			local_key[j][i]=local_key2[i];
		}

	}
	AddRoundKey(text,local_key[numberofrounds_nr[a]],a);	
	InvShiftRows(text,a);
	InvSubBytes(text,a);
	for (j=numberofrounds_nr[a]-1;j>0;j--)
	{
		AddRoundKey(text,local_key[j],a);
		InvMixColumns(text,a);
		InvShiftRows(text,a);
		InvSubBytes(text,a);
	}
	AddRoundKey(text,local_key[0],a);
	if (iteratekey)
	{
		for (i=0;i<keylength_nk[a]*4;i++) key[i]=local_key[numberofrounds_nr[a]][i];
	}
}
void parsemycmdlines(int argc,char **argv)
{
	int i,j;
	int err=0;
	int param=0;
	for (i=0;i<255;i++)
	{
		inputfilename[i]=0;
		outputfilename[i]=0;
		keyfilename[i]=0;
	}
	if (argc<=1) err=1;
	else {
		for (i=1;((i<argc) && (err==0));i++)
		{
			if ((argv[i][0]=='-'))
			{
				if (argv[i][1]=='d') {
					param=0;	
					cryptnotdecrypt=0;
				} else if (argv[i][1]=='k') param=513;
				else if (argv[i][1]=='o') param=514;
				else if (argv[i][1]=='g') print_gpl();
				else err=1;
			} else {
				if ((param==513)) 
for (j=0;(j<strlen(argv[i]) && (j<255));j++) keyfilename[j]=argv[i][j]; 
				else if ((param==514)) 
for (j=0;(j<strlen(argv[i]) && (j<255));j++) outputfilename[j]=argv[i][j];	
				else for (j=0;(j<strlen(argv[i]) && (j<255));j++) inputfilename[j]=argv[i][j];
				param=0;
			}
		}
	} 
	if (!err)
	{
		if ((inputfilename[0]==0) || (keyfilename[0]==0)) err=1;
		else if (outputfilename[0]==0)
		if (cryptnotdecrypt)
		{
			i=249;
			for (j=0;((j<249) && (i==249));j++) 
			if (inputfilename[j]==0) i=j; else outputfilename[j]=inputfilename[j];
			outputfilename[i]='.';
			outputfilename[i+1]='a';
			outputfilename[i+2]='e';
			outputfilename[i+3]='s';
		} else {
			i=255;
			for (j=0;((j<255) && (i==255));j++) if (inputfilename[j]==0) i=j;
			j=0;
			if (i>=4) if (inputfilename[i-1]=='s' && inputfilename[i-2]=='e' && inputfilename[i-3]=='a' && inputfilename[i-4]=='.')	j=1;
			if (j==1)
			{
				for (j=i-5;j>=0;j--) outputfilename[j]=inputfilename[j];
			} else {
			i=249;
			for (j=0;((j<249) && (i==249));j++) 
			if (inputfilename[j]==0) i=j; else outputfilename[j]=inputfilename[j];
			outputfilename[i]='.';
			outputfilename[i+1]='d';
			outputfilename[i+2]='a';
			outputfilename[i+3]='e';
			outputfilename[i+4]='s';
	
			}
		}
	}
	if (err)
	{
		fprintf(stderr,"*** DAES 0.40\n");
		fprintf(stderr,"*** (C)opyleft 2005 by Dettus\n");
		fprintf(stderr,"*** dettus@dettus.net\n");
		fprintf(stderr,"Useage: deas [-d] -k KEYFILE [-o OUTPUTFILE] FILENAME or -gpl\n");
		exit(0);
	}
}

int main(int argc,char **argv)
{
	
	FILE* f;
	FILE* g;
	int i,j;
	unsigned char key[32];
	unsigned char text[32];
	unsigned char text2[32];
	parsemycmdlines(argc,argv);
	f=fopen(keyfilename,"r");
	fread(key,16,1,f);
	fclose(f);
	f=fopen(inputfilename,"r");
	g=fopen(outputfilename,"w");
	if (cryptnotdecrypt) fprintf(g,"DAES040A%%"); else 
	{
		fread(text,9,1,f);
		if (text[0]!='D' || text[1]!='A' || text[2]!='E' || text[3]!='S' || text[8]!='%') fseek(f,0,0);
	}
	
	i=-1;
	while (!feof(f))
	{
		if (!(cryptnotdecrypt) && (i==-1)) i=fread(text2,1,16,f);
		i=fread(text,1,16,f);
		if (cryptnotdecrypt)
		{
			if (i>0)
			{
				for (j=i;j<16;j++) text[j]=text[j%i];
				aescrypt(text,key,MODE_128);
				fwrite(text,1,16,g);
			} else i=16;
			if (i<16) fprintf(g,"%c",(char)i);
		} else {
			aesdecrypt(text2,key,MODE_128);
			if (i!=1) fwrite(text2,1,16,g);	else fwrite(text2,1,(int)text[0],g);	
			for (i=0;i<16;i++) text2[i]=text[i];	
		}
	}
	fclose(f);
	fclose(g);
	exit(1);
}
