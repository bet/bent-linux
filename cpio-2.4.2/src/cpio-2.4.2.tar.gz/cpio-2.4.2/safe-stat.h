#define SAFE_STAT(path,pbuf) stat(path,pbuf)
