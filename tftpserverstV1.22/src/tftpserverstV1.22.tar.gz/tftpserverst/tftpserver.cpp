/**************************************************************************
*   Copyright (C) 2005 by Achal Dhir                                      *
*   achaldhir@gmail.com                                                   *
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/

// tftpserver.cpp

#include <sys/types.h>
#include <limits.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <time.h>
#include <stdlib.h>
#include <limits.h>
#include <memory.h>
#include <sys/stat.h>
#include <stdio.h>
#include <syslog.h>
#include <string>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <map>
using namespace std;
#include "tftpserver.h"

//Functions
void runProg();
int processNew(request *req);
int processSend(request *req);
int processRecv(request *req);
char *cleanstr(char* buff, bool next);
void init();
bool getSection(char *sectionName, char *buffer, int sizeofbuffer, char *fileName);
char *myLower(char *string);
char *myUpper(char *string);
char* IP2String(DWORD);
BYTE addServer(DWORD*, DWORD);
DWORD *findServer(DWORD*, DWORD);
extern void getServ(DWORD *array, const BYTE max_servers);
BYTE isIP(char*);
void logMess(request*, BYTE);
void logMess(BYTE);
DWORD my_inet_addr(char*);

//types
typedef map<string, request*> myMap;
typedef multimap<long, request*> myMultiMap;

//Global Variables
myMap tftpCache;
myMultiMap tftpAge;
bool verbatim = false;
char iniFile[]="/etc/tftpserver.ini";
WORD blksize = MAX_BLOCK_SIZE;
WORD interval = 3;
data2 cfig;
char tempbuff[256];
char logBuff[512];

int main(int argc, char **argv)
{
	verbatim = (argc > 1 && !strcasecmp(argv[1], "-v"));
	if (verbatim)
	{
		if (getuid())
		{
			printf("Error: Only root should run this program\n");
			exit(1);
		}

		init();
		timeval tv;
		fd_set readfds;
		request req;
		int fdsReady = 0;

		if (cfig.tftpConn[0].server)
		{
			printf("\nAccepting requests..\n");

			do
			{
				FD_ZERO(&readfds);
				tv.tv_sec = 1;
				tv.tv_usec = 0;

				for (int i = 0; i < MAX_SERVERS && cfig.tftpConn[i].server; i++)
					FD_SET(cfig.tftpConn[i].sock, &readfds);

				errno = 0;
				fdsReady = select(cfig.maxFD, &readfds, NULL, NULL, &tv);

				//if (errno)
				//	printf("%s\n", strerror(errno));

				for (int i = 0; fdsReady > 0 && i < MAX_SERVERS && cfig.tftpConn[i].server; i++)
				{
					if (FD_ISSET(cfig.tftpConn[i].sock, &readfds))
					{
						fdsReady--;
						memset(&req, 0, sizeof(request));
						req.clientsize = sizeof(req.client);
						req.sockInd = i;
						errno = 0;
						req.bytesRecd = recvfrom(cfig.tftpConn[req.sockInd].sock, (char*) & req.datain, sizeof(packet), 0, (sockaddr*)&req.client, &req.clientsize);
						sprintf(req.mapname, "%s:%u", inet_ntoa(req.client.sin_addr), ntohs(req.client.sin_port));
						request *req1 = tftpCache[req.mapname];

						if (!req1)
							tftpCache.erase(req.mapname);

						if (req1)
						{
							if (req.bytesRecd < 4 || errno )
							{
								sprintf(logBuff, "Client %s, Communication Error", req.mapname);
								logMess(1);
								req1->attempt = UCHAR_MAX;

								if (req1->file)
								{
									fclose(req1->file);
									req1->file = 0;
								}
								continue;
							}
							else if (ntohs(req.datain.opcode) == 1 || ntohs(req.datain.opcode) == 2)
							{
								if (req1->file)
								{
									fclose(req1->file);
									req1->file = 0;
								}

								memcpy(req1, &req, sizeof(request));

								if (processNew(req1))
									memcpy(&req, req1, sizeof(request));
							}
							else if (ntohs(req.datain.opcode) == 3)
							{
								req1->tblock = req1->block + 1;
								if (ntohs(req.datain.block) == req1->tblock)
								{
									//printf("in\n");
									req1->block = req1->tblock;
									req1->fblock++;
									req1->attempt = 0;
									req1->acout.opcode = htons(4);
									req1->acout.block = ntohs(req1->block);
									memcpy(&req1->datain, &req.datain, req.bytesRecd);
									req1->bytesRecd = req.bytesRecd;

									if (processRecv(req1))
										memcpy(&req, req1, sizeof(request));
								}
							}
							else if (ntohs(req.datain.opcode) == 4)
							{
								if (ntohs(req.datain.block) == req1->block)
								{
									req1->block++;
									req1->fblock++;
									req1->attempt = 0;
									memcpy(&req1->datain, &req.datain, req.bytesRecd);
									req1->bytesRecd = req.bytesRecd;

									if (processSend(req1))
										memcpy(&req, req1, sizeof(request));
								}
							}
							else if (ntohs(req.datain.opcode) == 5)
							{
								sprintf(logBuff, "Client %s, Error %i at Client, %s", req.mapname, ntohs(req.clientError.errorcode), req.clientError.errormessage);
								logMess(1);
								req1->attempt = UCHAR_MAX;

								if (req1->file)
								{
									fclose(req1->file);
									req1->file = 0;
								}
								continue;
							}
							else
							{
								req.serverError.opcode = htons(5);
								req.serverError.errorcode = htons(0);
								sprintf(req.serverError.errormessage, "Unexpected Option Code %u", ntohs(req.datain.opcode));
							}
						}
						else if (req.bytesRecd < 4 || errno )
						{
							sprintf(logBuff, "Client %s, Communication Error", req.mapname);
							logMess(1);
							continue;
						}
						else
						{
							if (cfig.hostRanges[0].rangeStart)
							{
								DWORD iip = ntohl(req.client.sin_addr.s_addr);
								BYTE allowed = 0;

								for (int j = 0; j <= 32 && cfig.hostRanges[j].rangeStart; j++)
								{
									if (iip >= cfig.hostRanges[j].rangeStart && iip <= cfig.hostRanges[j].rangeEnd)
									{
										allowed = 1;
										break;
									}
								}

								if (!allowed)
								{
									req.serverError.opcode = htons(5);
									req.serverError.errorcode = htons(2);
									strcpy(req.serverError.errormessage, "Access Denied");
									logMess(&req, 1);
									req.bytesSent = sendto(cfig.tftpConn[i].sock, (const char*) &req.serverError, strlen(req.serverError.errormessage) + 5, 0, (sockaddr*) & req.client, req.clientsize);
									continue;
								}
							}

							if (ntohs(req.datain.opcode) == 1 || ntohs(req.datain.opcode) == 2)
							{
								if (!processNew(&req))
								{
									request *req1 = (request*)malloc(sizeof(request));
									req1->bytesRecd = req.bytesRecd;
									memcpy(req1, &req, sizeof(request));
									tftpCache[req1->mapname] = req1;
									tftpAge.insert(pair<long, request*>(req1->expiry, req1));
								}
							}
							else if (ntohs(req.datain.opcode) == 5)
							{
								sprintf(logBuff, "Client %s, Error %i at Client, %s", req.mapname, ntohs(req.clientError.errorcode), req.clientError.errormessage);
								logMess(1);
								continue;
							}
							else
							{
								req.serverError.opcode = htons(5);
								req.serverError.errorcode = htons(5);
								sprintf(req.serverError.errormessage, "Unknown transfer ID");
							}
						}

						if (errno || req.serverError.errormessage[0])
						{
							if (!req.serverError.errormessage[0])
							{
								req.serverError.opcode = htons(5);
								req.serverError.errorcode = htons(0);
								sprintf(req.serverError.errormessage, "%s", strerror(errno));
							}

							if (req.file)
							{
								fclose(req.file);
								req.file = 0;
							}

							req.attempt = UCHAR_MAX;
							logMess(&req, 1);

							req.bytesSent = sendto(cfig.tftpConn[req.sockInd].sock, (const char*) &req.serverError, strlen(req.serverError.errormessage) + 5, 0, (sockaddr*) & req.client, req.clientsize);
						}
					}
				}

				myMultiMap::iterator p = tftpAge.begin();
				myMultiMap::iterator q;
				time_t currentTime = time(NULL);

				while (p != tftpAge.end())
				{
					if (!tftpAge.size())
						break;

					request *req = (*p).second;

					if (p->first > currentTime)
					{
						break;
					}
					else if (p->first < req->expiry && req->expiry > currentTime)
					{
						q = p;
						p++;
						tftpAge.erase(q);
						tftpAge.insert(pair<long, request*>(req->expiry, req));
					}
					else if (req->expiry + req->interval < currentTime)
					{
						if (req->file)
						{
							fclose(req->file);
							req->file = 0;
						}

						if (req->attempt < UCHAR_MAX)
						{
							req->serverError.opcode = htons(5);
							req->serverError.errorcode = htons(0);

							if (req->fblock && !req->block)
								strcpy(req->serverError.errormessage, "File too large for client");
							else
								strcpy(req->serverError.errormessage, "Timeout");

							req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) &req->serverError, strlen(req->serverError.errormessage) + 5, 0, (sockaddr*) & req->client, req->clientsize);
							logMess(req, 1);
						}

						q = p;
						p++;
						tftpAge.erase(q);
						tftpCache.erase(req->mapname);
						free(req);
					}
					else if (req->expiry <= currentTime && req->attempt < 3)
					{
						if (ntohs(req->datain.opcode) == 1)
						{
							if (req->file)
							{
								fclose(req->file);
								req->file = 0;
							}
							req->bytesSent = 0;
							processNew(req);
						}
						else if (ntohs(req->datain.opcode) == 2)
							req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) & req->acout, 4, 0, (sockaddr*) & req->client, req->clientsize);
						else if (ntohs(req->datain.opcode) == 3)
							req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) & req->acout, 4, 0, (sockaddr*) & req->client, req->clientsize);
						else if (ntohs(req->datain.opcode) == 4)
							processSend(req);

						req->attempt++;
						req->expiry = currentTime + req->interval;
						p++;
					}
					else
						p++;
				}
				//printf("%u=%u\n",tftpCache.size(),tftpAge.size());
			}
			while (true);

			for (int i = 0; i < MAX_SERVERS && cfig.tftpConn[i].server; i++)
				close(cfig.tftpConn[i].sock);
		}
	}
	else
	{
		if (getuid())
		{
			syslog(LOG_MAKEPRI(LOG_LOCAL1, LOG_CRIT), "Only root should run this program");
			exit(1);
		}

		/* Our process ID and Session ID */
		pid_t pid, sid;

		/* Fork off the parent process */
		pid = fork();
		if (pid < 0)
		{
			exit(EXIT_FAILURE);
		}
		/* If we got a good PID, then
		we can exit the parent process. */
		if (pid > 0)
		{
			exit(EXIT_SUCCESS);
		}

		/* Change the file mode mask */
		umask(0);

		/* Open any logs here */

		/* Create a new SID for the child process */
		sid = setsid();
		if (sid < 0)
		{
			/* Log the failure */
			exit(EXIT_FAILURE);
		}

		/* Close out the standard file descriptors */
		close(STDIN_FILENO);
		close(STDOUT_FILENO);
		close(STDERR_FILENO);

		/* Daemon-specific initialization goes here */
		//Initialize
		verbatim = false;
		init();

		timeval tv;
		fd_set readfds;
		request req;
		int fdsReady = 0;

		if (cfig.tftpConn[0].server)
		{
			do
			{
				FD_ZERO(&readfds);
				tv.tv_sec = 1;
				tv.tv_usec = 0;

				for (int i = 0; i < MAX_SERVERS && cfig.tftpConn[i].server; i++)
					FD_SET(cfig.tftpConn[i].sock, &readfds);

				errno = 0;
				fdsReady = select(cfig.maxFD, &readfds, NULL, NULL, &tv);

				//if (errno)
				//	printf("%s\n", strerror(errno));

				for (int i = 0; fdsReady > 0 && i < MAX_SERVERS && cfig.tftpConn[i].server; i++)
				{
					if (FD_ISSET(cfig.tftpConn[i].sock, &readfds))
					{
						fdsReady--;
						memset(&req, 0, sizeof(request));
						req.clientsize = sizeof(req.client);
						req.sockInd = i;
						errno = 0;
						req.bytesRecd = recvfrom(cfig.tftpConn[req.sockInd].sock, (char*) & req.datain, sizeof(packet), 0, (sockaddr*)&req.client, &req.clientsize);
						sprintf(req.mapname, "%s:%u", inet_ntoa(req.client.sin_addr), ntohs(req.client.sin_port));
						request *req1 = tftpCache[req.mapname];

						if (!req1)
							tftpCache.erase(req.mapname);

						if (req1)
						{
							if (req.bytesRecd < 4 || errno )
							{
								sprintf(logBuff, "Client %s, Communication Error", req.mapname);
								logMess(1);
								req1->attempt = UCHAR_MAX;

								if (req1->file)
								{
									fclose(req1->file);
									req1->file = 0;
								}
								continue;
							}
							else if (ntohs(req.datain.opcode) == 1 || ntohs(req.datain.opcode) == 2)
							{
								if (req1->file)
								{
									fclose(req1->file);
									req1->file = 0;
								}

								memcpy(req1, &req, sizeof(request));

								if (processNew(req1))
									memcpy(&req, req1, sizeof(request));
							}
							else if (ntohs(req.datain.opcode) == 3)
							{
								req1->tblock = req1->block + 1;
								if (ntohs(req.datain.block) == req1->tblock)
								{
									//printf("in\n");
									req1->block = req1->tblock;
									req1->fblock++;
									req1->attempt = 0;
									req1->acout.opcode = htons(4);
									req1->acout.block = ntohs(req1->block);
									memcpy(&req1->datain, &req.datain, req.bytesRecd);
									req1->bytesRecd = req.bytesRecd;

									if (processRecv(req1))
										memcpy(&req, req1, sizeof(request));
								}
							}
							else if (ntohs(req.datain.opcode) == 4)
							{
								if (ntohs(req.datain.block) == req1->block)
								{
									req1->block++;
									req1->fblock++;
									req1->attempt = 0;
									memcpy(&req1->datain, &req.datain, req.bytesRecd);
									req1->bytesRecd = req.bytesRecd;

									if (processSend(req1))
										memcpy(&req, req1, sizeof(request));
								}
							}
							else if (ntohs(req.datain.opcode) == 5)
							{
								sprintf(logBuff, "Client %s, Error %i at Client, %s", req.mapname, ntohs(req.clientError.errorcode), req.clientError.errormessage);
								logMess(1);
								req1->attempt = UCHAR_MAX;

								if (req1->file)
								{
									fclose(req1->file);
									req1->file = 0;
								}
								continue;
							}
							else
							{
								req.serverError.opcode = htons(5);
								req.serverError.errorcode = htons(0);
								sprintf(req.serverError.errormessage, "Unexpected Option Code %u", ntohs(req.datain.opcode));
							}
						}
						else if (req.bytesRecd < 4 || errno )
						{
							sprintf(logBuff, "Client %s, Communication Error", req.mapname);
							logMess(1);
							continue;
						}
						else
						{
							if (cfig.hostRanges[0].rangeStart)
							{
								DWORD iip = ntohl(req.client.sin_addr.s_addr);
								BYTE allowed = 0;

								for (int j = 0; j <= 32 && cfig.hostRanges[j].rangeStart; j++)
								{
									if (iip >= cfig.hostRanges[j].rangeStart && iip <= cfig.hostRanges[j].rangeEnd)
									{
										allowed = 1;
										break;
									}
								}

								if (!allowed)
								{
									req.serverError.opcode = htons(5);
									req.serverError.errorcode = htons(2);
									strcpy(req.serverError.errormessage, "Access Denied");
									logMess(&req, 1);
									req.bytesSent = sendto(cfig.tftpConn[i].sock, (const char*) &req.serverError, strlen(req.serverError.errormessage) + 5, 0, (sockaddr*) & req.client, req.clientsize);
									continue;
								}
							}

							if (ntohs(req.datain.opcode) == 1 || ntohs(req.datain.opcode) == 2)
							{
								if (!processNew(&req))
								{
									request *req1 = (request*)malloc(sizeof(request));
									req1->bytesRecd = req.bytesRecd;
									memcpy(req1, &req, sizeof(request));
									tftpCache[req1->mapname] = req1;
									tftpAge.insert(pair<long, request*>(req1->expiry, req1));
								}
							}
							else if (ntohs(req.datain.opcode) == 5)
							{
								sprintf(logBuff, "Client %s, Error %i at Client, %s", req.mapname, ntohs(req.clientError.errorcode), req.clientError.errormessage);
								logMess(1);
								continue;
							}
							else
							{
								req.serverError.opcode = htons(5);
								req.serverError.errorcode = htons(5);
								sprintf(req.serverError.errormessage, "Unknown transfer ID");
							}
						}

						if (errno || req.serverError.errormessage[0])
						{
							if (!req.serverError.errormessage[0])
							{
								req.serverError.opcode = htons(5);
								req.serverError.errorcode = htons(0);
								sprintf(req.serverError.errormessage, "%s", strerror(errno));
							}

							if (req.file)
							{
								fclose(req.file);
								req.file = 0;
							}

							req.attempt = UCHAR_MAX;
							logMess(&req, 1);

							req.bytesSent = sendto(cfig.tftpConn[req.sockInd].sock, (const char*) &req.serverError, strlen(req.serverError.errormessage) + 5, 0, (sockaddr*) & req.client, req.clientsize);
						}
					}
				}

				myMultiMap::iterator p = tftpAge.begin();
				myMultiMap::iterator q;
				time_t currentTime = time(NULL);

				while (p != tftpAge.end())
				{
					if (!tftpAge.size())
						break;

					request *req = (*p).second;

					if (p->first > currentTime)
					{
						break;
					}
					else if (p->first < req->expiry && req->expiry > currentTime)
					{
						q = p;
						p++;
						tftpAge.erase(q);
						tftpAge.insert(pair<long, request*>(req->expiry, req));
					}
					else if (req->expiry + req->interval < currentTime)
					{
						if (req->file)
						{
							fclose(req->file);
							req->file = 0;
						}

						if (req->attempt < UCHAR_MAX)
						{
							req->serverError.opcode = htons(5);
							req->serverError.errorcode = htons(0);

							if (req->fblock && !req->block)
								strcpy(req->serverError.errormessage, "File too large for client");
							else
								strcpy(req->serverError.errormessage, "Timeout");

							req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) &req->serverError, strlen(req->serverError.errormessage) + 5, 0, (sockaddr*) & req->client, req->clientsize);
							logMess(req, 1);
						}

						q = p;
						p++;
						tftpAge.erase(q);
						tftpCache.erase(req->mapname);
						free(req);
					}
					else if (req->expiry <= currentTime && req->attempt < 3)
					{
						if (ntohs(req->datain.opcode) == 1)
						{
							if (req->file)
							{
								fclose(req->file);
								req->file = 0;
							}
							req->bytesSent = 0;
							processNew(req);
						}
						else if (ntohs(req->datain.opcode) == 2)
							req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) & req->acout, 4, 0, (sockaddr*) & req->client, req->clientsize);
						else if (ntohs(req->datain.opcode) == 3)
							req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) & req->acout, 4, 0, (sockaddr*) & req->client, req->clientsize);
						else if (ntohs(req->datain.opcode) == 4)
							processSend(req);

						req->attempt++;
						req->expiry = currentTime + req->interval;
						p++;
					}
					else
						p++;
				}
				//printf("%u=%u\n",tftpCache.size(),tftpAge.size());
			}
			while (true);

			for (int i = 0; i < MAX_SERVERS && cfig.tftpConn[i].server; i++)
				close(cfig.tftpConn[i].sock);
		}
	}
}

int processNew(request *req)
{
	//printf("Here\n");
	req->block = 0;
	req->bytesSent = 0;
	req->blksize = 512;
	req->interval = interval - (interval / 2);
	req->expiry = time(NULL) + req->interval;

	char *temp = (char*) &req->datain;
	temp += 2;
	req->filename = temp;
	temp += strlen(temp) + 1;
	req->mode = temp;
	temp += strlen(temp) + 1;
	req->alias = req->filename;

	for (int i = 0; i < strlen(req->alias); i++)
		if (req->alias[i] == '\\')
			req->alias[i] = '/';

	if (strstr(req->alias, "../"))
	{
		req->serverError.opcode = htons(5);
		req->serverError.errorcode = htons(2);
		strcpy(req->serverError.errormessage, "Access violation");
		req->bytesSent = send(cfig.tftpConn[req->sockInd].sock, (const char*) &req->serverError, strlen(req->serverError.errormessage) + 5, 0);
		logMess(req, 1);
		return 1;
	}

	if (req->alias[0] == '/')
		req->alias++;

	if (!cfig.homes[0].alias[0])
	{
		strcpy(req->path, cfig.homes[0].target);
		strcat(req->path, req->alias);
	}
	else
	{
		char *ptr = strchr(req->alias, '/');

		if (ptr)
		{
			*ptr = 0;
			ptr++;
		}
		else
		{
			req->serverError.opcode = htons(5);
			req->serverError.errorcode = htons(2);
			sprintf(req->serverError.errormessage, "Missing directory/alias");
			req->bytesSent = send(cfig.tftpConn[req->sockInd].sock, (const char*) & req->serverError, strlen(req->serverError.errormessage) + 5, 0);
			logMess(req, 1);
			return 1;
		}

		for (int i = 0; i < 8; i++)
		{
			//printf("%s=%i\n", req->alias, cfig.homes[i].alias[0]);

			if (cfig.homes[i].alias[0] && !strcasecmp(req->alias, cfig.homes[i].alias))
			{
				strcpy(req->path, cfig.homes[i].target);
				strcat(req->path, ptr);
				break;
			}
			else if (i == 7 || !cfig.homes[i].alias[0])
			{
				req->serverError.opcode = htons(5);
				req->serverError.errorcode = htons(2);
				sprintf(req->serverError.errormessage, "No such directory/alias");
				req->bytesSent = send(cfig.tftpConn[req->sockInd].sock, (const char*) & req->serverError, strlen(req->serverError.errormessage) + 5, 0);
				logMess(req, 1);
				return 1;
			}
		}
	}

	if (ntohs(req->datain.opcode) == 1)
	{
		errno = 0;

		if (strcasecmp(req->mode, "netascii"))
			req->file = fopen(req->path, "rb");
		else
			req->file = fopen(req->path, "rt");

		if (errno || !req->file)
		{
			req->serverError.opcode = htons(5);
			req->serverError.errorcode = htons(1);
			strcpy(req->serverError.errormessage, "File Not Found");
			return 1;
		}
	}
	else
	{
		if (!cfig.overwrite)
		{
			req->file = fopen(req->path, "rb");
			if (req->file)
			{
				req->serverError.opcode = htons(5);
				req->serverError.errorcode = htons(6);
				strcpy(req->serverError.errormessage, "File already exists");
				return 1;
			}
		}

		errno = 0;

		if (strcasecmp(req->mode, "netascii"))
			req->file = fopen(req->path, "wb");
		else
			req->file = fopen(req->path, "wt");

		if (errno || !req->file)
		{
			req->serverError.opcode = htons(5);
			req->serverError.errorcode = htons(2);
			strcpy(req->serverError.errormessage, "Invalid Path");
			return 1;
		}
	}

	if (*temp)
	{
		char *pointer = req->acout.buffer;
		req->acout.opcode = htons(6);
		DWORD val;
		while (*temp)
		{
			//printf("%s", temp);
			if (!strcasecmp(temp, "blksize"))
			{
				strcpy(pointer, temp);
				pointer += strlen(pointer) + 1;
				temp += strlen(temp) + 1;
				val = atol(temp);

				if (val > 512 && val <= blksize)
					req->blksize = val;

				sprintf(pointer, "%u", req->blksize);
				pointer += strlen(pointer) + 1;
				temp += strlen(temp) + 1;

			}
			else if (!strcasecmp(temp, "tsize"))
			{
				strcpy(pointer, temp);
				pointer += strlen(pointer) + 1;
				temp += strlen(temp) + 1;
				fseek(req->file, 0, SEEK_END);
				req->tsize = ftell(req->file);
				sprintf(pointer, "%u", req->tsize);
				pointer += strlen(pointer) + 1;
				temp += strlen(temp) + 1;
			}
			else if (!strcasecmp(temp, "interval"))
			{
				strcpy(pointer, temp);
				pointer += strlen(pointer) + 1;
				temp += strlen(temp) + 1;
				val = atoi(temp);

				if (val > 0 && val <= 120)
				{
					req->interval = val - (val / 2);
					req->expiry = time(NULL) + req->interval;
				}
				else
					val = interval;

				sprintf(pointer, "%u", val);
				pointer += strlen(pointer) + 1;
				temp += strlen(temp) + 1;
			}
			else
				temp += strlen(temp) + 1;

			//printf("=%u\n",val);
		}

		req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) & req->acout, (DWORD)pointer - (DWORD) & req->acout, 0, (sockaddr*) & req->client, req->clientsize);
	}
	else if (htons(req->datain.opcode) == 2)
	{
		req->acout.opcode = htons(4);
		req->acout.block = htons(0);
		req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) & req->acout, 4, 0, (sockaddr*) & req->client, req->clientsize);
	}

	if (errno )
	{
		sprintf(req->serverError.errormessage, "Communication Error");
		return errno;
	}

	if (ntohs(req->datain.opcode) == 1)
	{
		if (ftell(req->file))
			fseek(req->file, 0, SEEK_SET);

		req->pkt[0].opcode = htons(3);
		req->pkt[0].block = htons(1);
		req->bytesRead[0] = fread(req->pkt[0].buffer, 1, req->blksize, req->file);

		if (errno )
		{
			sprintf(req->serverError.errormessage, "Communication Error");
			return errno;
		}

		if (req->bytesRead[0] == req->blksize)
		{
			req->pkt[1].opcode = htons(3);
			req->pkt[1].block = htons(2);
			req->bytesRead[1] = fread(req->pkt[1].buffer, 1, req->blksize, req->file);
			if (req->bytesRead[1] < req->blksize)
			{
				fclose(req->file);
				req->file = 0;
			}
		}
		else
		{
			fclose(req->file);
			req->file = 0;
		}

		if (!req->bytesSent)
		{
			req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) & req->pkt[0], req->bytesRead[0] + 4, 0, (sockaddr*) & req->client, req->clientsize);
			req->block = 1;
		}
	}
	return 0;
}

int processSend(request *req)
{
	errno = 0;
	req->expiry = time(NULL) + req->interval;

	if (ntohs(req->pkt[0].block) == req->block)
	{
		errno = 0;
		req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) & req->pkt[0], req->bytesRead[0] + 4, 0, (sockaddr*) & req->client, req->clientsize);

		if (errno)
		{
			sprintf(req->serverError.errormessage, "Communication Error");
			return errno;
		}

		if (req->file)
		{
			req->tblock = ntohs(req->pkt[1].block) + 1;
			if (req->tblock == req->block)
			{
				req->pkt[1].block = htons(++req->tblock);
				req->bytesRead[1] = fread(req->pkt[1].buffer, 1, req->blksize, req->file);

				if (errno)
				{
					return errno;
				}
				else if (req->bytesRead[1] < req->blksize)
				{
					fclose(req->file);
					req->file = 0;
				}
			}
		}
	}
	else if (ntohs(req->pkt[1].block) == req->block)
	{
		req->bytesSent = sendto(cfig.tftpConn[req->sockInd].sock, (const char*) & req->pkt[1], req->bytesRead[1] + 4, 0, (sockaddr*) & req->client, req->clientsize);

		if (errno )
		{
			sprintf(req->serverError.errormessage, "Communication Error");
			return errno;
		}

		if (req->file)
		{
			req->tblock = ntohs(req->pkt[0].block) + 1;
			if (req->tblock == req->block)
			{
				req->pkt[0].block = htons(++req->tblock);
				req->bytesRead[0] = fread(req->pkt[0].buffer, 1, req->blksize, req->file);

				if (errno)
				{
					return errno;
				}
				else if (req->bytesRead[0] < req->blksize)
				{
					fclose(req->file);
					req->file = 0;
				}
			}
		}
	}
	else //if (ntohs(req->pkt[0].block) < req->block && ntohs(req->pkt[1].block) < req->block)
	{
		req->attempt = UCHAR_MAX;

		if (!errno && !req->serverError.errormessage[0])
		{
			sprintf(logBuff, "Client %s %s, %u Blocks Served", req->mapname, req->path, req->fblock);
			logMess(2);
		}
		else
			return errno;
	}

	return 0;
}

int processRecv(request *req)
{
	errno = 0;
	req->expiry = time(NULL) + req->interval;
	errno=0;
	sendto(cfig.tftpConn[req->sockInd].sock, (const char*)&req->acout, 4, 0, (sockaddr*)&req->client, req->clientsize);

	if (errno )
	{
		sprintf(req->serverError.errormessage, "Communication Error");
		return errno;
	}

	if (req->bytesRecd > 4 && !fwrite(req->datain.buffer, req->bytesRecd - 4, 1, req->file))
	{
		req->serverError.opcode = htons(5);
		req->serverError.errorcode = htons(3);
		strcpy(req->serverError.errormessage, "Disk full or allocation exceeded");
		return 1;
	}

	//printf("%u\n", req->bytesRecd);

	if (req->bytesRecd - 4 < req->blksize)
	{
		if (!errno && !req->serverError.errormessage[0])
		{
			sprintf(logBuff, "Client %s %s, %u Blocks Received", req->mapname, req->path, req->fblock);
			logMess(2);
		}

		req->attempt = UCHAR_MAX;
		req->expiry = 0;
		fclose(req->file);
		req->file = 0;
		return 0;
	}

	return 0;
}

void init()
{
	memset(&cfig, 0, sizeof(cfig));
	char iniStr[4096];

	if (getSection("LOGGING", iniStr, sizeof(iniStr), iniFile))
	{
		char *iniStrPtr = cleanstr(iniStr, false);

		if (!iniStrPtr[0] || !strcasecmp(iniStrPtr, "None"))
			cfig.logLevel = 0;
		else if (!strcasecmp(iniStrPtr, "Errors"))
			cfig.logLevel = 1;
		else if (!strcasecmp(iniStrPtr, "All"))
			cfig.logLevel = 2;
		else
		{
			sprintf(logBuff, "Section [LOGGING], Invalid Logging Level: %s ignored", iniStrPtr);
			logMess(0);
		}
	}

	if (verbatim)
		cfig.logLevel = 2;

	if (getSection("LISTEN-ON", iniStr, sizeof(iniStr), iniFile))
	{
		char *iniStrPtr = cleanstr(iniStr, false);
		for (int i = 0; i < MAX_SERVERS && iniStrPtr[0]; iniStrPtr = cleanstr(iniStrPtr, true))
		{
			DWORD addr = my_inet_addr(iniStrPtr);
			if (isIP(iniStrPtr) && addr)
			{
				if (addServer(cfig.listenServers, addr))
					i++;
			}
			else
			{
				sprintf(logBuff, "Warning: Section [LISTEN-ON], Invalid IP Address %s, ignored", iniStrPtr);
				logMess(1);
			}
		}
	}

	if (getSection("HOME", iniStr, sizeof(iniStr), iniFile))
	{
		char *iniStrPtr = cleanstr(iniStr, false);
		for (; iniStrPtr[0]; iniStrPtr = cleanstr(iniStrPtr, true))
		{
			char name[256];
			strncpy(name, iniStrPtr, 255);
			char *value = strchr(name, '=');
			if (value)
			{
				*value = 0;
				value++;
				if (!cfig.homes[0].alias[0] && cfig.homes[0].target[0])
				{
					sprintf(logBuff, "Section [HOME], alias and bare path mixup, entry %s ignored", iniStrPtr);
					logMess(1);
				}
				else if (strchr(name, '\\') || strchr(name, '/') || strchr(name, '>') || strchr(name, '<') || strchr(name, '.'))
				{
					sprintf(logBuff, "Section [HOME], invalid chars in alias %s, entry ignored", name);
					logMess(1);
				}
				else if (name[0] && strlen(name) < 64 && value[0])
				{
					for (int i = 0; i < 8; i++)
					{
						if (cfig.homes[i].alias[0] && !strcasecmp(name, cfig.homes[i].alias))
						{
							sprintf(logBuff, "Section [HOME], Duplicate Entry: %s ignored", iniStrPtr);
							logMess(1);
							break;
						}
						else if (!cfig.homes[i].alias[0])
						{
							strcpy(cfig.homes[i].alias, name);
							strcpy(cfig.homes[i].target, value);

							if (cfig.homes[i].target[strlen(cfig.homes[i].target) - 1] != '/')
								strcat(cfig.homes[i].target, "/");

							break;
						}
					}
				}
				else
				{
					sprintf(logBuff, "Section [HOME], alias name too large", name);
					logMess(1);
				}
			}
			else if (!cfig.homes[0].alias[0] && !cfig.homes[0].target[0])
			{
				strcpy(cfig.homes[0].target, name);

				if (cfig.homes[0].target[strlen(cfig.homes[0].target) - 1] != '/')
					strcat(cfig.homes[0].target, "/");
			}
			else if (cfig.homes[0].alias[0])
			{
				sprintf(logBuff, "Section [HOME], alias and bare path mixup, entry %s ignored", iniStrPtr);
				logMess(1);
			}
			else if (cfig.homes[0].target[0])
			{
				sprintf(logBuff, "Section [HOME], Duplicate Path: %s ignored", iniStrPtr);
				logMess(1);
			}
			else
			{
				printf(logBuff, "Section [HOME], missing = sign, Invalid Entry: %s ignored", iniStrPtr);
				logMess(1);
			}
		}
	}

	if (!cfig.homes[0].target[0])
	{
		strcpy(cfig.homes[0].target, "/home/");
	}

	if (getSection("TFTP-OPTIONS", iniStr, sizeof(iniStr), iniFile))
	{
		char *iniStrPtr = cleanstr(iniStr, false);
		for (;strlen(iniStrPtr);iniStrPtr = cleanstr(iniStrPtr, true))
		{
			char name[256];
			strncpy(name, iniStrPtr, 255);
			char *value = strchr(name, '=');
			if (value != NULL)
			{
				*value = 0;
				value++;
				myLower(name);

				if (!strcmp(name, "blksize"))
				{
					blksize = atol(value);
					if (blksize < 512)
						blksize = 512;
					else if (blksize > MAX_BLOCK_SIZE)
						blksize = MAX_BLOCK_SIZE;
				}
				else if (!strcmp(name, "interval"))
				{
					interval = atol(value);
					if (interval < 1)
						interval = 3;
					else if (interval > 120)
						interval = 120;
				}
				else if (!strcmp(name, "overwrite"))
				{
					if (!strcasecmp(value, "y"))
						cfig.overwrite = true;
					else
						cfig.overwrite = false;
				}
				else if (!strcmp(name, "port-range"))
				{
					char *ptr = strchr(value, '-');
					if (ptr)
					{
						*ptr = 0;
						cfig.minport = atol(value);
						cfig.maxport = atol(++ptr);

						if (cfig.minport < 1024 || cfig.minport >= USHRT_MAX || cfig.maxport < 1024 || cfig.maxport >= USHRT_MAX || cfig.minport > cfig.maxport)
						{
							cfig.minport = 0;
							cfig.maxport = 0;

							sprintf(logBuff, "Invalid port range %s\n", value);
							logMess(1);
						}
					}
					else
					{
						sprintf(logBuff, "Invalid port range %s\n", value);
						logMess(1);
					}
				}
				else
				{
					sprintf(logBuff, "Unknown Option %s\n", name);
					logMess(1);
				}
			}
		}
	}

	if (getSection("ALLOWED-CLIENTS", iniStr, sizeof(iniStr), iniFile))
	{
		char *iniStrPtr = cleanstr(iniStr, false);
		for (int i = 0; i < 32 && iniStrPtr[0]; iniStrPtr = cleanstr(iniStrPtr, true))
		{
			char name[256];
			strncpy(name, iniStrPtr, 255);
			DWORD rs = 0;
			DWORD re = 0;
			char *ptr = strchr(name, '-');
			if (ptr)
			{
				*ptr = 0;
				ptr++;
				rs = htonl(my_inet_addr(name));
				re = htonl(my_inet_addr(ptr));
			}
			else
			{
				rs = htonl(my_inet_addr(name));
				re = rs;
			}
			if (rs && rs != INADDR_NONE && re && re != INADDR_NONE && rs <= re)
			{
				cfig.hostRanges[i].rangeStart = rs;
				cfig.hostRanges[i].rangeEnd = re;
				i++;
			}
			else
			{
				sprintf(logBuff, "Section [ALLOWED-CLIENTS] Invalid entry %s in ini file, ignored", iniStrPtr);
				logMess(1);
			}
		}
	}

	if (!cfig.listenServers[0])
		getServ(cfig.servers, MAX_SERVERS);
	else
		memcpy(&cfig.servers, &cfig.listenServers, MAX_SERVERS*sizeof(DWORD));

	int i = 0;

	for (int j = 0; j < MAX_SERVERS && cfig.servers[j]; j++)
	{
		cfig.tftpConn[i].sock = socket(AF_INET,
		                              SOCK_DGRAM,
		                              IPPROTO_UDP);

		if (cfig.tftpConn[i].sock == -1)
		{
			sprintf(logBuff, "Failed to Create Socket");
			logMess(1);
			continue;
		}

		cfig.tftpConn[i].addr.sin_family = AF_INET;
		cfig.tftpConn[i].addr.sin_addr.s_addr = cfig.servers[j];
		cfig.tftpConn[i].addr.sin_port = htons(69);

		socklen_t nRet = bind(cfig.tftpConn[i].sock,
		                      (sockaddr*) & cfig.tftpConn[i].addr,
		                      sizeof(cfig.tftpConn[i].addr)
		                     );

		if (nRet == -1)
		{
			close(cfig.tftpConn[i].sock);
			sprintf(logBuff, "%s Port 53 bind failed", IP2String(cfig.servers[j]));
			logMess(1);
			continue;
		}

		if (cfig.maxFD < cfig.tftpConn[i].sock)
			cfig.maxFD = cfig.tftpConn[i].sock;

		cfig.tftpConn[i].server = cfig.servers[j];
		i++;
	}

	cfig.maxFD++;

	if (!cfig.tftpConn[0].server)
	{
		sprintf(logBuff, "No listening Interfaces available, stopping...");
		logMess(1);
		getchar();
		return ;
	}
	else if (verbatim)
	{
		printf("\nStarting TFTP...\n");
	}
	else
	{
		sprintf(logBuff, "Starting TFTP Service");
		logMess(1);
	}

	if (cfig.tftpConn[0].server)
	{
		for (int i = 0; i < 8; i++)
			if (cfig.homes[i].target[0])
			{
				sprintf(logBuff, "Alias /%s is mapped to %s", cfig.homes[i].alias, cfig.homes[i].target);
				logMess(1);
			}

		for (int i = 0; i < MAX_SERVERS && cfig.tftpConn[i].server; i++)
		{
			sprintf(logBuff, "Listening On: %s", IP2String(cfig.tftpConn[i].server));
			logMess(1);
		}

		if (cfig.hostRanges[0].rangeStart)
		{
			char temp[128];

			for (int i = 0; i <= 32 && cfig.hostRanges[i].rangeStart; i++)
			{
				sprintf(logBuff, "%s", "Permitted Clients: ");
				sprintf(temp, "%s-", IP2String(htonl(cfig.hostRanges[i].rangeStart)));
				strcat(logBuff, temp);
				sprintf(temp, "%s", IP2String(htonl(cfig.hostRanges[i].rangeEnd)));
				strcat(logBuff, temp);
				logMess(1);
			}
		}
		else
		{
			sprintf(logBuff, "%s", "Permitted Clients: All");
			logMess(1);
		}

		sprintf(logBuff, "max blksize: %u", blksize);
		logMess(1);
		sprintf(logBuff, "defult blksize: %u", 512);
		logMess(1);
		sprintf(logBuff, "default interval: %u", interval);
		logMess(1);
		sprintf(logBuff, "Overwrite Existing Files: %s", cfig.overwrite ? "Yes" : "No");
		logMess(1);

		if (!verbatim)
		{
			sprintf(logBuff, "Logging: %s", cfig.logLevel > 1 ? "All" : "Errors");
			logMess(1);
		}
	}
}

char *cleanstr(char* buff, bool next)
{
	if (strlen(buff) && next)
		buff += strlen(buff) + 1;
	while (strlen(buff))
		if (*buff >= '0' && *buff <= '9' || *buff >= 'A' && *buff <= 'Z' || *buff >= 'a' && *buff <= 'z' || *buff == '/')
			break;
		else
			buff += strlen(buff) + 1;
	return buff;
}

bool getSection(char *sectionName, char *buffer, int sizeofbuffer, char *fileName)
{
	char section[128];
	sprintf(section, "[%s]", sectionName);
	myUpper(section);
	FILE *f = fopen(fileName, "r");
	char buff[512];
	char *ptr = buffer;
	*ptr = 0;
	bool found = false;
	while (f && fgets(buff, 255, f))
	{
		myUpper(buff);
		if (strstr(buff, section) == buff)
		{
			found = true;
			while (fgets(buff, 255, f))
			{
				if (strstr(buff, "[") == buff)
					break;
				sprintf(ptr, "%s", buff);
				ptr += strlen(buff);
				while (*ptr <= 32)
					ptr--;
				ptr++;
				*ptr = 0;
				ptr++;
			}
			*ptr = 0;
		}
	}
	if (f)
		fclose(f);
	return found;
}

char *IP2String(DWORD ip)
{
	in_addr inaddr;
	inaddr.s_addr = ip;
	sprintf(tempbuff, "%s", inet_ntoa(inaddr));
	return tempbuff;
}

char *myUpper(char *string)
{
	char diff = 'a' - 'A';
	WORD len = strlen(string);
	for (int i = 0; i < len; i++)
		if (string[i] >= 'a' && string[i] <= 'z')
			string[i] -= diff;
	return string;
}

char *myLower(char *string)
{
	char diff = 'a' - 'A';
	WORD len = strlen(string);
	for (int i = 0; i < len; i++)
		if (string[i] >= 'A' && string[i] <= 'Z')
			string[i] += diff;
	return string;
}

BYTE isIP(char *string)
{
	int j = 0;

	for (; *string; string++)
	{
		if (*string == '.')
			j++;
		else if (*string < '0' || *string > '9')
			return 0;
	}

	if (j == 3)
		return 1;
	else
		return 0;
}

DWORD my_inet_addr(char* str)
{
	if (str == NULL)
		return INADDR_ANY;
	DWORD x = inet_addr(str);
	if (x == INADDR_NONE)
		return INADDR_ANY;
	else
		return x;
}

DWORD *findServer(DWORD *array, DWORD ip)
{
	if (ip)
	{
		for (BYTE i = 0; i < MAX_SERVERS && array[i]; i++)
		{
			if (array[i] == ip)
				return &(array[i]);
		}
	}
	return 0;
}

BYTE addServer(DWORD *array, DWORD ip)
{
	for (BYTE i = 0; i < MAX_SERVERS; i++)
	{
		if (!ip || array[i] == ip)
			return 0;
		else if (!array[i])
		{
			array[i] = ip;
			return 1;
		}
	}
	return 0;
}

void logMess(BYTE messLevel)
{
	if (verbatim)
		printf("%s\n", logBuff);
	else if (messLevel <= cfig.logLevel)
		syslog(LOG_MAKEPRI(LOG_LOCAL1, LOG_CRIT), logBuff);
}

void logMess(request *req, BYTE messLevel)
{
	if (verbatim)
	{
		if (!req->serverError.errormessage[0])
			printf(req->serverError.errormessage, strerror(errno));

		if (req->path[0])
			printf("Client %s %s, %s\n", req->mapname, req->path, req->serverError.errormessage);
		else
			printf("Client %s, %s\n", req->mapname, req->serverError.errormessage);

	}
	else if (messLevel <= cfig.logLevel)
	{
		if (!req->serverError.errormessage[0])
			printf(req->serverError.errormessage, strerror(errno));

		if (req->path[0])
			printf(logBuff, "Client %s %s, %s\n", req->mapname, req->path, req->serverError.errormessage);
		else
			printf(logBuff, "Client %s, %s\n", req->mapname, req->serverError.errormessage);

		syslog(LOG_MAKEPRI(LOG_LOCAL1, LOG_CRIT), logBuff);
	}
}

