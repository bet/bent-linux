#include <sys/socket.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/ioctl.h>


#ifndef SIOCGIFCONF
#include <sys/sockio.h>
#endif

#define WORD unsigned short
#define BYTE unsigned char
#define DWORD unsigned long

BYTE addServer(DWORD *array, DWORD ip, BYTE max_servers)
{
	for (BYTE i = 0; i < max_servers; i++)
	{
		if (!ip || array[i] == ip)
			return 0;
		else if (!array[i])
		{
			array[i] = ip;
			return 1;
		}
	}
	return 0;
}

void getServ(DWORD *array, const BYTE max_servers)
{
	struct ifconf Ifc;
	struct ifreq IfcBuf[max_servers];
	struct ifreq *pIfr;
	int num_ifreq;
	int i;
	int fd;

	Ifc.ifc_len = sizeof(IfcBuf);
	Ifc.ifc_buf = (char *) IfcBuf;

	if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) >= 0)
	{
		if ( ioctl(fd, SIOCGIFCONF, &Ifc) >= 0)
		{
			num_ifreq = Ifc.ifc_len / sizeof(struct ifreq);
			for ( pIfr = Ifc.ifc_req, i = 0 ; i < num_ifreq; pIfr++, i++ )
			{
				DWORD iaddr = ((sockaddr_in*)(&pIfr->ifr_ifru.ifru_addr))->sin_addr.s_addr;
				addServer(array, iaddr, max_servers);
			}
		}
	}
}

