/* tag: Tom Lord Tue Dec  4 14:41:46 2001 (case-db-macros.h)
 */
/* case-db-macros.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__UNIDATA__CASE_DB_MACROS_H
#define INCLUDE__UNIDATA__CASE_DB_MACROS_H


#include "hackerlab/uni/unidata.h"


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__UNIDATA__CASE_DB_MACROS_H */
