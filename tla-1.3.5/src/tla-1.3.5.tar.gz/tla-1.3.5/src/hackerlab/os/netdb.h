/* tag: Tom Lord Tue Dec  4 14:41:32 2001 (netdb.h)
 */
/* netdb.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__OS__NETDB_H
#define INCLUDE__OS__NETDB_H


#include <netdb.h>


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__OS__NETDB_H */
