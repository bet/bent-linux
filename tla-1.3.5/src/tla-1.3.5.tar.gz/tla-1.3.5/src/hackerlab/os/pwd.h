/* tag: Tom Lord Tue Dec  4 14:41:32 2001 (pwd.h)
 */
/* pwd.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__OS__PWD_H
#define INCLUDE__OS__PWD_H


#include <pwd.h>


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__OS__PWD_H */
