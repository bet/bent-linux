/* zlib.h:
 *
 ****************************************************************
 * Copyright (C) 2005 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__OS__ZLIB_H
#define INCLUDE__OS__ZLIB_H


#include <zlib.h>


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__OS__ZLIB_H */


/* tag: Tom Lord Fri Apr 15 20:59:54 2005 (zlib.h)
 */
