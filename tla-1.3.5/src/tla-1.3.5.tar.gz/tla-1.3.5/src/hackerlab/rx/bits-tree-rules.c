/* tag: Tom Lord Tue Dec  4 14:41:38 2001 (bits-tree-rules.c)
 */
/* uni-bits.c - unicode bitset tree rules
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */


#include "hackerlab/rx/bits-tree-rules.h"



struct bits_tree_rule rx_8bit_bits_tree_rule[] = {{0, 256, 0, 0}};
