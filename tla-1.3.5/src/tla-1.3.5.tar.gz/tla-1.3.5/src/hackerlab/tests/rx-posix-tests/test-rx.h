/* test-rx.h - test rx.h
 *
 ****************************************************************
 * Copyright (C) 2000 Thomas Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */


#ifndef RX_TESTS_TEST_RXH
#define RX_TESTS_TEST_RXH



/* automatically generated __STDC__ prototypes */
#endif  /* RX_TESTS_TEST_RXH */
