/* tag: Tom Lord Tue Dec  4 14:41:04 2001 (test-rx-size.c)
 */

void regexec(void);
void regcomp(void);
void regerror(void);

int main () { regexec(); regcomp(); regerror(); return 0; }

