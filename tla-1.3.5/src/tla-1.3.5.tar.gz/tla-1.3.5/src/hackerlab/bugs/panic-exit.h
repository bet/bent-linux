/* tag: Tom Lord Tue Dec  4 14:41:26 2001 (panic-exit.h)
 */
/* panic-exit.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__BUGS__panic_H
#define INCLUDE__BUGS__panic_H



/* automatically generated __STDC__ prototypes */
extern void panic_exit (void);
#endif  /* INCLUDE__BUGS__panic_H */
