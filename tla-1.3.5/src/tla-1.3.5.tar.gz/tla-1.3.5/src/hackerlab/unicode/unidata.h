/* tag: Tom Lord Tue Dec  4 14:41:42 2001 (unidata.h)
 */
/* unidata.h -
 *
 ****************************************************************
 * Copyright (C) 2000 Tom Lord
 * 
 * See the file "COPYING" for further information about
 * the copyright and warranty status of this work.
 */

#ifndef INCLUDE__UNICODE__UNIDATA_H
#define INCLUDE__UNICODE__UNIDATA_H


#include "hackerlab/uni/coding.h"
#include "hackerlab/unidata/unidata.h"


/* automatically generated __STDC__ prototypes */
#endif  /* INCLUDE__UNICODE__UNIDATA_H */
