/* This is a (now *very slim*) stub for some liblogging
 * code we use in rsyslog.
 */
#ifndef __LIB3195_LIBLOGGINGSTUB_H_INCLUDED__
#define __LIB3195_LIBLOGGINGSTUB_H_INCLUDED__ 1
#include <stdio.h>
#endif
