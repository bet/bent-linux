#!/bin/sh

echo "Test0 run," $1 >> /tmp/ostiary/ostcmds.log
echo `date` >> /tmp/ostiary/ostcmds.log
