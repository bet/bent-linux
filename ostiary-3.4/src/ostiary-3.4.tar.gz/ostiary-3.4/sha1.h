/* sha1.h - Declaration of functions and data types used for SHA-1 sum
   computing library functions.
   Copyright (C) 2004 Raymond Ingles
*/

#ifndef _SHA1_H
#define _SHA1_H 1

/* Compute SHA-1 message digest for LEN bytes beginning at BUFFER.  The
   result is always in little endian byte order, so that a byte-wise
   output yields to the wanted ASCII representation of the message
   digest.  */
extern void *sha1_buffer (const char *buffer, size_t len, void *resblock);

#endif
