#!/bin/bash

wget http://www.unbolted.net/dump_clients.php -O ../conf/client_manuf
wget http://www.unbolted.net/dump_aps.php -O ../conf/ap_manuf

