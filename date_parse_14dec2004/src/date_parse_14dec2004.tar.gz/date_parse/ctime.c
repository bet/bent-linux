#include <stdio.h>
#include <time.h>

int
main( int argc, char** argv )
    {
    time_t t;

    t = atoi( argv[1] );
    fputs( ctime( &t ), stdout );
    exit( 0 );
    }
