#include <sys/types.h>
#include <stdio.h>
#include <time.h>

#include "date_parse.h"

int
main( int argc, char** argv )
    {
    char line[5000];
    time_t t;

    while ( fgets( line, sizeof(line), stdin ) != (char*) 0 )
	{
	t = date_parse( line );
	(void) printf( "%d - %s", t, ctime( &t ) );
	}

    exit( 0 );
    }
