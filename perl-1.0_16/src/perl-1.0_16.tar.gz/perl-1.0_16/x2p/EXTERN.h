/* $Header: EXTERN.h,v 1.0 87/12/18 13:06:44 root Exp $
 *
 * $Log:	EXTERN.h,v $
 * Revision 1.0  87/12/18  13:06:44  root
 * Initial revision
 * 
 */

#undef EXT
#define EXT extern

#undef INIT
#define INIT(x)

#undef DOINIT
