/* $Header: INTERN.h,v 1.0 87/12/18 13:06:48 root Exp $
 *
 * $Log:	INTERN.h,v $
 * Revision 1.0  87/12/18  13:06:48  root
 * Initial revision
 * 
 */

#undef EXT
#define EXT

#undef INIT
#define INIT(x) = x

#define DOINIT
