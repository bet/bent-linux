void hextype(FILE *f, void const *d, size_t len) ;
