#if __GLIBC__ < 2
#  include_next <nlist.h>
#endif
