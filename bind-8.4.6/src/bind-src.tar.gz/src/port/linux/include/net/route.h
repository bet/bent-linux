#if __GLIBC__ < 2
#  include_next <net/route.h>
#endif
