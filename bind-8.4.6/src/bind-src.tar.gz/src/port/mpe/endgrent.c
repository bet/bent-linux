void __bind_mpe_endgrent(void) {

return;
}

