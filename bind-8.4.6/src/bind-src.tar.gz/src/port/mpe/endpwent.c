void __bind_mpe_endpwent(void) {

return;
}

