int
__bind_mpe_nice(int priority) {
	/* NOOP */
	return 0;
}
