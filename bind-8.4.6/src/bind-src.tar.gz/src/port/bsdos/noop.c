static void
noop() {
	/* NOOP */
}
