int main() { return sync(); }
