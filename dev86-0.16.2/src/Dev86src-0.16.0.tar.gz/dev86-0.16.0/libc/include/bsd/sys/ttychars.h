#ifndef _BSD_SYS_TTYCHARS_H
#define _BSD_SYS_TTYCHARS_H
#endif /*  _BSD_SYS_TTYCHARS_H */
