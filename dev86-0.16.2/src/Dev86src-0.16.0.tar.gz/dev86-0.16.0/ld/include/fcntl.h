#define O_RDONLY	0
#define O_WRONLY	1
