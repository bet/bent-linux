#ifndef MATCH_H
#define MATCH_H

extern int match(char *,char *,unsigned int);

#endif
