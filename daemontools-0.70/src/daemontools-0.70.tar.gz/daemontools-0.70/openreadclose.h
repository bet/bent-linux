#ifndef OPENREADCLOSE_H
#define OPENREADCLOSE_H

#include "stralloc.h"

extern int openreadclose(char *,stralloc *,unsigned int);

#endif
