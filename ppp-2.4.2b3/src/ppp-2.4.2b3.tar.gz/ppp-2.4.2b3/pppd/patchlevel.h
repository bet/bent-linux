/* $Id: patchlevel.h,v 1.58 2003/05/01 12:47:55 paulus Exp $ */

#define VERSION		"2.4.2b3"
#define DATE		"1 May 2003"
