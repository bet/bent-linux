#ifdef SPANISH
  char *version="v2.2 por Slayer, 19/02/1999";
#else
  char *version="v2.2 by Slayer, 1999/02/19";
#endif
