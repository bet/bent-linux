#include "../unix/fullrw.c"
