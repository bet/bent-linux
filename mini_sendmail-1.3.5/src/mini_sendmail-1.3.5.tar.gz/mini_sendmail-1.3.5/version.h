/* version.h - version define for mini_sendmail */

#ifndef _VERSION_H_
#define _VERSION_H_

#define VERSION "mini_sendmail/1.3.5 16nov2003"

#endif /* _VERSION_H_ */
