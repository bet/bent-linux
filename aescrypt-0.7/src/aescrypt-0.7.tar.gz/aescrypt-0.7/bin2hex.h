/* Copyright 1999 Enhanced Software Technologies Inc.
 * All Rights Reserved
 *
 * bin2hex.c: binary to hex conversions. 
 *
 * RCS CHANGE LOG
 * Revision 1.1  2000/03/28 23:54:28  eric
 * Initial checkin -- aescrypt/aesget
 *
 * Revision 1.3  1999/11/18 16:23:36  eric
 * More mods to make it work. Start of the 'rsh' functionality.
 *
 * Revision 1.2  1999/09/30 20:32:28  eric
 * Refreshed after Richard foobared the CVS archive
 *
 * Revision 1.1  1999/09/23 00:09:14  eric
 * Initial checkin
 *
 *
 */

/* do hex2binary on blocks of data, where we stored the blocks of data
 * in big endian format before hand, e.g., it may be stuff we did using
 * the mpz_t stuff or generated using the dorandom() function.
 */

unsigned int unhexnib(unsigned char hexchar);

unsigned char *hexify_block( unsigned char *resultbuf, int length );
unsigned char *unhexify_block(unsigned char *str, int length);


