/* Copyright 2000 Enhanced Software Technologies Inc.
   All Rights Reserved

   dorandom.h -- read /dev/urandom.

RCS CHANGE LOG:
$Log: dorandom.h,v $
Revision 1.1.1.1  2001/05/17 17:11:01  elgreen
Initial checkin

Revision 1.3  2000/04/24 19:46:57  eric
More autoconf tweaks. Changed to using Counterpane's TwoFish rather than
Dr. Gladman's TwoFish in an attempt to fix the big endian/little endian
problems once and for all.

Revision 1.1  2000/03/28 23:54:28  eric
Initial checkin -- aescrypt/aesget

$Date: 2001/05/17 17:11:01 $

*/

#ifndef DO_RANDOM_H
#define DO_RANDOM_H 1

#define URAND_NAME "/dev/urandom"

int urand_seed(char * filename);  /* NULL for /dev/urandom  */
char *urand_get(int numbytes);

#endif
