/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */
#include <stdio.h>

#define __USE_BSD
#include <string.h>

#include "hasher/hasher.h"

const char
*E_no_hash = "No hash algorithm specified\n",
*E_no_hash_yet = "File argument found, but no hash algorithm yet specified\n",
*E_fopen_fail = "Could not open file %s\n",
*E_error_read = "%s: error reading %s\n",
*E_blank = "";

int misuse(int argL, char *arg[],
           const char *msg) {
  printf("Usage: %s -a <algorithm> [file1 file2 ...]\n"
         "\n"
         "ERROR: %s" /* these have their own \n */
         "\n"
         "Currently supported message digest (hash) algorithms:\n"
         " Name: sha-1  sha-256  sha-384  sha-512  ripemd-160  md5*\n"
         " Size:   160      256      384      512         160  128\n"
         "  *note: any 128bit hash algorithm is no longer secure\n"
         "\n"
         "Wrappers exist for specific algoritms:\n"
         " sha1sum       (hashsum -a sha-1)\n"
         "     pronounced \"sh ya want some\"\n"
         " sha256sum       (hashsum -a sha-256)\n"
         "     unpronouceble\n"
         " sha384sum       (hashsum -a sha-382)\n"
         "     unpronouceble\n"
         " sha512sum       (hashsum -a sha-512)\n"
         "     unpronouceble\n"
         " ripemd160sum  (hashsum -a ripemd-160)\n"
         "     unpronouceble\n"
         " md5sum        (hashsum -a md5)\n"
         "     pronouced \"don't use it if you know what's good for ya\"\n"
         "\n"
         "       --help   Detailed help\n", arg[0], msg);
  return 1;
}

#define READ_SIZE 1024
int hashsum_file(FILE *file, const char *path, const char *app,
                 hasher_t *h, char **msg) {
  char buf[READ_SIZE],
       D[HASHER_MAX_DIGEST_SIZE * sizeof(uns32)];
  int read_len,
      i;

  if (file == NULL) {
    *msg = (char*) malloc(strlen(E_fopen_fail) +strlen(path));
    sprintf(*msg, E_fopen_fail, path);
    return 1;
  }

  h->init(h);
  do {
    read_len = fread(buf, 1, READ_SIZE, file);
    h->update(h, buf, read_len);
  } while (read_len == READ_SIZE);
  h->final(h, D);

  if (ferror(file)) {
    *msg = (char*) malloc(strlen(E_error_read) +strlen(app) +strlen(path));
    sprintf(*msg, E_error_read, app, path);
    return 2;
  }

  for (i=0; i<h->len; i++)
    printf("%.2x", D[i]&0xff);
  printf("  %s\n", path);

  fclose(file);
  return 0;
}
#undef READ_SIZE

#define WRAPPER(NAME,ALGO)\
  if (strlen(NAME) <= strlen(arg[0])) {\
    if (strcmp(NAME, &arg[0][strlen(arg[0])-strlen(NAME)]) == 0) {\
      algostr = ALGO;\
      if (hasher_setup(&H, algostr) != HASHER_OK)\
        return misuse(argL, arg, hasher_ret_msg(H.err));\
    }\
  }

#define CHECK_ALGO()\
{\
  if (algostr == NULL)\
    return misuse(argL, arg, E_no_hash_yet);\
  if (strcmp(algostr, "md5") == 0)\
    fprintf(stderr, "md5 is not secure.  Refer to van Oorschot's paper:\n"\
                    "  http://www.rsasecurity.com/rsalabs/faq/3-6-6.html\n");\
}\

int main(int argL, char *arg[]) {
  hasher_t H;
  char *algostr=NULL;
  char *msg;
  char *modestr;
  int i,
      done_a_file=0;

  modestr = (char*) malloc(4);
  strcpy(modestr, "r");

  WRAPPER("sha1sum", "sha-1")
  WRAPPER("sha256sum", "sha-256")
  WRAPPER("sha384sum", "sha-384")
  WRAPPER("sha512sum", "sha-512")
  WRAPPER("ripemd160sum", "ripemd-160")
  WRAPPER("md5sum", "md5")

  for (i=1; i<argL; i++) {
    if (arg[i][0] == '-') { /* option */
      if (argL < (i+1))
        return misuse(argL, arg, E_no_hash);
      if (strcmp(arg[i], "-a") == 0) {
        algostr = arg[++i];
        if (hasher_setup(&H, algostr) != HASHER_OK)
          return misuse(argL, arg, hasher_ret_msg(H.err));
      }
      else if (strcmp(arg[i], "-b") == 0) {
        strcpy(modestr, "rb");
      }
    }
    else if (arg[i][0] != '-') { /* file */
      CHECK_ALGO();
      if (hashsum_file(fopen(arg[i], modestr), arg[i], arg[0], &H, &msg))
        fprintf(stderr, msg);
      done_a_file = 1;
    }
  }

  CHECK_ALGO();
  if (!done_a_file)
    if (hashsum_file(stdin, "", arg[0], &H, &msg))
      return misuse(argL, arg, msg);

  hasher_teardown(&H);

  return 0;
}
