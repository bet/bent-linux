/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#ifndef RIPMEMD160S_C
#define RIPMEMD160S_C

static const uns32 ripemd160_perm_const[2][5] = {
{0x00000000UL, 0x5a827999UL, 0x6ed9eba1UL, 0x8f1bbcdcUL, 0xa953fd4eUL},
{0x50a28be6UL, 0x5c4dd124UL, 0x6d703ef3UL, 0x7a6d76e9UL, 0x00000000UL}
};
static const uns8 ripemd160_perm_shift[5][16] = {
{11,14,15,12, 5, 8, 7, 9,11,13,14,15, 6, 7, 9, 8},
{12,13,11,15, 6, 9, 9, 7,12,15,11,13, 7, 8, 7, 7},
{13,15,14,11, 7, 7, 6, 8,13,14,13,12, 5, 5, 6, 9},
{14,11,12,14, 8, 6, 5, 5,15,12,15,14, 9, 9, 8, 6},
{15,12,13,13, 9, 5, 8, 6,14,11,12,11, 8, 6, 5, 5}
};
static const uns8 ripemd160_perm_p[16] = {7,4,13,1,10,6,15,3,12,0,9,5,2,14,11,8};
#define ripemd160_perm_pi(ii)  ( (9*ii + 5) & 0xf )

static uns32 ripemd160_perm_bool(uns32 x, uns32 y, uns32 z, int round) {
  uns32 r;

  if      (round==0) r=F(x,y,z);
  else if (round==1) r=G(x,y,z);
  else if (round==2) r=H(x,y,z);
  else if (round==3) r=I(x,y,z);
  else               r=J(x,y,z);

  return r;
}

static int ripemd160_perm_pos(int round, int curr_pos, int l_or_r) {
  if (l_or_r)
    curr_pos = ripemd160_perm_pi(curr_pos);

  if (round==4) curr_pos = ripemd160_perm_p[curr_pos];
  if (round>=3) curr_pos = ripemd160_perm_p[curr_pos];
  if (round>=2) curr_pos = ripemd160_perm_p[curr_pos];
  if (round>=1) curr_pos = ripemd160_perm_p[curr_pos];

  return curr_pos;
}
#endif
