/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

/*! reference: http://csrc.nist.gov/encryption/shs/dfips-180-2.pdf */

#ifndef SHA384_H
#define SHA384_H

#include "hashcom.h"
#include "sha512.h"

#ifndef SHA384_SMALL
  #define SHA384_SMALL   0  /* low footprint sha-384 */
#endif

#define SHA384_DIGEST_SIZE   (6*sizeof(uns64))

typedef struct {
  uns64 state[8];
  uns8 buf[128];
  uns32 count[4];
} sha384_context;

#ifdef __cplusplus
extern "C" {
#endif

#ifdef WIN32
 #ifdef CRYPTO_EXPORTS
   #define extern   extern __declspec(dllexport)
 #else
   #define extern   extern __declspec(dllimport)
 #endif
#endif

extern void sha384_init(sha384_context *c);
extern void sha384_update(sha384_context *c, uns8 *input, unsigned int inLen);
extern void sha384_final(uns8 *digest, sha384_context *c);

#ifdef __cplusplus
}
#endif

#ifdef WIN32
  #undef extern
#endif

/*
sha384(abc) = cb00753f45a35e8bb5a03d699ac65007272c32ab0eded1631a8b605a43ff5bed8086072ba1e7cc2358baeca134c825a7
*/

#endif
