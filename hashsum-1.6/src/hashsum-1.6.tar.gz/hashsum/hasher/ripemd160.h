/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#ifndef  RIPEMD160_H
#define  RIPEMD160_H

/*! reference: http://www.esat.kuleuven.ac.be/~bosselae/ripemd160.html */

#include "hashcom.h"

#ifndef RIPEMD160_SMALL
  #define RIPEMD160_SMALL   0 /* Low footprint ripemd-160 */
#endif

#define RIPEMD160_DIGEST_SIZE    20

typedef struct {
  uns32 state[5];
  uns32 count[2];
  uns8 buf[64];
} ripemd160_context;

#ifdef __cplusplus
extern "C" {
#endif

#ifdef WIN32
 #ifdef CRYPTO_EXPORTS
   #define extern   extern __declspec(dllexport)
 #else
   #define extern   extern __declspec(dllimport)
 #endif
#endif

extern void ripemd160_init(ripemd160_context *CTX);
extern void ripemd160_update(ripemd160_context *CTX, uns8 *input, unsigned int inLen);
extern void ripemd160_final(uns8 *digest, ripemd160_context *CTX);

#ifdef __cplusplus
}
#endif

#ifdef WIN32
  #undef extern
#endif

#endif
