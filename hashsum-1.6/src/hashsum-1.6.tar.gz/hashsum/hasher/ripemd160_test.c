/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#include "ripemd160.h"
#include "stdio.h"

const uns8 ans0[RIPEMD160_DIGEST_SIZE] = {0x9c, 0x11, 0x85, 0xa5, 0xc5, 0xe9, 0xfc, 0x54, 0x61, 0x28, 0x08, 0x97, 0x7e, 0xe8, 0xf5, 0x48, 0xb2, 0x25, 0x8d, 0x31};
const uns8 ans[RIPEMD160_DIGEST_SIZE] = {0x8e, 0xb2, 0x08, 0xf7, 0xe0, 0x5d, 0x98, 0x7a, 0x9b, 0x04, 0x4a, 0x8e, 0x98, 0xc6, 0xb0, 0x87, 0xf1, 0x5a, 0x0b, 0xfc};
const uns8 ans2[RIPEMD160_DIGEST_SIZE] = {0x5d, 0x06, 0x89, 0xef, 0x49, 0xd2, 0xfa, 0xe5, 0x72, 0xb8, 0x81, 0xb1, 0x23, 0xa8, 0x5f, 0xfa, 0x21, 0x59, 0x5f, 0x36};
const uns8 ans3[RIPEMD160_DIGEST_SIZE] = {0x52, 0x78, 0x32, 0x43, 0xc1, 0x69, 0x7b, 0xdb, 0xe1, 0x6d, 0x37, 0xf9, 0x7f, 0x68, 0xf0, 0x83, 0x25, 0xdc, 0x15, 0x28};

int main() {
  char *test = "abc";
  char *test2 = "message digest";
  uns8 D[RIPEMD160_DIGEST_SIZE];
  ripemd160_context CTX;
  int i;

  printf("ripemd160(%s)\n", "");
  /* strlen < 56 */
  ripemd160_init(&CTX);
  ripemd160_final(D, &CTX);
  printf("D   = "); for (i=0; i<20; i++) printf("%.2x ", D[i]); printf("\n");
  printf("ans0= "); for (i=0; i<20; i++) printf("%.2x ", 0xff&ans0[i]); printf("\n");

  printf("ripemd160(%s)\n", test);
  /* strlen < 56 */
  ripemd160_init(&CTX);
  ripemd160_update(&CTX, (uns8*)test, strlen(test));
  ripemd160_final(D, &CTX);

  printf("D  = "); for (i=0; i<20; i++) printf("%.2x ", D[i]); printf("\n");
  printf("ans= "); for (i=0; i<20; i++) printf("%.2x ", 0xff&ans[i]); printf("\n");

  printf("ripemd160(%s)\n", test2);
  /* strlen == 56 */
  ripemd160_init(&CTX);
  ripemd160_update(&CTX, (uns8*)test2, strlen(test2));
  ripemd160_final(D, &CTX);

  printf("D   = "); for (i=0; i<20; i++) printf("%.2x ", D[i]); printf("\n");
  printf("ans2= "); for (i=0; i<20; i++) printf("%.2x ", 0xff&ans2[i]); printf("\n");

  printf("ripemd160(1,000,000 x 'a')\n");
  ripemd160_init(&CTX);
  for (i=0; i<1000*1000; i++)
    ripemd160_update(&CTX, (uns8*)"a", 1);
  ripemd160_final(D, &CTX);
  
  printf("D   = "); for (i=0; i<20; i++) printf("%.2x ", D[i]); printf("\n");
  printf("ans3= "); for (i=0; i<20; i++) printf("%.2x ", 0xff&ans3[i]); printf("\n");

  return 0;
}
