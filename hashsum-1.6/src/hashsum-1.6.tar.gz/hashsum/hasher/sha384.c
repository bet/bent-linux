/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#include "sha384.h"

#define Ch(x,y,z)   ((x & y) ^ (~x & z))
#define Maj(x,y,z)  ((x & y) ^ (x & z) ^ (y & z))
#define e0(x)       (RORuns64(x,28) ^ RORuns64(x,34) ^ RORuns64(x,39))
#define e1(x)       (RORuns64(x,14) ^ RORuns64(x,18) ^ RORuns64(x,41))
#define s0(x)       (RORuns64(x,1)  ^ RORuns64(x,8)  ^ (x >> 7))
#define s1(x)       (RORuns64(x,19) ^ RORuns64(x,61) ^ (x >> 6))

#define H0         0xcbbb9d5dc1059ed8LL
#define H1         0x629a292a367cd507LL
#define H2         0x9159015a3070dd17LL
#define H3         0x152fecd8f70e5939LL
#define H4         0x67332667ffc00b31LL
#define H5         0x8eb44a8768581511LL
#define H6         0xdb0c2e0d64f98fa7LL
#define H7         0x47b5481dbefa4fa4LL

extern void sha512_xform(uns64 *state, const uns8 *input);

#if SHA384_BASIC_API
void sha384_init(sha384_context *C) {
  C->state[0] = H0;
  C->state[1] = H1;
  C->state[2] = H2;
  C->state[3] = H3;
  C->state[4] = H4;
  C->state[5] = H5;
  C->state[6] = H6;
  C->state[7] = H7;
  C->count[0] = C->count[1] = C->count[2] = C->count[3] = 0;
  memset(C->buf, 0, 128);
}

void sha384_update(sha384_context *C, uns8 *input, unsigned int inputLen) {
  uns32 i, index, partLen;

  /* Compute number of bytes mod 128 */
  index = (uns32)((C->count[0] >> 3) & 0x7F);

  /* Update number of bits */
  if ((C->count[0] += (inputLen << 3)) < (inputLen << 3)) {
    if ((C->count[1] += 1) < 1)
      if ((C->count[2] += 1) < 1)
        C->count[3]++;
    C->count[1] += (inputLen >> 29);
  }

  partLen = 128 - index;

  /* Transform as many times as possible. */
  if (inputLen >= partLen) {
    memcpy((uns8*)&C->buf[index], input, partLen);
    sha512_xform(C->state, C->buf);

    for (i=partLen; i+127<inputLen; i+=128)
      sha512_xform(C->state, &input[i]);

    index = 0;
  } else {
    i = 0;
  }

  /* Buffer remaining input */
  memcpy((uns8*)&C->buf[index], (uns8*)&input[i], inputLen-i);
}

void sha384_final(uns8 *digest, sha384_context *C) {
  uns8 bits[128];
  uns32 index, padLen;
  uns32 t;
  uns64 t2;
  int i,j;

  memset(bits, 0, 128);
  
  /* Save number of bits */
  t = C->count[0];
  bits[15] = t; t>>=8;
  bits[14] = t; t>>=8;
  bits[13] = t; t>>=8;
  bits[12] = t; t>>=8;
  t = C->count[1];
  bits[11] = t; t>>=8;
  bits[10] = t; t>>=8;
  bits[9 ] = t; t>>=8;
  bits[8 ] = t; t>>=8;
  t = C->count[2];
  bits[7 ] = t; t>>=8;
  bits[6 ] = t; t>>=8;
  bits[5 ] = t; t>>=8;
  bits[4 ] = t; t>>=8;
  t = C->count[3];
  bits[3 ] = t; t>>=8;
  bits[2 ] = t; t>>=8;
  bits[1 ] = t; t>>=8;
  bits[0 ] = t; t>>=8;

  /* Pad out to 112 mod 128. */
  index = (C->count[0] >> 3) & 0x7f;
  padLen = (index < 112) ? (112 - index) : ((128+112) - index);
  sha384_update(C, (uns8*)hashcom_PADDING, padLen);

  /* Append length (before padding) */
  sha384_update(C, bits, 16);

  /* Store state in digest */
  for (i=j=0; i<6; i++,j+=8) {
    t2 = C->state[i];
    digest[j+7] = (char)t2 & 0xff; t2>>=8;
    digest[j+6] = (char)t2 & 0xff; t2>>=8;
    digest[j+5] = (char)t2 & 0xff; t2>>=8;
    digest[j+4] = (char)t2 & 0xff; t2>>=8;
    digest[j+3] = (char)t2 & 0xff; t2>>=8;
    digest[j+2] = (char)t2 & 0xff; t2>>=8;
    digest[j+1] = (char)t2 & 0xff; t2>>=8;
    digest[j  ] = (char)t2 & 0xff;
  }

  /* Zeroize sensitive information. */
  memset(C, 0, sizeof(sha384_context));
}
#endif
