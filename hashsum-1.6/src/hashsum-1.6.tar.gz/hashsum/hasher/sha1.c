/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#include "sha1.h"

#define f1(b,c,d)   ((b & c) | (~b & d))
#define f2(b,c,d)   (b ^ c ^ d)
#define f3(b,c,d)   ((b & c) | (b & d) | (c & d))
#define f4(b,c,d)   (b ^ c ^ d)
#define K1          0x5A827999
#define K2          0x6ED9EBA1
#define K3          0x8F1BBCDC
#define K4          0xCA62C1D6

#define ROL1(a)   ( (a<<1) | (a>>31) )
#define ROL5(a)   ( (a<<5) | (a>>27) )
#define ROL30(a)  ( (a<<30) | (a>>2) )

#if SHA1_SMALL
  #include "sha1s.c"
#else
  #define UNFOLD 1
#endif

void sha1_xform(uns32 *state, uns8 *input) {
  int i;
  uns32 t;
  uns32 W[80],
        A,B,C,D,E;

  for (i=0; i<16; i++) {
    t  = input[4*i  ]; t <<= 8;
    t |= input[4*i+1]; t <<= 8;
    t |= input[4*i+2]; t <<= 8;
    t |= input[4*i+3];
    W[i] = t;
  }

#if SHA1_SMALL
  for (i=16; i<80; i++) {
    t = W[i-3] ^ W[i-8] ^ W[i-14] ^ W[i-16];   W[i] = ROL1(t);
  }

  A=state[0];   B=state[1];   C=state[2];   D=state[3];   E=state[4];  

  for (i=0; i<80; i++) {
    t = ROL5(A) + sha1_perm_bool(B,C,D,i/20) + E + W[i] + sha1_perm_const[i/20];
    E = D; D = C;
    C = ROL30(B);
    B = A; A = t;
  }
#else
  for (i=16; i<80; i+=4) {
    t = W[i-3] ^ W[i-8] ^ W[i-14] ^ W[i-16];   W[i  ] = ROL1(t);
    t = W[i-2] ^ W[i-7] ^ W[i-13] ^ W[i-15];   W[i+1] = ROL1(t);
    t = W[i-1] ^ W[i-6] ^ W[i-12] ^ W[i-14];   W[i+2] = ROL1(t);
    t = W[i  ] ^ W[i-5] ^ W[i-11] ^ W[i-13];   W[i+3] = ROL1(t);
  }

  A=state[0];   B=state[1];   C=state[2];   D=state[3];   E=state[4];  

/* round 1 */
  E = ROL5(A) + f1(B,C,D) + E + W[ 0] + K1; B=ROL30(B);
  D = ROL5(E) + f1(A,B,C) + D + W[ 1] + K1; A=ROL30(A);
  C = ROL5(D) + f1(E,A,B) + C + W[ 2] + K1; E=ROL30(E);
  B = ROL5(C) + f1(D,E,A) + B + W[ 3] + K1; D=ROL30(D);
  A = ROL5(B) + f1(C,D,E) + A + W[ 4] + K1; C=ROL30(C);
  E = ROL5(A) + f1(B,C,D) + E + W[ 5] + K1; B=ROL30(B);
  D = ROL5(E) + f1(A,B,C) + D + W[ 6] + K1; A=ROL30(A);
  C = ROL5(D) + f1(E,A,B) + C + W[ 7] + K1; E=ROL30(E);
  B = ROL5(C) + f1(D,E,A) + B + W[ 8] + K1; D=ROL30(D);
  A = ROL5(B) + f1(C,D,E) + A + W[ 9] + K1; C=ROL30(C);
  E = ROL5(A) + f1(B,C,D) + E + W[10] + K1; B=ROL30(B);
  D = ROL5(E) + f1(A,B,C) + D + W[11] + K1; A=ROL30(A);
  C = ROL5(D) + f1(E,A,B) + C + W[12] + K1; E=ROL30(E);
  B = ROL5(C) + f1(D,E,A) + B + W[13] + K1; D=ROL30(D);
  A = ROL5(B) + f1(C,D,E) + A + W[14] + K1; C=ROL30(C);
  E = ROL5(A) + f1(B,C,D) + E + W[15] + K1; B=ROL30(B);
  D = ROL5(E) + f1(A,B,C) + D + W[16] + K1; A=ROL30(A);
  C = ROL5(D) + f1(E,A,B) + C + W[17] + K1; E=ROL30(E);
  B = ROL5(C) + f1(D,E,A) + B + W[18] + K1; D=ROL30(D);
  A = ROL5(B) + f1(C,D,E) + A + W[19] + K1; C=ROL30(C);
/* round 2 */
  E = ROL5(A) + f2(B,C,D) + E + W[20] + K2; B=ROL30(B);
  D = ROL5(E) + f2(A,B,C) + D + W[21] + K2; A=ROL30(A);
  C = ROL5(D) + f2(E,A,B) + C + W[22] + K2; E=ROL30(E);
  B = ROL5(C) + f2(D,E,A) + B + W[23] + K2; D=ROL30(D);
  A = ROL5(B) + f2(C,D,E) + A + W[24] + K2; C=ROL30(C);
  E = ROL5(A) + f2(B,C,D) + E + W[25] + K2; B=ROL30(B);
  D = ROL5(E) + f2(A,B,C) + D + W[26] + K2; A=ROL30(A);
  C = ROL5(D) + f2(E,A,B) + C + W[27] + K2; E=ROL30(E);
  B = ROL5(C) + f2(D,E,A) + B + W[28] + K2; D=ROL30(D);
  A = ROL5(B) + f2(C,D,E) + A + W[29] + K2; C=ROL30(C);
  E = ROL5(A) + f2(B,C,D) + E + W[30] + K2; B=ROL30(B);
  D = ROL5(E) + f2(A,B,C) + D + W[31] + K2; A=ROL30(A);
  C = ROL5(D) + f2(E,A,B) + C + W[32] + K2; E=ROL30(E);
  B = ROL5(C) + f2(D,E,A) + B + W[33] + K2; D=ROL30(D);
  A = ROL5(B) + f2(C,D,E) + A + W[34] + K2; C=ROL30(C);
  E = ROL5(A) + f2(B,C,D) + E + W[35] + K2; B=ROL30(B);
  D = ROL5(E) + f2(A,B,C) + D + W[36] + K2; A=ROL30(A);
  C = ROL5(D) + f2(E,A,B) + C + W[37] + K2; E=ROL30(E);
  B = ROL5(C) + f2(D,E,A) + B + W[38] + K2; D=ROL30(D);
  A = ROL5(B) + f2(C,D,E) + A + W[39] + K2; C=ROL30(C);
/* round 4*/
  E = ROL5(A) + f3(B,C,D) + E + W[40] + K3; B=ROL30(B);
  D = ROL5(E) + f3(A,B,C) + D + W[41] + K3; A=ROL30(A);
  C = ROL5(D) + f3(E,A,B) + C + W[42] + K3; E=ROL30(E);
  B = ROL5(C) + f3(D,E,A) + B + W[43] + K3; D=ROL30(D);
  A = ROL5(B) + f3(C,D,E) + A + W[44] + K3; C=ROL30(C);
  E = ROL5(A) + f3(B,C,D) + E + W[45] + K3; B=ROL30(B);
  D = ROL5(E) + f3(A,B,C) + D + W[46] + K3; A=ROL30(A);
  C = ROL5(D) + f3(E,A,B) + C + W[47] + K3; E=ROL30(E);
  B = ROL5(C) + f3(D,E,A) + B + W[48] + K3; D=ROL30(D);
  A = ROL5(B) + f3(C,D,E) + A + W[49] + K3; C=ROL30(C);
  E = ROL5(A) + f3(B,C,D) + E + W[50] + K3; B=ROL30(B);
  D = ROL5(E) + f3(A,B,C) + D + W[51] + K3; A=ROL30(A);
  C = ROL5(D) + f3(E,A,B) + C + W[52] + K3; E=ROL30(E);
  B = ROL5(C) + f3(D,E,A) + B + W[53] + K3; D=ROL30(D);
  A = ROL5(B) + f3(C,D,E) + A + W[54] + K3; C=ROL30(C);
  E = ROL5(A) + f3(B,C,D) + E + W[55] + K3; B=ROL30(B);
  D = ROL5(E) + f3(A,B,C) + D + W[56] + K3; A=ROL30(A);
  C = ROL5(D) + f3(E,A,B) + C + W[57] + K3; E=ROL30(E);
  B = ROL5(C) + f3(D,E,A) + B + W[58] + K3; D=ROL30(D);
  A = ROL5(B) + f3(C,D,E) + A + W[59] + K3; C=ROL30(C);
/* round 4 */
  E = ROL5(A) + f4(B,C,D) + E + W[60] + K4; B=ROL30(B);
  D = ROL5(E) + f4(A,B,C) + D + W[61] + K4; A=ROL30(A);
  C = ROL5(D) + f4(E,A,B) + C + W[62] + K4; E=ROL30(E);
  B = ROL5(C) + f4(D,E,A) + B + W[63] + K4; D=ROL30(D);
  A = ROL5(B) + f4(C,D,E) + A + W[64] + K4; C=ROL30(C);
  E = ROL5(A) + f4(B,C,D) + E + W[65] + K4; B=ROL30(B);
  D = ROL5(E) + f4(A,B,C) + D + W[66] + K4; A=ROL30(A);
  C = ROL5(D) + f4(E,A,B) + C + W[67] + K4; E=ROL30(E);
  B = ROL5(C) + f4(D,E,A) + B + W[68] + K4; D=ROL30(D);
  A = ROL5(B) + f4(C,D,E) + A + W[69] + K4; C=ROL30(C);
  E = ROL5(A) + f4(B,C,D) + E + W[70] + K4; B=ROL30(B);
  D = ROL5(E) + f4(A,B,C) + D + W[71] + K4; A=ROL30(A);
  C = ROL5(D) + f4(E,A,B) + C + W[72] + K4; E=ROL30(E);
  B = ROL5(C) + f4(D,E,A) + B + W[73] + K4; D=ROL30(D);
  A = ROL5(B) + f4(C,D,E) + A + W[74] + K4; C=ROL30(C);
  E = ROL5(A) + f4(B,C,D) + E + W[75] + K4; B=ROL30(B);
  D = ROL5(E) + f4(A,B,C) + D + W[76] + K4; A=ROL30(A);
  C = ROL5(D) + f4(E,A,B) + C + W[77] + K4; E=ROL30(E);
  B = ROL5(C) + f4(D,E,A) + B + W[78] + K4; D=ROL30(D);
  A = ROL5(B) + f4(C,D,E) + A + W[79] + K4; C=ROL30(C);
#endif /* SHA1_SMALL */

  state[0]+=A;   state[1]+=B;   state[2]+=C;   state[3]+=D;   state[4]+=E;  
}

#if SHA1_BASIC_API
void sha1_init(sha1_context *c) {
  c->state[0] = 0x67452301;
  c->state[1] = 0xEFCDAB89;
  c->state[2] = 0x98BADCFE;
  c->state[3] = 0x10325476;
  c->state[4] = 0xC3D2E1F0;
  c->count[1] = c->count[0] = 0;
}

void sha1_update(sha1_context *C, uns8 *input, unsigned int inputLen) {
  uns32 i, index, partLen;

  /* Compute number of bytes mod 64 */
  index = (uns32)((C->count[0] >> 3) & 0x3F);

  /* Update number of bits */
  if ((C->count[0] += (inputLen << 3)) < (inputLen << 3)) {
    C->count[1]++;
    C->count[1] += (inputLen >> 29);
  }

  partLen = 64 - index;

  /* Transform as many times as possible. */
  if (partLen <= inputLen) {
    memcpy((uns8*)&C->buf[index], input, partLen);
    sha1_xform(C->state, (uns8*)C->buf);

    for (i=partLen; i+63<inputLen; i+=64)
      sha1_xform(C->state, &input[i]);

    index = 0;
  } else {
    i = 0;
  }

  /* Buffer remaining input */
  memcpy((uns8*)&C->buf[index], (uns8*)&input[i], inputLen-i);
}

void sha1_final(uns8 *digest, sha1_context *C) {
  uns8 bits[8];
  uns32 index, padLen, t;
  int i,j;

  /* Save number of bits */
  t = C->count[0];
  bits[7] = t; t>>=8;
  bits[6] = t; t>>=8;
  bits[5] = t; t>>=8;
  bits[4] = t;
  t = C->count[1];
  bits[3] = t; t>>=8;
  bits[2] = t; t>>=8;
  bits[1] = t; t>>=8;
  bits[0] = t;

  /* Pad out to 56 mod 64. */
  index = (C->count[0] >> 3) & 0x3f;
  padLen = (index < 56) ? (56 - index) : ((64+56) - index);
  sha1_update(C, (uns8*)hashcom_PADDING, padLen);

  /* Append length (before padding) */
  sha1_update(C, bits, 8);

  /* Store state in digest */
  for (i=j=0; i<5; i++,j+=4) {
    t = C->state[i];
    digest[j+3] = t; t>>=8;
    digest[j+2] = t; t>>=8;
    digest[j+1] = t; t>>=8;
    digest[j  ] = t;
  }

  /* Zeroize sensitive information. */
  memset(C, 0, sizeof(sha1_context));
}
#endif
