/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#include "hasher.h"

const int hasher_lengths[CRYPTO_HASH_COUNT][2] = {
  {CRYPTO_HASH_MD5, MD5_DIGEST_SIZE},
  {CRYPTO_HASH_SHA1, SHA1_DIGEST_SIZE},
  {CRYPTO_HASH_RIPEMD160, RIPEMD160_DIGEST_SIZE},
  {CRYPTO_HASH_SHA512, SHA512_DIGEST_SIZE},
  {CRYPTO_HASH_SHA384, SHA384_DIGEST_SIZE},
  {CRYPTO_HASH_SHA256, SHA256_DIGEST_SIZE},
};

hasher_retcode hasher_setup(hasher_t *H, const char *algostr) {
  int i;
  hasher_retcode ret = HASHER_BAD_HASH_ALGO;
  hash_t algo;

  algo = crypto_hash_name_rev(algostr);
  
  memset(H, 0, sizeof(hasher_t));
  
  H->len = 0;
  for (i=0; i<CRYPTO_HASH_COUNT; i++) {
    if (hasher_lengths[i][0] == algo) {
      H->len = hasher_lengths[i][1];
      break;
    }
  }
  if (H->len == 0)
    return H->err = HASHER_BAD_HASH_ALGO;

  H->algo = algo;

  H->init = (void (*)(void*)) hasher_init;
  H->update = (void (*)(void*,const uns8*,uns32)) hasher_update;
  H->final = (void (*)(void*,uns8*)) hasher_final;

  switch (algo) {
    case CRYPTO_HASH_MD5:
      H->init_ = (void(*)(void*)) md5_init;
      H->update_ = (void(*)(void*,const uns8*,uns32)) md5_update;
      H->final_ = (void(*)(uns8*,void*)) md5_final;
      ret = HASHER_OK;
      break;
    case CRYPTO_HASH_SHA1:
      H->init_ = (void(*)(void*)) sha1_init;
      H->update_ = (void(*)(void*,const uns8*,uns32)) sha1_update;
      H->final_ = (void(*)(uns8*,void*)) sha1_final;
      ret = HASHER_OK;
      break;
    case CRYPTO_HASH_RIPEMD160:
      H->init_ = (void(*)(void*)) ripemd160_init;
      H->update_ = (void(*)(void*,const uns8*,uns32)) ripemd160_update;
      H->final_ = (void(*)(uns8*,void*)) ripemd160_final;
      ret = HASHER_OK;
      break;
    case CRYPTO_HASH_SHA512:
      H->init_ = (void(*)(void*)) sha512_init;
      H->update_ = (void(*)(void*,const uns8*,uns32)) sha512_update;
      H->final_ = (void(*)(uns8*,void*)) sha512_final;
      ret = HASHER_OK;
      break;
    case CRYPTO_HASH_SHA384:
      H->init_ = (void(*)(void*)) sha384_init;
      H->update_ = (void(*)(void*,const uns8*,uns32)) sha512_update;
      H->final_ = (void(*)(uns8*,void*)) sha384_final;
      ret = HASHER_OK;
      break;
    case CRYPTO_HASH_SHA256:
      H->init_ = (void(*)(void*)) sha256_init;
      H->update_ = (void(*)(void*,const uns8*,uns32)) sha256_update;
      H->final_ = (void(*)(uns8*,void*)) sha256_final;
      ret = HASHER_OK;
      break;
    default:
      H->init = NULL;
      H->update = NULL;
      H->final = NULL;
      H->ctx = NULL;
      H->algo = CRYPTO_HASH_NONE;
      H->len = 0;
      return H->err = HASHER_BAD_HASH_ALGO;
      break;
  }

  H->ctx = malloc(HASHER_MAX_CTX_SIZE);

  return H->err = ret;
}

void hasher_init(hasher_t *H) { H->err = HASHER_OK; H->init_(H->ctx); }
void hasher_update(hasher_t *H, const uns8 *data, uns32 len) { H->update_(H->ctx, data, len); }
void hasher_final(hasher_t *H, uns8 *d) { H->final_(d, H->ctx); }

hasher_retcode hasher_teardown(hasher_t *H) {
  hasher_retcode ret = HASHER_OK;

  if (H->init == NULL) ret = HASHER_NULL_POINTER;
  else                 H->init = NULL;
  if (H->update == NULL) ret = HASHER_NULL_POINTER;
  else                   H->update = NULL;
  if (H->final == NULL) ret = HASHER_NULL_POINTER;
  else                  H->final = NULL;
  if (H->ctx == NULL) ret = HASHER_NULL_POINTER;
  else                { ck_free(H->ctx, HASHER_MAX_CTX_SIZE); }
  H->len = 0;
  H->algo = CRYPTO_HASH_NONE;

  return H->err = ret;
}

const char* hasher_ret_msg(hasher_retcode c) {
  switch (c) {
    case HASHER_OK:            return "OK";
    case HASHER_BAD_HASH_ALGO: return "Bad Hash Algorithm";
    case HASHER_NULL_POINTER:  return "Null Pointer Error";
  }
  return "Unknown Error Code";
}
