/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

/*! reference: http://csrc.nist.gov/encryption/shs/dfips-180-2.pdf */

#ifndef SHA512_H
#define SHA512_H

#include "hashcom.h"

#ifndef SHA512_SMALL
  #define SHA512_SMALL   0  /* low footprint sha-512 */
#endif

#define SHA512_DIGEST_SIZE   (8*sizeof(uns64))

typedef struct {
  uns64 state[8];
  uns8 buf[128];
  uns32 count[4];
} sha512_context;

#ifdef __cplusplus
extern "C" {
#endif

#ifdef WIN32
 #ifdef CRYPTO_EXPORTS
   #define extern   extern __declspec(dllexport)
 #else
   #define extern   extern __declspec(dllimport)
 #endif
#endif

extern void sha512_init(sha512_context *c);
extern void sha512_update(sha512_context *c, uns8 *input, unsigned int inLen);
extern void sha512_final(uns8 *digest, sha512_context *c);

#ifdef __cplusplus
}
#endif

#ifdef WIN32
  #undef extern
#endif

/*
sha512(abc) = ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f
*/

#endif
