/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#ifndef HASHER_H
#define HASHER_H

#include <string.h>
#include <stdlib.h>

#include "sha256.h"
#include "sha384.h"
#include "sha512.h"
#include "sha1.h"
#include "md5.h"
#include "ripemd160.h"

/*! Incase we have any C++ users...tisk tisk
*/
#ifdef __cplusplus
extern "C" {
#endif

/*! Incase we have any windows users wanting a DLL
*/
#ifdef WIN32
 #ifdef CRYPTO_EXPORTS
   #define extern   extern __declspec(dllexport)
 #else
   #define extern   extern __declspec(dllimport)
 #endif
#endif

/*! Array of digest lengths
* @see hash_t
*/
extern const int hasher_lengths[CRYPTO_HASH_COUNT][2];

/*!
*/
#define HASHER_MAX_DIGEST_SIZE\
  ( max(\
     max(\
      SHA256_DIGEST_SIZE,\
      SHA384_DIGEST_SIZE\
     ),\
     max(\
      max(\
       RIPEMD160_DIGEST_SIZE,\
       MD5_DIGEST_SIZE\
      ),\
      max(\
       SHA1_DIGEST_SIZE,\
       SHA512_DIGEST_SIZE\
      )\
     )\
    )\
  )
#define HASHER_MAX_CTX_SIZE\
  ( max(\
     max(\
      sizeof(sha256_context),\
      sizeof(sha384_context)\
     ),\
     max(\
      max(\
       sizeof(ripemd160_context),\
       sizeof(md5_context)\
      ),\
      max(\
       sizeof(sha512_context),\
       sizeof(sha1_context)\
      )\
     )\
    )\
  )

typedef enum {
  HASHER_OK,
  HASHER_BAD_HASH_ALGO,
  HASHER_NULL_POINTER
} hasher_retcode;

typedef struct {
/*! This fools doxygen into marking each of these as being used by hasher */
#if (!defined LINUX32) && (!defined WIN32)
  private:
    md5_context md5;
    sha1_context sha1;
    sha256_context sha256;
    sha384_context sha384;
    sha512_context sha512;
    ripemd160_context ripemd160;
  public:
#endif
  
/*! <B>Internal use only</B>
*  Initialize the digest context
*  @see md5_init
*  @see sha1_init
*  @see sha256_init
*  @see sha384_init
*  @see sha512_init
*  @see ripemd160_init
*/
  void (*init_)(void*);

/*! <B>Internal use only</B>
*  Update the digest context with input data
*  @see md5_update
*  @see sha1_update
*  @see sha256_update
*  @see sha384_update
*  @see sha512_update
*  @see ripemd160_update
*/
  void (*update_)(void*, const uns8*, uns32);

/*! <B>Internal use only</B>
*  Finalize the digest context and output the result
*  @see md5_final
*  @see sha1_final
*  @see sha256_final
*  @see sha384_final
*  @see sha512_final
*  @see ripemd160_final
*/
  void (*final_)(uns8*, void*);

#define hasher_t void
/*! Initialize the hasher pseudo-object
*  @see hasher_init
*/
  void (*init)(hasher_t *H);
  
/*! Updates the hasher pseudo-object's state
*  @see hasher_update
*/
  void (*update)(hasher_t *H, const uns8 *data, uns32 len);

/*! Finalizes the state and 
*  @see hasher_final
*/
  void (*final)(hasher_t *H, uns8 *d);
#undef hasher_t

/*! The digest algorithm's context structure
*/
  void *ctx;

/*! Length of the final output
* @see hasher_final
*/
  int len;

/*! Algorithm being used for this hasher
*/
  hash_t algo;

/*! Stored error code
* @see hasher_ret_msg
*/
  hasher_retcode err;
} hasher_t;

/*! Initalize the hasher pseudo-object
* Resets the digest internal state to unity
*/
extern void hasher_init  (hasher_t *H);

/*! Update the current state of hasher
*   Operations are buffered, thus alignment issues are abstracted from
*   lucky programm who uses this!
* @param H the hasher pseudo-object requiring the H->update(H,data,len)
* @param data pointer to array of bytes to process
* @param len length in bytes of the input
*/
extern void hasher_update(hasher_t *H, const uns8 *data, uns32 len);

/*! Finalize the structure and produce a digest
* @param H the hasher pseudo-object requiring the H->final(H,result)
* @param result byte array of <B>AT LEAST</B> H->len bytes in size
*/
extern void hasher_final (hasher_t *H, uns8 *result);

/*! Setup the hasher object for use
* @param H the hasher pseudo-object to be setup
* @param algo string representation of the algorithm to be used for
*             the lifetime of this structure (eg. "md5", "sha-1", "sha-2", "ripemd-160")
* @see hasher_ret_msg
*/
extern hasher_retcode hasher_setup(hasher_t *H, const char *algo);

/*! De-allocate and erase the components of the hasher
* @param H the hasher pseudo-object to be releasd
* @see hasher_ret_msg
*/
extern hasher_retcode hasher_teardown(hasher_t *H);

/*! Provide a human readable representation of an hasher_retcode error code
* @param c the hasher_ret_msg returned by a hasher static or pseudo-object member function
*/
extern const char* hasher_ret_msg(hasher_retcode c);

#ifdef __cplusplus
}
#endif

#ifdef WIN32
  #undef extern
#endif

#endif
