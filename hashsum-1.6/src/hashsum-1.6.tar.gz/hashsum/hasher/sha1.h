/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

/*! reference: http://csrc.nist.gov/publications/fips/fips180-1/fips180-1.pdf */

#ifndef SHA1_H
#define SHA1_H

#include "hashcom.h"

#ifndef SHA1_SMALL
  #define SHA1_SMALL   0  /* low footprint sha-1 */
#endif

#define SHA1_DIGEST_SIZE   20

typedef struct {
  uns32 state[5];
  char buf[64];
  uns32 count[2];
} sha1_context;

#ifdef __cplusplus
extern "C" {
#endif

#ifdef WIN32
 #ifdef CRYPTO_EXPORTS
   #define extern   extern __declspec(dllexport)
 #else
   #define extern   extern __declspec(dllimport)
 #endif
#endif

extern void sha1_init(sha1_context *c);
extern void sha1_update(sha1_context *c, uns8 *input, unsigned int inLen);
extern void sha1_final(uns8 *digest, sha1_context *c);

#ifdef __cplusplus
}
#endif

#ifdef WIN32
  #undef extern
#endif

/*
sha1(abc) = a9993e364706816aba3e25717850c26c9cd0d89d
*/

#endif
