/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#ifndef SHA1S_C
#define SHA1S_C

static const uns32 sha1_perm_const[4] = {K1, K2, K3, K4};
static uns32 sha1_perm_bool(uns32 x, uns32 y, uns32 z, int round) {
  uns32 r;

  if      (round==0) r=f1(x,y,z);
  else if (round==1) r=f2(x,y,z);
  else if (round==2) r=f3(x,y,z);
  else               r=f4(x,y,z);

  return r;
}

#endif
