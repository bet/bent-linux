/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#ifndef MAINDEFS_H
#define MAINDEFS_H

#if defined WIN32
  typedef unsigned __int64 uns64;
#elif defined LINUX32
  #include <stdint.h>
  typedef uint64_t uns64;
#else
  #error No undertood architectures defined
#endif

typedef unsigned int uns32;
typedef unsigned short uns16;
typedef unsigned char uns8;

#define ROLuns32(a,b)\
  (( ((a) << ((b) & 31)) | ((a) >> (32-((b) & 31))) ))
#define RORuns32(a,b)\
  (( ((a) >> ((b) & 31)) | ((a) << (32-((b) & 31))) ))

#define ROLuns64(a,b)\
  ( ((a) << ((b) & 63)) | ((a) >> (64-((b) & 63))) )
#define RORuns64(a,b)\
  ( ((a) >> ((b) & 63)) | ((a) << (64-((b) & 63))) )

#ifndef WIN32
  #define max(AA,BB)\
   ( (AA)<(BB) ? BB : AA )
#endif
  
#define ck_free(PTR,SIZE)\
  {\
  memset(PTR, 0, SIZE);\
  free(PTR);\
  PTR = NULL;\
  }

  
#endif
