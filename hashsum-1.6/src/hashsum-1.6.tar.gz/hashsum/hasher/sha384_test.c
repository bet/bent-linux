/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#include <stdio.h>
#include "sha384.h"

const uns8 ans1[SHA384_DIGEST_SIZE] = {0xcb, 0x00, 0x75, 0x3f, 0x45, 0xa3, 0x5e, 0x8b, 0xb5, 0xa0, 0x3d, 0x69, 0x9a, 0xc6, 0x50, 0x07, 0x27, 0x2c, 0x32, 0xab, 0x0e, 0xde, 0xd1, 0x63, 0x1a, 0x8b, 0x60, 0x5a, 0x43, 0xff, 0x5b, 0xed, 0x80, 0x86, 0x07, 0x2b, 0xa1, 0xe7, 0xcc, 0x23, 0x58, 0xba, 0xec, 0xa1, 0x34, 0xc8, 0x25, 0xa7};
const uns8 ans2[SHA384_DIGEST_SIZE] = {0x09, 0x33, 0x0c, 0x33, 0xf7, 0x11, 0x47, 0xe8, 0x3d, 0x19, 0x2f, 0xc7, 0x82, 0xcd, 0x1b, 0x47, 0x53, 0x11, 0x1b, 0x17, 0x3b, 0x3b, 0x05, 0xd2, 0x2f, 0xa0, 0x80, 0x86, 0xe3, 0xb0, 0xf7, 0x12, 0xfc, 0xc7, 0xc7, 0x1a, 0x55, 0x7e, 0x2d, 0xb9, 0x66, 0xc3, 0xe9, 0xfa, 0x91, 0x74, 0x60, 0x39};
const uns8 ans3[SHA384_DIGEST_SIZE] = {0x9d, 0x0e, 0x18, 0x09, 0x71, 0x64, 0x74, 0xcb, 0x08, 0x6e, 0x83, 0x4e, 0x31, 0x0a, 0x4a, 0x1c, 0xed, 0x14, 0x9e, 0x9c, 0x00, 0xf2, 0x48, 0x52, 0x79, 0x72, 0xce, 0xc5, 0x70, 0x4c, 0x2a, 0x5b, 0x07, 0xb8, 0xb3, 0xdc, 0x38, 0xec, 0xc4, 0xeb, 0xae, 0x97, 0xdd, 0xd8, 0x7f, 0x3d, 0x89, 0x85};

int main() {
  char *test1 = "abc";
  char *test2 = "abcdefghbcdefghicdefghijdefghijkefghijklfghijklmghijklmnhijklmnoijklmnopjklmnopqklmnopqrlmnopqrsmnopqrstnopqrstu";
  uns8 D[SHA384_DIGEST_SIZE];
  sha384_context CTX;
  int i;

  printf("sha384(%s)\n", test1);
  /* strlen < 56 */
  sha384_init(&CTX);
  sha384_update(&CTX, (uns8*)test1, strlen(test1));
  sha384_final(D, &CTX);

  printf("D = "); for (i=0; i<SHA384_DIGEST_SIZE; i++) printf("%.2x ", D[i]); printf("\n");
  printf("A = "); for (i=0; i<SHA384_DIGEST_SIZE; i++) printf("%.2x ", ans1[i]); printf("\n");


  /* strlen == 56 */
  printf("sha384(%s)\n", test2);
  sha384_init(&CTX);
  sha384_update(&CTX, (uns8*)test2, strlen(test2));
  sha384_final(D, &CTX);

  printf("D = "); for (i=0; i<SHA384_DIGEST_SIZE; i++) printf("%.2x ", D[i]); printf("\n");
  printf("A = "); for (i=0; i<SHA384_DIGEST_SIZE; i++) printf("%.2x ", ans2[i]); printf("\n");


  /* strlen == 56 */
  printf("sha384(%s)\n", test2);
  sha384_init(&CTX);
  sha384_update(&CTX, (uns8*)test2, strlen(test2)/2);
  sha384_update(&CTX, (uns8*)&test2[strlen(test2)/2], strlen(test2) - strlen(test2)/2);
  sha384_final(D, &CTX);

  printf("D = "); for (i=0; i<SHA384_DIGEST_SIZE; i++) printf("%.2x ", D[i]); printf("\n");
  printf("A = "); for (i=0; i<SHA384_DIGEST_SIZE; i++) printf("%.2x ", ans2[i]); printf("\n");


  /* crazy long! */
  printf("sha384(1,000,000 x 'a')\n");
  sha384_init(&CTX);
  for (i=0; i<10*1000; i++)
    sha384_update(&CTX, "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", 100);
  sha384_final(D, &CTX);

  printf("D = "); for (i=0; i<SHA384_DIGEST_SIZE; i++) printf("%.2x ", D[i]); printf("\n");
  printf("A = "); for (i=0; i<SHA384_DIGEST_SIZE; i++) printf("%.2x ", ans3[i]); printf("\n");

  return 0;
}
