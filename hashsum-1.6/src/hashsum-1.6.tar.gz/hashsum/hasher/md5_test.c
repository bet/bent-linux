/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#include "stdio.h"
#include "md5.h"

uns8 test_ans[MD5_DIGEST_SIZE] = {0x90, 0x01, 0x50, 0x98, 0x3c, 0xd2, 0x4f, 0xb0, 0xd6, 0x96, 0x3f, 0x7d, 0x28, 0xe1, 0x7f, 0x72};
uns8 test2_ans[MD5_DIGEST_SIZE] = {0xd1, 0x74, 0xab, 0x98, 0xd2, 0x77, 0xd9, 0xf5, 0xa5, 0x61, 0x1c, 0x2c, 0x9f, 0x41, 0x9d, 0x9f};
uns8 test3_ans[MD5_DIGEST_SIZE] = {0x77, 0x07, 0xd6, 0xae, 0x4e, 0x02, 0x7c, 0x70, 0xee, 0xa2, 0xa9, 0x35, 0xc2, 0x29, 0x6f, 0x21};

int main(int argL, char *arg[]) {
  char *test = "abc";
  char *test2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  md5_context CTX; /* CONTEXT */
  uns8 D[MD5_DIGEST_SIZE];      /* DIGEST */
  uns8 str[1024];
  int i, readLen;
  FILE *fin;

  printf("md5( \"%s\" )\n", test);
  md5_init(&CTX);
  md5_update(&CTX, test, strlen(test));
  md5_final(D, &CTX);

  printf("D = ");
  for (i=0; i<MD5_DIGEST_SIZE; i++)
    printf("%.2x ", D[i]);
  printf("\n");
  printf("A = ");
  for (i=0; i<MD5_DIGEST_SIZE; i++)
    printf("%.2x ", test_ans[i] & 0xff);
  printf("\n");

  printf("md5( \"%s\" )\n", test2);
  md5_init(&CTX);
  md5_update(&CTX, test2, strlen(test2));
  md5_final(D, &CTX);

  printf("D = ");
  for (i=0; i<MD5_DIGEST_SIZE; i++)
    printf("%.2x ", D[i]);
  printf("\n");
  printf("A = ");
  for (i=0; i<MD5_DIGEST_SIZE; i++)
    printf("%.2x ", test2_ans[i] & 0xff);
  printf("\n");

  printf("md5( \"1,000,000 x 'a'\" )\n");
  md5_init(&CTX);
  for (i=0; i<1000*1000; i++)
    md5_update(&CTX, (uns8*)"a", 1);
  md5_final(D, &CTX);

  printf("D = ");
  for (i=0; i<MD5_DIGEST_SIZE; i++)
    printf("%.2x ", D[i]);
  printf("\n");
  printf("A = ");
  for (i=0; i<MD5_DIGEST_SIZE; i++)
    printf("%.2x ", test3_ans[i] & 0xff);
  printf("\n");

  if (argL < 2) {
    printf("Usage: %s <file to open>\n", arg[0]);
    return 1;
  }
  
  fin = fopen(arg[1], "r");
  if (fin == NULL) {
    printf("file not found\n");
    return -1;
  }

  printf("MD5( %s ) = ", arg[1]);
  md5_init(&CTX);
  do {
    readLen = fread(str, 1, 1024, fin);
    md5_update(&CTX, str, readLen);
  } while (readLen != 0);
  md5_final(D, &CTX);

  for (i=0; i<16; i++) {
    printf("%.2x ", D[i]);
  }
  printf("\n");

  return 0;
}
