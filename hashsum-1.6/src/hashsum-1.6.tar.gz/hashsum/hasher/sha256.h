/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

/*! reference: http://csrc.nist.gov/encryption/shs/dfips-180-2.pdf */

#ifndef SHA256_H
#define SHA256_H

#include "hashcom.h"

#ifndef SHA256_SMALL
  #define SHA256_SMALL   0  /* low footprint sha-256 */
#endif

#define SHA256_DIGEST_SIZE   (8*sizeof(uns32))

typedef struct {
  uns32 state[8];
  uns8 buf[128];
  uns32 count[2];
} sha256_context;

#ifdef __cplusplus
extern "C" {
#endif

#ifdef WIN32
 #ifdef CRYPTO_EXPORTS
   #define extern   extern __declspec(dllexport)
 #else
   #define extern   extern __declspec(dllimport)
 #endif
#endif

extern void sha256_init(sha256_context *c);
extern void sha256_update(sha256_context *c, uns8 *input, unsigned int inLen);
extern void sha256_final(uns8 *digest, sha256_context *c);

#ifdef __cplusplus
}
#endif

#ifdef WIN32
  #undef extern
#endif

/*
sha256(abc) = ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f
*/

#endif
