/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#include "sha1.h"
#include "stdio.h"

int main(int argL, char *arg[]) {
  char *test = "abc";
  char *test2 = "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq";
  uns8 test_ans[SHA1_DIGEST_SIZE] = {0xa9, 0x99, 0x3e, 0x36, 0x47, 0x06, 0x81, 0x6a, 0xba, 0x3e, 0x25, 0x71, 0x78, 0x50, 0xc2, 0x6c, 0x9c, 0xd0, 0xd8, 0x9d};
  uns8 test2_ans[SHA1_DIGEST_SIZE] = {0x84, 0x98, 0x3e, 0x44, 0x1c, 0x3b, 0xd2, 0x6e, 0xba, 0xae, 0x4a, 0xa1, 0xf9, 0x51, 0x29, 0xe5, 0xe5, 0x46, 0x70, 0xf1};
  uns8 test3_ans[SHA1_DIGEST_SIZE] = {0x34, 0xaa, 0x97, 0x3c, 0xd4, 0xc4, 0xda, 0xa4, 0xf6, 0x1e, 0xeb, 0x2b, 0xdb, 0xad, 0x27, 0x31, 0x65, 0x34, 0x01, 0x6f};
  uns8 D[SHA1_DIGEST_SIZE];
  sha1_context CTX;
  int i;

  printf("sha1(%s)\n", test);
  /* strlen < 56 */
  sha1_init(&CTX);
  sha1_update(&CTX, (uns8*)test, strlen(test));
  sha1_final(D, &CTX);

  printf("D = ");
  for (i=0; i<SHA1_DIGEST_SIZE; i++)
    printf("%.2x ", D[i]);
  printf("\n");
  printf("A = ");
  for (i=0; i<SHA1_DIGEST_SIZE; i++)
    printf("%.2x ", test_ans[i] & 0xff);
  printf("\n");

  printf("sha1(%s)\n", test2);
  /* strlen == 56 */
  sha1_init(&CTX);
  sha1_update(&CTX, (uns8*)test2, strlen(test2));
  sha1_final(D, &CTX);

  printf("D = ");
  for (i=0; i<SHA1_DIGEST_SIZE; i++)
    printf("%.2x ", D[i]);
  printf("\n");
  printf("A = ");
  for (i=0; i<SHA1_DIGEST_SIZE; i++)
    printf("%.2x ", test2_ans[i] & 0xff);
  printf("\n");

  printf("sha1( \"1,000,000 x 'a'\" )\n");
  sha1_init(&CTX);
  for (i=0; i<1000*1000; i++)
    sha1_update(&CTX, (uns8*)"a", 1);
  sha1_final(D, &CTX);

  printf("D = ");
  for (i=0; i<SHA1_DIGEST_SIZE; i++)
    printf("%.2x ", D[i]);
  printf("\n");
  printf("A = ");
  for (i=0; i<SHA1_DIGEST_SIZE; i++)
    printf("%.2x ", test3_ans[i] & 0xff);
  printf("\n");

  if (argL >= 2) {
    FILE *fin = fopen(arg[1], "rb");
    uns8 tmp[1024];
    int read_size=1024,
        read_len;

    sha1_init(&CTX);
    do {
      read_len = fread(tmp, 1, read_size, fin);
      sha1_update(&CTX, tmp, read_len);
    } while (read_len == read_size);
    sha1_final(D, &CTX);

    printf("D = ");
    for (i=0; i<SHA1_DIGEST_SIZE; i++)
      printf("%.2x ", D[i]);
    printf("\n");
  }
  
  return 0;
}
