/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#ifndef HASHCOM_H
#define HASHCOM_H

#include <string.h>
#include "mainDefs.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef WIN32
 #ifdef CRYPTO_EXPORTS
   #define extern   extern __declspec(dllexport)
 #else
   #define extern   extern __declspec(dllimport)
 #endif
#endif
 
#if defined HASHCOM_SMALL
  #define SHA1_SMALL 1
  #define SHA512_SMALL 1
  #define SHA512_REASONABLE 0
  #define SHA384_SMALL 1
  #define SHA384_REASONABLE 0
  #define SHA256_SMALL 1
  #define SHA256_REASONABLE 0
  #define RIPEMD160_SMALL 1
#elif defined HASHCOM_REASONABLE
  #define SHA1_SMALL 0
  #define SHA512_SMALL 0
  #define SHA512_REASONABLE 1
  #define SHA384_SMALL 0
  #define SHA384_REASONABLE 1
  #define SHA256_SMALL 0
  #define SHA256_REASONABLE 1
  #define RIPEMD160_SMALL 0
#elif defined HASHCOM_LARGE
  #define SHA1_SMALL 0
  #define SHA512_SMALL 0
  #define SHA512_REASONABLE 0
  #define SHA384_SMALL 0
  #define SHA384_REASONABLE 0
  #define SHA256_SMALL 0
  #define SHA256_REASONABLE 0
  #define RIPEMD160_SMALL 0
#else
  #error You must define one of HASHCOM_SMALL HASHCOM_REASONABLE or HASHCOM_LARGE
#endif
  
#if defined HASHCOM_BASIC_API
  #define SHA1_BASIC_API 1
  #define SHA512_BASIC_API 1
  #define SHA384_BASIC_API 1
  #define SHA256_BASIC_API 1
  #define RIPEMD160_BASIC_API 1
#else
  #define SHA1_BASIC_API 0
  #define SHA512_BASIC_API 0
  #define SHA384_BASIC_API 1
  #define SHA256_BASIC_API 0
  #define RIPEMD160_BASIC_API 0
#endif
  
typedef enum {
 CRYPTO_HASH_NONE=0,
 CRYPTO_HASH_MD5,
 CRYPTO_HASH_SHA1,
 CRYPTO_HASH_RIPEMD160,
 CRYPTO_HASH_SHA512,
 CRYPTO_HASH_SHA384,
 CRYPTO_HASH_SHA256,

 CRYPTO_HASH_COUNT /* LEAVE THIS HERE! */
} hash_t;
 
extern const void* crypto_hash_name_arr[CRYPTO_HASH_COUNT][2];
extern const char* crypto_name(const void* tab[][2], int count, int v);
extern unsigned int crypto_name_rev(const void* tab[][2], int count, const char *str);
#define crypto_hash_name(HASH_T)\
  crypto_name(crypto_hash_name_arr, CRYPTO_HASH_COUNT, HASH_T)
#define crypto_hash_name_rev(STR)\
  ((hash_t)crypto_name_rev(crypto_hash_name_arr, CRYPTO_HASH_COUNT, STR))

extern const char hashcom_PADDING[128];

#ifdef __cplusplus
}
#endif

#ifdef WIN32
  #undef extern
#endif

#endif
