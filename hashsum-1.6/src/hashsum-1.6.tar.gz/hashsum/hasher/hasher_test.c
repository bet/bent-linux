/*! A contribution to the open-source movement.
 *  Jean-Luc Cooke <jlcooke@certainkey.com>
 *     CertainKey Inc.
 *     Ottawa Ontario Canada
 *
 *  Created: July 20th, 2001
 *
 *  The following program code is released under the GPL license
 *    http://www.gnu.org/copyleft/gpl.html
 */

#include <stdio.h>
#include "hasher.h"

#define HANDLE_ERROR(X) {\
  if ((status = X) != HASHER_OK) {\
    printf("Error occured: %u %s\n", status, hasher_ret_msg(status));\
    return;\
  }\
}

#define TESTTHIS  "abc"

void test_hash(const char *h) {
  hasher_t H;
  char *D;
  int i;
  hasher_retcode status;

  HANDLE_ERROR(hasher_setup(&H, h));

  D = (char*) malloc(H.len);

  H.init(&H);
  H.update(&H, TESTTHIS, strlen(TESTTHIS));
  H.final(&H, D);
  
  printf("%s(%s)=", h, TESTTHIS);
  for (i=0; i<H.len; i++)
    printf("%.2x", D[i]&0xff);
  printf("\n");
  
  free(D);
}

const char *algos[] = {
"none algo whatsoever",
"md5",
"sha-1",
"sha-256",
"sha-512",
"ripemd-160"
};

int main() {
  int i;

  for (i=0; i<CRYPTO_HASH_COUNT; i++) {
    test_hash(algos[i]);
  }
  
  return 0;
}
