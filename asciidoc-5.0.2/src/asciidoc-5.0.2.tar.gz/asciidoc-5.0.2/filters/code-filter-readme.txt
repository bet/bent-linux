AsciiDoc Example Code Filter README
===================================

This simple minded filter highlights source code keywords and
comments.

Files
-----
code-filter.py::
	The filter Python script.
code-filter.conf::
	The AsciiDoc filter configuration file.
code-filter-test.asc::
	Short AsciiDoc document to test the filter.

Installation
------------
The code filter is installed in the distribution `./filters` directory
as part of the standard AsciiDoc install.

Test it on the `code-filter-test.asc` file:

  $ asciidoc -b html code-filter-test.asc

Help
----
Execute the filter with the help option:

  $ ./code-filter.py --help | less
