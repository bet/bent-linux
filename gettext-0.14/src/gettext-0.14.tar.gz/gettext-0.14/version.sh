# Version number and release date.
VERSION_NUMBER=0.14
RELEASE_DATE=2004-01-28      # in "date +%Y-%m-%d" format
