package URI::itunesplaylist; 

# dummy URI for our itunesplaylist scheme

require URI;
@ISA=qw(URI);

use strict;

1;

__END__
