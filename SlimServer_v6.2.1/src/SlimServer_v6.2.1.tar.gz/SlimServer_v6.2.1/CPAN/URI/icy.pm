package URI::icy;

# dummy URI for the icy icecast scheme

require URI::http;
@ISA=qw(URI::http);

1;
