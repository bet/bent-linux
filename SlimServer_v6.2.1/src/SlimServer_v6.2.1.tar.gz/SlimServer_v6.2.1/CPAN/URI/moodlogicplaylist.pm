package URI::moodlogicplaylist; 

# dummy URI for our moodlogic scheme

require URI;
@ISA=qw(URI);

use strict;

1;

__END__
