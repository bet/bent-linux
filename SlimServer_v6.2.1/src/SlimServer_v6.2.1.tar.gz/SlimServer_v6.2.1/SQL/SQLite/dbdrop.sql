DROP TABLE metainformation;

DROP TABLE tracks;

DROP TABLE playlist_track;

DROP TABLE albums;

DROP TABLE contributors;

DROP TABLE contributor_track;

DROP TABLE contributor_album;

DROP TABLE genres;

DROP TABLE genre_track;

DROP TABLE comments;

DROP TABLE dirlist_track;

DROP TABLE pluginversion;
