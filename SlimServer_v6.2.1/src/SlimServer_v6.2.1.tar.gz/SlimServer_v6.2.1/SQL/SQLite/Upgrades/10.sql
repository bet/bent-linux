-- 
-- Force db recreation by upping the schema

UPDATE metainformation SET version = 10;
