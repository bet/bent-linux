-- 
--

-- ALTER TABLE tracks ADD COLUMN rating int(10) unsigned;
-- ALTER TABLE tracks ADD COLUMN playCount int(10) unsigned;
-- ALTER TABLE tracks ADD COLUMN lastPlayed int(10) unsigned;

-- ALTER TABLE tracks ADD INDEX trackRatingIndex (rating);
-- ALTER TABLE tracks ADD INDEX trackPlayCountIndex (playCount);

-- UPDATE metainformation SET version = 4;
