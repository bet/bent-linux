/* SiEd - A text editor for PalmOS 3.5+ Copyright (C) 2003 Benjamin Roe
 * Contact Email:ben@benroe.com
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 * 
 *  This program is distributed in the hope that it will be useful, but
 *  WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * */

#include "database_interface.h"
#include <unistd.h>

int main(int argc,char **argv)
{
	int opt;
	bool done=false;

	while((opt=getopt(argc,argv,"f:d:v"))!=-1)
    	{
        	switch(opt)
        	{
        	case 'f':
			convert_text_to_pdb(optarg);
			done=true;
            		break;
        	case 'd':
			convert_pdb_to_text(optarg);
			done=true;
            		break;
		case 'v':
			cout<<"SiEd Palm Database Conversion. (C) Ben Roe 2003. Licensed under the GPL v2.0\n";
			cout<<"This program comes with ABSOLUTELY NO WARRANTY.\n";
			break;
        	case '?':
            		cout<<"Unknown option. Ignoring\n";
            		break;
		default:
            		cout<<"Usage: -f <input text file> -d <input pdb file>\n";
			done=true;
            		break;
        }
    }
    if(!done)
    	cout<<"Usage: -f <input text file> -d <input pdb file>\n";
	return 0;
}
