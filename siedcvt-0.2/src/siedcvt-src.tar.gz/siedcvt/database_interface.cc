/*
 * SiEd - A text editor for PalmOS 3.5+ Copyright (C) 2003 Benjamin Roe
 * Contact Email:ben@benroe.com
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 * */

#include "database_interface.h"
#include <time.h>
#include <iostream>
using namespace std;
#define EPOCH_OFFSET 2082844800
#define MAX_FILENAME_LENGTH 28

const char extension[5]=".pdb";

bool convert_text_to_pdb(const char * filename)
{
	if(strlen(filename)>MAX_FILENAME_LENGTH)
	{
		cout<<"SiEd filenames must be less than 28 characters long.\n";
		return false;
	}

	ifstream file;

	file.open(filename);

	if(file==NULL)
	{
		cout<<"Unable to open input file "<<filename<<".\n";
		return false;
	}
	file.seekg(0,ios::end);
	int size=file.tellg();

	file.seekg(0,ios::beg);
	char * data=new char[size+HEADER_SIZE];

	write_header(data,size+HEADER_SIZE,filename);

	file.read(data+HEADER_SIZE,size);

	write_pdb(data,size+HEADER_SIZE,filename);

	delete[] data;
}

char * strip_filename(const char * const filename)
{
	int len=strlen(filename);
	char * new_filename;
	if(len<=4)
	{
		new_filename=new char[len+1];
		strncpy(new_filename,filename,len);
		memset(new_filename+len,0,1);
	}
	else if(strncmp(filename+len-4,".pdb",4)==0)
	{
		//strip off the pdb if it's present
		new_filename=new char[len-3];
		strncpy(new_filename,filename,len-4);
		memset(new_filename+len-4,0,1);
	}
	else
	{
		new_filename=new char[len+5];
		strncpy(new_filename,filename,len);
		strncpy(new_filename+len,".txt",5);
	}
	return new_filename;
}

bool convert_pdb_to_text(const char * filename)
{
	if(strlen(filename)-4>MAX_FILENAME_LENGTH)
	{
		cout<<"SiEd filenames must be less than 28 characters long.\n";
		return false;
	}
	ifstream pdb_file;
	pdb_file.open(filename);

	if(pdb_file==NULL)
	{
		cout<<"Unable to open input file "<<filename<<".\n";
		return false;
	}


	pdb_file.seekg(0,ios::end);
	int size=pdb_file.tellg();

	pdb_file.seekg(0,ios::beg);
	char * data=new char[size];
	pdb_file.read(data,size);
	pdb_file.close();
	char * new_name=strip_filename(filename);

	ofstream out(new_name);
	out.write(data+HEADER_SIZE,size-HEADER_SIZE);
	out.close();
	delete[] data;
	delete[] new_name;
	return true;
}

void write_data(char * data,char * to_write,const int number)
{
	#ifdef __LITTLE_ENDIAN__
	for(int i=number-1;i>=0;--i)
		data[number-i-1]=to_write[i];
	#else
	memcpy(data,to_write,number);
	#endif

}


void write_header(char * data,const int size,const char * const filename)
{
	//output the database header
	//first the name (up to 31 bytes)
	strncpy(data,filename,MAX_FILENAME_LENGTH);
	memset(data+strlen(filename),0,1);
	unsigned int zero=0;
	//attributes
	short unsigned int flags=16;
	write_data(data+32,(char*)&flags,2);

	//version
	short unsigned int version=1;
	write_data(data+34,(char*)&version,2);

	//creation
	unsigned int the_time=time(NULL)+EPOCH_OFFSET;
	write_data(data+36,(char*)&the_time,4);

	//modification
	write_data(data+40,(char*)&the_time,4);
	write_data(data+44,(char*)&zero,4);

	//backup
	write_data(data+48,(char*)&the_time,4);

	//appinfo
	unsigned int appinfo=0;
	write_data(data+52,(char*)&appinfo,4);

	//sortinfo
	unsigned int sortinfo=0;
	write_data(data+56,(char*)&sortinfo,4);

	//type
	unsigned int type=DatabaseType;
	write_data(data+60,(char*)&type,4);
	//creator
	unsigned int creator=SiEdAppID;
	write_data(data+64,(char*)&creator,4);

	unsigned int un_id=0;
	write_data(data+68,(char*)&un_id,4);

	//next record list
	unsigned int next_rec=0;
	write_data(data+72,(char*)&next_rec,4);

	//one record for now
	unsigned short int rec=1;
	write_data(data+76,(char*)&rec,2);

	//then the record list
	//starts 86 bytes in
	unsigned int offset=HEADER_SIZE;
	write_data(data+78,(char*)&offset,4);

	write_data(data+80,(char*)&zero,1);

	write_data(data+83,(char*)&zero,3);

}

bool write_pdb(const char * const data,const int size,const char * const filename)
{
	char * new_filename=new char[strlen(filename)+6];
	strncpy(new_filename,filename,strlen(filename));
	strncpy(new_filename+strlen(filename),extension,5);
	ofstream out(new_filename);
	out.write(data,size);
	out.close();
	delete[] new_filename;
	return true;
}
