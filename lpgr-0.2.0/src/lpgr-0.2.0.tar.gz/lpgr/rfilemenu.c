/*****************************************************************************
* Lien Project Gutenber Reader is a reader for Project Gutenberg ebook       *
* Copyright (C) 2002 Tan Chee Kien. See file COPYING for licence details     *
*                                                                            *
*    This program is free software; you can redistribute it and/or modify    *
*    it under the terms of the GNU General Public License as published by    *
*    the Free Software Foundation; either version 2 of the License, or       *
*    any later version.                                                      *
*                                                                            *
*    This program is distributed in the hope that it will be useful,         *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of          *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           *
*    GNU General Public License for more details.                            *
*                                                                            *
*    You should have received a copy of the GNU General Public License       *
*    along with this program; if not, write to the Free Software             *
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307    *  
*    USA                                                                     *
*                                                                            *
*    You can contact the author by sending an email to :                     *
*       gogota321@yahoo.com                                                  *
*    or write a letter to :                                                  *
*    Tan Chee Kien, No. 33, Kampung Tembaga Dayak, Sematan, 94500 Lundu ,Sar *
*    awak, Malaysia                                                          *
*****************************************************************************/


// display menu to let user choose that was opened before


#include <menu.h>
#include <stdlib.h>
#include <string.h>
#include "lpgr.h"
#include <unistd.h>

char           *
rfmenu(void)
{
    ITEM           *item[init_recent_fl() + 1];
    char           *filename[init_recent_fl() + 1];
    char           *realname[init_recent_fl() + 1];
    MENU           *rfilemenu;
    WINDOW         *fwin, *subfwin;
    int             max_length_for_name;
    int             count, total_item;
    FILE           *stream;
    char            temp[300];
    char            full_name[300];
    int             key = 0;
    int             index;
    int             done = NO;

    start_ncurses();
    keypad(stdscr, TRUE);
    fwin = newwin(LINES - 1, COLS, 1, 0);
    subfwin = subwin(fwin, LINES - 3, COLS - 2, 2, 1);
    max_length_for_name = COLS - 2;
    total_item = init_recent_fl();

    bkgd(COLOR_PAIR(MENUBOX_COLOR) + A_BOLD);
    wbkgd(subfwin, COLOR_PAIR(MENUBACK_COLOR) + A_BOLD);
    wbkgd(fwin, COLOR_PAIR(MENUBOX_COLOR) + A_BOLD);
    box(fwin, ACS_VLINE, ACS_HLINE);
    clearok(fwin, TRUE);
    leaveok(fwin, TRUE);
    clearok(subfwin, TRUE);
    leaveok(subfwin, TRUE);

    nodelay(subfwin, FALSE);
    strncpy(full_name, getenv("HOME"), 300);
    strcat(full_name, LPGR_CONF_DIR);

    chdir(full_name);
    stream = fopen("recent.inf", "r");

    printw("please choose one & press enter:");

    for (count = 0; count < total_item; count++) {
	filename[count] =
	    (char *) malloc((max_length_for_name + 1) * sizeof(char));
	realname[count] = (char *) malloc(300 * sizeof(char));
	memset(temp, 0, 300 * sizeof(char));
	memset(filename[count], 0, (max_length_for_name + 1) * sizeof(char));
	memset(realname[count], 0, 300 * sizeof(char));
	fscanf(stream, "%[^\n]", temp);
	strncpy(filename[count], temp, max_length_for_name);
	strncpy(realname[count], temp, 299);
	// erase();
	// printw("%s",filename[count]);
	// refresh();
	// getch();
	item[count] = new_item(filename[count], "");
	fscanf(stream, "%[\n]", temp);
    }
    item[count] = NULL;

    rfilemenu = new_menu(item);

    set_menu_win(rfilemenu, subfwin);
    set_menu_back(rfilemenu, COLOR_PAIR(MENUBACK_COLOR) + A_BOLD);
    set_menu_mark(rfilemenu, "");
    set_menu_format(rfilemenu, LINES - 3, 1);
    post_menu(rfilemenu);
    wnoutrefresh(stdscr);
    wnoutrefresh(subfwin);
    wnoutrefresh(fwin);
    doupdate();
    while (done == NO) {
	key = getch();

	switch (key) {
	case DOWN_ARROW:
	    menu_driver(rfilemenu, REQ_DOWN_ITEM);
	    post_menu(rfilemenu);
	    wnoutrefresh(subfwin);
	    wnoutrefresh(fwin);
	    doupdate();
	    continue;

	case UP_ARROW:
	    menu_driver(rfilemenu, REQ_UP_ITEM);
	    post_menu(rfilemenu);
	    wnoutrefresh(subfwin);
	    wnoutrefresh(fwin);
	    doupdate();
	    continue;

	case ENTER:
	    index = item_index(current_item(rfilemenu));
	    done = YES;
	    continue;

	default:
	    continue;

	}
    }
    return realname[index];
}
