/*****************************************************************************
* Lien Project Gutenber Reader is a reader for Project Gutenberg ebook       *
* Copyright (C) 2002 Tan Chee Kien. See file COPYING for licence details     *
*                                                                            *
*    This program is free software; you can redistribute it and/or modify    *
*    it under the terms of the GNU General Public License as published by    *
*    the Free Software Foundation; either version 2 of the License, or       *
*    any later version.                                                      *
*                                                                            *
*    This program is distributed in the hope that it will be useful,         *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of          *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           *
*    GNU General Public License for more details.                            *
*                                                                            *
*    You should have received a copy of the GNU General Public License       *
*    along with this program; if not, write to the Free Software             *
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307    *
*    USA                                                                     *
*                                                                            *
*    You can contact the author by sending an email to :                     *
*       gogota321@yahoo.com                                                  *
*    or write a letter to :                                                  *
*    Tan Chee Kien, No. 33, Kampung Tembaga Dayak, Sematan, 94500 Lundu ,Sar *
*    awak, Malaysia                                                          *
*****************************************************************************/

#include <ncurses.h>
#include <ctype.h>
#include "lpgr.h"
#include "config.h"

int
printpage(FILE * source)
{
    WINDOW         *leftwin, *rightwin;
    WINDOW         *middleline;

    char            c;
    int             use_left_or_right = LEFT;
    int             a;
    int             prev_is_enter = NO;
    int             bold = 0;
    extern int      nonpg;

    if (MAKE_TEXT_BRIGHT == 1)
	bold = A_BOLD;
    else if (MAKE_TEXT_BRIGHT == 0)
	bold = 0;


    leftwin = newwin(LINES - 1, COLS / 2, 0, 0);
    rightwin = newwin(LINES - 1, 0, 0, COLS / 2 + 1);
    middleline = newwin(LINES - 1, 1, 0, COLS / 2);


    wattrset(leftwin, COLOR_PAIR(TEXT_COLOR) + bold);
    wattrset(rightwin, COLOR_PAIR(TEXT_COLOR) + bold);
    wattrset(middleline, COLOR_PAIR(LINE_COLOR) + bold);

    for (a = 0; a <= (LINES - 2); a++)
	mvwaddch(middleline, a, 0, ACS_VLINE);

    while ((c = fgetc(source)) != EOF) {
	if (isprint(c)) {
	    prev_is_enter = NO;
	    if (use_left_or_right == LEFT) {
		if (waddch(leftwin, c) == OK)
		    continue;
		else {
		    // ungetc(c, source);
		    use_left_or_right = RIGHT;
		    continue;
		}
	    } else {
		if (waddch(rightwin, c) == OK)
		    continue;
		else {
		    // ungetc(c, source);
		    break;
		}
	    }
	} else if (c == '\n') {
	    if (use_left_or_right == LEFT) {
		if (prev_is_enter) {
		    wprintw(leftwin, "\n\n");
		    prev_is_enter = NO;
		} else {
		    wprintw(leftwin, " ");
		    prev_is_enter = YES;
		}
		if (nonpg == YES)
		    wprintw(leftwin, "\n");
		continue;
	    } else {
		if (prev_is_enter) {
		    wprintw(rightwin, "\n\n");
		    prev_is_enter = NO;
		} else {
		    wprintw(rightwin, " ");
		    prev_is_enter = YES;
		}
		if (nonpg == YES)
		    wprintw(rightwin, "\n");
		continue;
	    }
	}
    }

    wnoutrefresh(leftwin);
    wnoutrefresh(rightwin);
    wnoutrefresh(middleline);
    doupdate();

    if (c == EOF)
	return FINISH;
    else
	return NOTFINISH;
}
