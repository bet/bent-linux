/*****************************************************************************
* Lien Project Gutenber Reader is a reader for Project Gutenberg ebook       *
* Copyright (C) 2002 Tan Chee Kien. See file COPYING for licence details     *
*                                                                            *
*    This program is free software; you can redistribute it and/or modify    *
*    it under the terms of the GNU General Public License as published by    *
*    the Free Software Foundation; either version 2 of the License, or       *
*    any later version.                                                      *
*                                                                            *
*    This program is distributed in the hope that it will be useful,         *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of          *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           *
*    GNU General Public License for more details.                            *
*                                                                            *
*    You should have received a copy of the GNU General Public License       *
*    along with this program; if not, write to the Free Software             *
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307    *
*    USA                                                                     *
*                                                                            *
*    You can contact the author by sending an email to :                     *
*       gogota321@yahoo.com                                                  *
*    or write a letter to :                                                  *
*    Tan Chee Kien, No. 33, Kampung Tembaga Dayak, Sematan, 94500 Lundu ,Sar *
*    awak, Malaysia                                                          *
*****************************************************************************/


#include <ncurses.h>
#include <signal.h>
#include "lpgr.h"
#include <fnmatch.h>
#include <sys/types.h>
#include <dirent.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include <string.h>

int             nonpg;

int
main(int argc, char **argv)
{
    FILE           *stream;
    unsigned int    pages = 1;
    DIR            *dirptr;
    struct dirent  *abc;
    char           *dirname;
    char           *filename;
    char           *choosen_old_file = NULL;
    char            cdir[300];
    int             option;
    int             num_of_recent;
    // total files that was opened before
    extern int      nonpg;

    extern int      optind;

    puts("Please wait for a while ....");
    while ((option = getopt(argc, argv, "rhn")) != -1) {
	switch (option) {
	case 'h':
	    givehelp();
	    exit(-1);

	case 'r':
	    choosen_old_file = rfmenu();
	    // erase();
	    // printw("you choose %s", choosen_old_file);
	    // refresh();
	    // getch();
	    endwin();
	    continue;
	case 'n':
	    nonpg = YES;
	    continue;

	default:
	    givehelp();
	    exit(-1);
	}
    }

    if ((argv[optind] == NULL) && (choosen_old_file == NULL)) {
	givehelp();
	exit(-1);
    }
    if ((argv[optind] != NULL) && (choosen_old_file != NULL)) {
	endwin();
	printf("You can't use -r if you specify a file in command line\n");
	givehelp();
	exit(-1);
    }
    if (argv[optind] != NULL)
	// file choosen in command line
    {
	if ((dirname = killname(argv[optind])) == NULL)
	    // no directory specified
	{
	    dirname = (char *) malloc(sizeof(char) * 300);
	    memset(dirname, 0, sizeof(char) * 300);
	    getcwd(dirname, sizeof(char) * 300);
	    strcat(dirname, "/");
	}
	filename = filtername(argv[optind]);

	chdir(dirname);
	getcwd(cdir, sizeof(char) * 300);
	dirptr = opendir(cdir);


	while (1) {
	    if ((abc = readdir(dirptr)) == NULL) {
		printf("no such file !!\n");
		givehelp();
		exit(-1);
	    }
	    if (fnmatch(filename, abc->d_name, 0) == 0) {
		if ((stream = fopen(abc->d_name, "rb")) == NULL) {
		    printf("file exist but unable to open !\n");
		    exit(-1);
		}
		fclose(stream);
		strncpy(filename, abc->d_name, 250);
		break;
	    }
	}

	if ((num_of_recent = init_recent_fl()) == 0)
	    make_recent_fl(dirname, abc->d_name);

	else {
	    if (num_of_recent >= MAX_RECENT_FL_ITEM)
		reduce_item_from_recent_fl();
	    append_2_recent_fl(dirname, abc->d_name);
	}
    } else if (choosen_old_file != NULL) {
	dirname = killname(choosen_old_file);
	filename = filtername(choosen_old_file);
    }
    chdir(dirname);

    // printf("%d\n", num_of_recent);
    // exit(-1);

    if (choosen_old_file == NULL) {
	start_ncurses();
	signal(SIGTERM, disable_curses_and_exit);	/* If you don't put
							 * this, the whole */
	signal(SIGQUIT, disable_curses_and_exit);	/* terminal will
							 * become nuts ! */
    }
    if ((stream = fopen(filename, "rb")) == NULL)
	cur_error("unable to open input file");

    while (fakeread(stream) != FINISH)
	pages++;

    fclose(stream);


    control(filename, pages);

    disable_curses_and_exit(0);
    return 0;
}

void
givehelp(void)
{
    printf("The correct way is \"lpgr <filename>\"\n");
    printf("example : \n");
    printf("  lpgr /mnt/cdrom/ebook/reath10.txt\n");
    printf("or\n");
    printf("  lpgr /mnt/cd*/eb*/r*txt\n\n");
    printf("options :\n");
    printf("-h : this help screen\n");
    printf("-r : choose from file that was opened before\n\n");
    printf("-n : open non Project Gutenberg text file\n\n");
    printf("Any bugs please report to <gogota321@yahoo.com>\n");
    printf("Lien Project Gutenberg Etext Reader version %s\n\n",
	   LPGR_VERSION);
}
