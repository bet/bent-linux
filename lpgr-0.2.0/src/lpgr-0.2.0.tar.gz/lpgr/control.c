/*****************************************************************************
* Lien Project Gutenber Reader is a reader for Project Gutenberg ebook       *
* Copyright (C) 2002 Tan Chee Kien. See file COPYING for licence details     *
*                                                                            *
*    This program is free software; you can redistribute it and/or modify    *
*    it under the terms of the GNU General Public License as published by    *
*    the Free Software Foundation; either version 2 of the License, or       *
*    any later version.                                                      *
*                                                                            *
*    This program is distributed in the hope that it will be useful,         *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of          *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           *
*    GNU General Public License for more details.                            *
*                                                                            *
*    You should have received a copy of the GNU General Public License       *
*    along with this program; if not, write to the Free Software             *
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307    *  
*    USA                                                                     *
*                                                                            *
*    You can contact the author by sending an email to :                     *
*       gogota321@yahoo.com                                                  *
*    or write a letter to :                                                  *
*    Tan Chee Kien, No. 33, Kampung Tembaga Dayak, Sematan, 94500 Lundu ,Sar *
*    awak, Malaysia                                                          *
*****************************************************************************/

#include <ncurses.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "lpgr.h"
static WINDOW  *buttomwin;

void
control(const char *const filename, unsigned int pages)
{
    static BOOKINFO book;
    FILE           *stream;
    int             key;
    unsigned int    count;
    unsigned int    page;
    int             returncode = NOTFINISH;
    char            pagenum[6];
    long            pages_location[pages];	// array to hold pages
    // location

    buttomwin = newwin(1, COLS, LINES - 1, 0);

    book.pagenow = 1;
    strncpy(book.name, filename, MAX_CHAR_4_FILENAME);
    keypad(buttomwin, TRUE);
    typeahead(-1);
    book.totalpage = pages;

    stream = fopen(filename, "r");
    for (count = 0; count < pages; count++) {
	pages_location[count] = ftell(stream);
	fakeread(stream);
	// erase();
	// printw("%ld",pages_location[count]);
	// refresh();
	// getch();
    }

    rewind(stream);

    while (1) {
	returncode = printpage(stream);
	tellinfo(book);
	key = wgetch(buttomwin);
	switch (key) {
	case DOWN_ARROW:
	    {
		if (returncode != FINISH) {
		    book.pagenow++;
		    continue;
		} else {
		    gotopage(book.pagenow, stream, pages_location);
		    continue;
		}
	    }

	case UP_ARROW:
	    {
		if (book.pagenow == 1) {
		    gotopage(book.pagenow, stream, pages_location);
		    continue;
		} else {
		    gotopage(book.pagenow - 1, stream, pages_location);
		    book.pagenow--;
		    continue;
		}
	    }

	case HOME:
	    {
		gotopage(1, stream, pages_location);
		book.pagenow = 1;
		continue;
	    }

	case END:
	    {
		gotopage(book.totalpage, stream, pages_location);
		book.pagenow = book.totalpage;
		continue;
	    }

	case PAGEUP:
	    {
		if (book.pagenow > 10) {
		    gotopage(book.pagenow - 10, stream, pages_location);
		    book.pagenow = book.pagenow - 10;
		} else
		    gotopage(book.pagenow, stream, pages_location);
		continue;
	    }

	case PAGEDOWN:
	    {
		if (book.pagenow + 10 <= book.totalpage) {
		    gotopage(book.pagenow + 10, stream, pages_location);
		    book.pagenow = book.pagenow + 10;
		} else
		    gotopage(book.pagenow, stream, pages_location);
		continue;
	    }

	case 'p':
	case 'P':
	    {
		echo();
		werase(buttomwin);
		wprintw(buttomwin,
			"Please enter the page you want to go to : ");
		wrefresh(buttomwin);
		wgetnstr(buttomwin, pagenum, 5);
		page = (unsigned int) atoi(pagenum);
		if ((page > 0) && (page <= book.totalpage))	// check ok
		{
		    gotopage(page, stream, pages_location);
		    book.pagenow = page;
		    continue;
		} else {
		    werase(buttomwin);
		    wprintw(buttomwin, "No such page !!?");
		    wrefresh(buttomwin);
		    sleep(2);
		    gotopage(book.pagenow, stream, pages_location);
		    continue;
		}
	    }

	case 'q':
	case 'Q':
	    disable_curses_and_exit(0);

	case 'b':
	case 'B':
	    {
		if (bookmark(book.pagenow, filename) == GOOD) {
		    werase(buttomwin);
		    wprintw(buttomwin, "Bookmark save successful");
		    wrefresh(buttomwin);
		    sleep(2);
		} else {
		    werase(buttomwin);
		    wprintw(buttomwin,
			    "Failed to save bookmark - check to see your home directory is writeable");
		    wrefresh(buttomwin);
		    sleep(2);
		}
		gotopage(book.pagenow, stream, pages_location);
		continue;
	    }

	case 'l':
	case 'L':
	    {
		keypad(stdscr, TRUE);
		erase();
		printw
		    ("This program is free software; you can redistribute it and/or modify\n");
		printw
		    ("it under the terms of the GNU General Public License as published by\n");
		printw
		    ("the Free Software Foundation; either version 2 of the License, or\n");
		printw("any later version.\n\n");
		printw
		    ("This program is distributed in the hope that it will be useful,\n");
		printw
		    ("but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
		printw
		    ("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
		printw("GNU General Public License for more details.\n\n");
		printw
		    ("You should have received a copy of the GNU General Public License\n");
		printw
		    ("along with this program; if not, write to the Free Software\n");
		printw
		    ("Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA\n");

		refresh();
		getch();
		keypad(buttomwin, TRUE);
		gotopage(book.pagenow, stream, pages_location);
		continue;
	    }

	case 'g':
	case 'G':
	    {
		if (findbookmark(book.name, &page) != BAD) {
		    if (page <= book.totalpage) {
			gotopage(page, stream, pages_location);
			book.pagenow = page;
			werase(buttomwin);
			wprintw(buttomwin, "going to page %u", page);
			wrefresh(buttomwin);
			sleep(1);
			continue;
		    } else {
			gotopage(book.pagenow, stream, pages_location);
			werase(buttomwin);
			wprintw(buttomwin, "no such page !!");
			wrefresh(buttomwin);
			sleep(2);
			continue;
		    }
		} else {
		    werase(buttomwin);
		    wprintw(buttomwin,
			    "There are no bookmark for this file...sorry...");
		    wrefresh(buttomwin);
		    gotopage(book.pagenow, stream, pages_location);
		    sleep(2);
		    continue;
		}
	    }

	case 'h':
	case 'H':
	    {
		keypad(stdscr, TRUE);
		erase();
		addch(ACS_DARROW);
		printw(" : go down a page\n");
		addch(ACS_UARROW);
		printw(" : go up a page\n");
		printw("pagedown : down 10 pages\n");
		printw("pageup : up 10 pages\n");
		printw("home : beginning of file\n");
		printw("end : end of file\n");
		printw("b : Bookmark this page\n");
		printw("g : Go to bookmark that was set for this file\n");
		printw("p : go to a particular page\n");
		printw("l : Show License\n");
		printw("q : Quit from this program\n\n");
		printw("Press any key to quit form this help screen");
		refresh();
		getch();
		keypad(buttomwin, TRUE);
		gotopage(book.pagenow, stream, pages_location);
		continue;
	    }

	default:
	    {
		gotopage(book.pagenow, stream, pages_location);
		continue;
	    }
	}
    }

    tellinfo(book);

    fclose(stream);

}

void
tellinfo(const BOOKINFO book)
{
    werase(buttomwin);
    wprintw(buttomwin, "%u / %u, file : %s  h for help", book.pagenow,
	    book.totalpage, book.name);
    wnoutrefresh(buttomwin);
    doupdate();
}

void
gotopage(const unsigned int page_num,
	 FILE * source, const long *const pages_location)
{
    fseek(source, *(pages_location + (page_num - 1)), SEEK_SET);
    return;
}
