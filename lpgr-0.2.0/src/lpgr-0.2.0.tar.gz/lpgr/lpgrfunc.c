/*****************************************************************************
* Lien Project Gutenber Reader is a reader for Project Gutenberg ebook       *
* Copyright (C) 2002 Tan Chee Kien. See file COPYING for licence details     *
*                                                                            *
*    This program is free software; you can redistribute it and/or modify    *
*    it under the terms of the GNU General Public License as published by    *
*    the Free Software Foundation; either version 2 of the License, or       *
*    any later version.                                                      *
*                                                                            *
*    This program is distributed in the hope that it will be useful,         *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of          *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           *
*    GNU General Public License for more details.                            *
*                                                                            *
*    You should have received a copy of the GNU General Public License       *
*    along with this program; if not, write to the Free Software             *
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307    *  
*    USA                                                                     *
*                                                                            *
*    You can contact the author by sending an email to :                     *
*    Malaysia                                                                *
*       gogota321@yahoo.com                                                  *
*    or write a letter to :                                                  *
*    Tan Chee Kien, No. 33, Kampung Tembaga Dayak, Sematan, 94500 Lundu ,Sar *
*    awak, Malaysia                                                          *
*****************************************************************************/

#include <stdlib.h>
#include <ncurses.h>
#include <ctype.h>
#include "lpgr.h"
#include "config.h"

void
disable_curses_and_exit(int k)
{
    erase();
    refresh();
    endwin();
    printf("Lien Project Gutenberg Ebooks Reader Version %s\n", LPGR_VERSION);
    printf("By Tan Chee Kien <gogota321@yahoo.com>\n");
    printf("Web site : http://lpgr.sourceforge.net\n");
    printf("Get Thousand of free ebooks from http://promo.net/pg\n");
    printf("My other open source project : Lien Mp3 Player\n");
    printf("http://freshmeat.net/projects/lienmp3\n\n");
    printf
	("This program is free software; you can redistribute it and/or modify\n");
    printf
	("it under the terms of the GNU General Public License as published by\n");
    printf
	("the Free Software Foundation; either version 2 of the License, or\n");
    printf("any later version.\n\n");
    printf
	("This program is distributed in the hope that it will be useful,\n");
    printf
	("but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
    printf("MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
    printf("GNU General Public License for more details.\n\n");
    printf
	("You should have received a copy of the GNU General Public License\n");
    printf("along with this program; if not, write to the Free Software\n");
    printf
	("Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA\n");

    exit(EXIT_SUCCESS);
}

void
start_ncurses(void)
{
    initscr();
    curs_set(0);
    noecho();
    nonl();
    keypad(stdscr, TRUE);
    start_color();
    init_pair(TEXT_COLOR, TEXT, BACKGROUND);
    init_pair(LINE_COLOR, LINE, BACKGROUND);
    init_pair(MENUBACK_COLOR, MENUTEXT, MENUBACK);
    init_pair(MENUBOX_COLOR, MENUBOX, MENUBACK);
}

void
cur_error(char *errortext)
{
    endwin();
    printf("%s\n", errortext);
    exit(EXIT_FAILURE);
}
