/*****************************************************************************
* Lien Project Gutenber Reader is a reader for Project Gutenberg ebook       *
* Copyright (C) 2002 Tan Chee Kien. See file COPYING for licence details     *
*                                                                            *
*    This program is free software; you can redistribute it and/or modify    *
*    it under the terms of the GNU General Public License as published by    *
*    the Free Software Foundation; either version 2 of the License, or       *
*    any later version.                                                      *
*                                                                            *
*    This program is distributed in the hope that it will be useful,         *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of          *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           *
*    GNU General Public License for more details.                            *
*                                                                            *
*    You should have received a copy of the GNU General Public License       *
*    along with this program; if not, write to the Free Software             *
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307    *  
*    USA                                                                     *
*                                                                            *
*    You can contact the author by sending an email to :                     *
*       gogota321@yahoo.com                                                  *
*    or write a letter to :                                                  *
*    Tan Chee Kien, No. 33, Kampung Tembaga Dayak, Sematan, 94500 Lundu ,Sar *
*    awak, Malaysia                                                          *
*****************************************************************************/

#ifndef LPGR_H_
#define LPGR_H_

#define LPGR_VERSION "0.2.0"

#define MAX_RECENT_FL_ITEM 50

#define LPGR_CONF_DIR "/.lpgr0.1conf/"

#define YES 1
#define NO 0

#define LEFT 1
#define RIGHT 2

#define FINISH 1
#define NOTFINISH 2

#define GOOD 1
#define BAD 2

#define DOWN_ARROW 258
#define UP_ARROW 259
#define HOME 262
#define END 360
#define PAGEUP 339
#define PAGEDOWN 338
#define ENTER 13

#define MAX_LETTER_PER_LINE 39	//should be this number - 1 but you need the '\0'
#define MAX_CHAR_4_FILENAME 40

#define TEXT_COLOR 1
#define LINE_COLOR 2
#define MENUBACK_COLOR 3
#define MENUBOX_COLOR 4

#define BACKGROUND COLOR_BLACK

struct bookinfo
{
  unsigned int pagenow;
  unsigned int totalpage;
  char name[MAX_CHAR_4_FILENAME];
};
typedef struct bookinfo BOOKINFO;


void start_ncurses (void);

void disable_curses_and_exit (int k);

int printpage (FILE * source);

int fakeread (FILE * source);

//the main control center , pages is total pages  
void control (const char *const filename, unsigned int pages);

//output error message, disable ncurses and exit
void cur_error (char *errortext);

//output book name, total pages and page now at buttom of screen
void tellinfo (const BOOKINFO book);

void gotopage (const unsigned int page_num,
	       FILE * source, const long *const pages_location);

// return GOOD if everything is fine, BAD if not, make a bookmark
int bookmark (const unsigned int page_num, const char *const filename);

//change /usr/doc/book/abc.txt to abc.txt
char *filtername (const char *const original);

//change /usr/doc/book/abc.txt to /usr/doc/book, return NULL if no slash found
char *killname (const char *const original);

//return GOOD or BAD , will modify markpage to point out the correct page
int findbookmark (const char *const filename, unsigned int *const markpage);

void givehelp (void);

//check to see if recent filelist exist, if not, return 0, else 
//return total of file that has been opened b4(should not more then 
//MAX_RECENT_FL_ITEM)
int init_recent_fl (void);

//make a new recent fl, beware that dirname should end with /
// return GOOD or BAD
int make_recent_fl (const char *const dirname, const char *const filename);

//append dirname(should end with /) and filename to recent fl
//return GOOD or BAD
int append_2_recent_fl (const char *const dirname,
			const char *const filename);

//remove 1 item from recent filelist so that next item can fit in
void reduce_item_from_recent_fl (void);

char *rfmenu (void);

#endif //__LPGR_H
