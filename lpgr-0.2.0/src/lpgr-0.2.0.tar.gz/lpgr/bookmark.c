/*****************************************************************************
* Lien Project Gutenber Reader is a reader for Project Gutenberg ebook       *
* Copyright (C) 2002 Tan Chee Kien. See file COPYING for licence details     *
*                                                                            *
*    This program is free software; you can redistribute it and/or modify    *
*    it under the terms of the GNU General Public License as published by    *
*    the Free Software Foundation; either version 2 of the License, or       *
*    any later version.                                                      *
*                                                                            *
*    This program is distributed in the hope that it will be useful,         *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of          *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           *
*    GNU General Public License for more details.                            *
*                                                                            *
*    You should have received a copy of the GNU General Public License       *
*    along with this program; if not, write to the Free Software             *
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307    *  
*    USA                                                                     *
*                                                                            *
*    You can contact the author by sending an email to :                     *
*       gogota321@yahoo.com                                                  *
*    or write a letter to :                                                  *
*    Tan Chee Kien, No. 33, Kampung Tembaga Dayak, Sematan, 94500 Lundu ,Sar *
*    awak, Malaysia                                                          *
*****************************************************************************/


#include <sys/stat.h>
#include <ncurses.h>
#include "lpgr.h"
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int
bookmark(const unsigned int page_num, const char *const filename)
{
    char            full_name[300];
    FILE           *bmstream;
    char           *fixedname;
    int             returncode = GOOD;

    strncpy(full_name, getenv("HOME"), 300);
    strcat(full_name, LPGR_CONF_DIR);

    mkdir(full_name, S_IRWXU);
    fixedname = filtername(filename);

    strcat(full_name, fixedname);


    if ((bmstream = fopen(full_name, "w")) == NULL)
	returncode = BAD;
    else {
	fprintf(bmstream, "%u\n", page_num);
	fclose(bmstream);
    }

    return returncode;
}


int
findbookmark(const char *const filename, unsigned int *const markpage)
{
    char            full_name[300];
    FILE           *bmstream;
    char           *fixedname;
    int             returncode = GOOD;

    strncpy(full_name, getenv("HOME"), 300);
    strcat(full_name, LPGR_CONF_DIR);

    fixedname = filtername(filename);

    strcat(full_name, fixedname);


    if ((bmstream = fopen(full_name, "r")) == NULL)
	returncode = BAD;
    else {
	fscanf(bmstream, "%u", markpage);
	// erase();
	// printw("%u",*markpage);
	// refresh();
	// getch();
	fclose(bmstream);
    }

    return returncode;
}

char           *
filtername(const char *const original)
{

    int             a, c;
    int             b = 0;
    int             totalslash = 0;
    char           *cutshort;

    cutshort = (char *) malloc(250 * sizeof(char));

    for (a = 0; original[a] != '\0'; a++) {
	if (original[a] == '/')
	    totalslash++;
    }

    if (totalslash == 0)
	strcpy(cutshort, original);

    else {
	for (a = 0; original[a] != '\0'; a++) {
	    if (original[a] == '/') {
		b++;
		if (b == totalslash) {
		    for (c = 0; original[a + 1] != '\0'; c++) {
			cutshort[c] = original[a + 1];
			a++;
		    }
		    cutshort[c] = '\0';
		    break;
		}
	    }
	}
    }

    return cutshort;
}

char           *
killname(const char *const original)
{

    int             a;
    int             totalslash = 0, foundslash = 0;
    char           *cutshort;

    cutshort = (char *) malloc(250 * sizeof(char));

    for (a = 0; original[a] != '\0'; a++) {
	if (original[a] == '/')
	    totalslash++;
    }

    if (totalslash == 0)
	return NULL;

    else {
	for (a = 0; foundslash < totalslash; a++) {
	    if (original[a] == '/')
		foundslash++;
	    cutshort[a] = original[a];
	}
	return cutshort;
    }

}
