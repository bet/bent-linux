/* ***************************************************************
 * OK, here you can adjust the colour to whatever you like.
 * The valid colour is :
 *    COLOR_BLACK
 *    COLOR_RED
 *    COLOR_GREEN
 *    COLOR_YELLOW
 *    COLOR_BLUE
 *    COLOR_MAGENTA
 *    COLOR_CYAN
 *    COLOR_WHITE
 * 
 *  run make and install again after editing this file !! enjoy !
 * ****************************************************************/

/******************************************************************
 * READING SECTION
 * ****************************************************************/

/* the text colour of the book you are reading. Default is green */
#define TEXT COLOR_GREEN

/* the colour of the line at the middle. Default is white */
#define LINE COLOR_WHITE

/* Make TEXT brighter, set it to 1 if you're using dark text */
#define MAKE_TEXT_BRIGHT 1

/*****************************************************************
 * MENU SECTION
 * **************************************************************/

/* Background. Default is blue */
#define MENUBACK COLOR_BLUE

/* Text within menu. Default is yellow */
#define MENUTEXT COLOR_YELLOW

/* the color of the border, default is white */
#define MENUBOX COLOR_WHITE
