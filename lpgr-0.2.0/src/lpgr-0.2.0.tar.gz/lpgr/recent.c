/*****************************************************************************
* Lien Project Gutenber Reader is a reader for Project Gutenberg ebook       *
* Copyright (C) 2002 Tan Chee Kien. See file COPYING for licence details     *
*                                                                            *
*    This program is free software; you can redistribute it and/or modify    *
*    it under the terms of the GNU General Public License as published by    *
*    the Free Software Foundation; either version 2 of the License, or       *
*    any later version.                                                      *
*                                                                            *
*    This program is distributed in the hope that it will be useful,         *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of          *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           *
*    GNU General Public License for more details.                            *
*                                                                            *
*    You should have received a copy of the GNU General Public License       *
*    along with this program; if not, write to the Free Software             *
*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307    *  
*    USA                                                                     *
*                                                                            *
*    You can contact the author by sending an email to :                     *
*       gogota321@yahoo.com                                                  *
*    or write a letter to :                                                  *
*    Tan Chee Kien, No. 33, Kampung Tembaga Dayak, Sematan, 94500 Lundu ,Sar *
*    awak, Malaysia                                                          *
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lpgr.h"
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include "recent.h"

int
init_recent_fl(void)
{
    int             count = 0;
    char            full_name[300];
    char            temp[300];
    FILE           *stream;

    strncpy(full_name, getenv("HOME"), 300);
    strcat(full_name, LPGR_CONF_DIR);

    mkdir(full_name, S_IRWXU);
    chdir(full_name);

    if ((stream = fopen("recent.inf", "r")) == NULL) {
	return 0;
    }

    else {
	while (1) {
	    if (fscanf(stream, "%[^\n]", temp) != 0)
		count++;
	    fscanf(stream, "%[\n]", temp);
	    if (feof(stream) != 0)
		break;
	}
	fclose(stream);
	return count;
    }
}

int
make_recent_fl(const char *const dirname, const char *const filename)
{
    FILE           *stream;
    char            full_name[300];

    strncpy(full_name, getenv("HOME"), 300);
    strcat(full_name, LPGR_CONF_DIR);

    mkdir(full_name, S_IRWXU);
    chdir(full_name);
    if ((stream = fopen("recent.inf", "w")) == NULL) {
	printf("Error, unable to create filelist !!\n");
	printf
	    ("Make sure you have write permission in your home directory\n");
	printf("this message will vanish in 5 seconds\n");
	sleep(5);
	return BAD;
    } else {
	fprintf(stream, "%s%s\n", dirname, filename);
	fclose(stream);
	return GOOD;
    }
}

int
append_2_recent_fl(const char *const dirname, const char *const filename)
{
    FILE           *stream;
    char            full_name[300];

    strncpy(full_name, getenv("HOME"), 300);
    strcat(full_name, LPGR_CONF_DIR);

    // mkdir (full_name, S_IRWXU);
    chdir(full_name);
    if (check_if_item_exist(dirname, filename) == NO) {

	if ((stream = fopen("recent.inf", "a")) == NULL) {
	    printf("Error, unable to append to filelist !!\n");
	    printf
		("Make sure you have write permission in your home directory\n");
	    printf("this message will vanish in 5 seconds\n");
	    sleep(5);
	    return BAD;
	} else {
	    fprintf(stream, "%s%s\n", dirname, filename);
	    fclose(stream);
	    return GOOD;
	}
    } else
	return GOOD;
}

int
check_if_item_exist(const char *const dirname, const char *const filename)
{
    char            full_name[300];
    char            itemname[300];
    char            item_temp[300];
    FILE           *stream;
    int             returncode = NO;

    strncpy(full_name, getenv("HOME"), 300);
    strcat(full_name, LPGR_CONF_DIR);

    chdir(full_name);

    if ((stream = fopen("recent.inf", "r")) == NULL)
	return returncode;
    else {
	strncpy(itemname, dirname, 300);
	strcat(itemname, filename);
	while (feof(stream) == 0) {
	    fscanf(stream, "%[^\n]", item_temp);
	    if (strncmp(item_temp, itemname, 300) == 0)
		returncode = YES;
	    memset(item_temp, 0, 300 * (sizeof(char)));
	    fscanf(stream, "%[\n]", item_temp);
	    memset(item_temp, 0, 300 * (sizeof(char)));
	}
	fclose(stream);
	return returncode;
    }
}

void
reduce_item_from_recent_fl(void)
{
    char            full_name[300];
    char            item_temp[300];
    char           *tmpfile;
    FILE           *stream, *tmpstream;
    int             count = 0;
    int             a;

    strncpy(full_name, getenv("HOME"), 300);
    strcat(full_name, LPGR_CONF_DIR);

    chdir(full_name);

    tmpfile = tmpnam(NULL);
    tmpstream = fopen(tmpfile, "w");
    stream = fopen("recent.inf", "r");
    while (feof(stream) == 0) {
	fscanf(stream, "%[^\n]", item_temp);
	if (count != 0) {
	    fprintf(tmpstream, "%s\n", item_temp);
	}
	count++;
	fscanf(stream, "%[\n]", item_temp);
	memset(item_temp, 0, 300 * sizeof(char));
    }

    fclose(stream);
    unlink("recent.inf");
    fclose(tmpstream);
    tmpstream = fopen(tmpfile, "r");

    stream = fopen("recent.inf", "w");
    while ((a = fgetc(tmpstream)) != EOF)	// copy everything from
	// tempfile to recent.inf
	fputc(a, stream);
    fclose(stream);
    fclose(tmpstream);
    unlink(tmpfile);
}
