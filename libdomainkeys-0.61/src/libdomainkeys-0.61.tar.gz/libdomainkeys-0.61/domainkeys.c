#include <sys/types.h>
#include <ctype.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <stdio.h>

extern char *dns_txt(char *);

/* STARTHEAD */
/* Copyright Yahoo, Inc. 2004.
 * Redistribution beyond the Domain Signs List not permitted.
 * In time a proper open source license will available.
 */

#ifdef SWIG
%module domainkeys
%{
#include "domainkeys.h"
%}
#endif

typedef enum {
		      DK_STAT_OK, /* Function completed successfully */
		      DK_STAT_BADSIG, /* Signature was available but failed to verify against domain specified key */
		      DK_STAT_NOSIG, /* No signature available in message */
		      DK_STAT_NOKEY, /* No public key available (permanent failure) */
		      DK_STAT_BADKEY, /* Unusable key, public if verifying, private if signing */
		      DK_STAT_CANTVRFY, /* Cannot get domain key to verify signature (temporary failure) */
		      DK_STAT_SYNTAX, /* Message is not valid syntax. Signature could not be created/checked */
		      DK_STAT_NORESOURCE, /* Could not get critical resource (temporary failure) */
		      DK_STAT_ARGS, /* Arguments are not usable. */
		      DK_STAT_REVOKED,    /* Key has been revoked. */
		      DK_STAT_INTERNAL,	/* cannot call this routine in this context.  Internal error. */
		      } DK_STAT;

typedef enum {
  DK_FLAG_TESTING = 1,		/* set when in testing mode. */
  DK_FLAG_SIGNSALL = 2,		/* domain signs all outgoing email. */
} DK_FLAGS;

typedef struct {
/* STARTPRIV */
  const EVP_MD *md;
/* STOPPRIV */
} DK_LIB;

typedef struct {
/* STARTPRIV */
#define DKMARK ('D' | 'K'<<8 | 'E'<<16 | 'Y'<<24)
  int dkmarker;
  EVP_MD_CTX mdctx;
#define DK_SIGNING_SIGN 0
#define DK_SIGNING_VERIFY 1
#define DK_SIGNING_NOSIGN 2
#define DK_SIGNING_NOVERIFY 3
  int signing;
  int in_headers;
  char *header;
  int headerlen;
  int headermax;
  int headerlinelen;
  char *from;
  char *dksign;
  int errline;
  char *errfile;
/* STOPPRIV */
} DK;

/* STOPHEAD */

#define DKERR(x) ((dk->errline=__LINE__),(dk->errfile=__FILE__),(x))

/* HEADER */
/* returns the source file from which an error was returned. */
char * dk_errfile(DK *dk)
{
  return dk->errfile;
}

/* HEADER */
/* returns the source line number from which an error was returned. */
int dk_errline(DK *dk)
{
  return dk->errline;
}

/* HEADER */
/* Per-process, one-time initialization
 * Returns library structure for subsequent dk_sign or dk_verify calls.
 * Consult statp before using.
 */
DK_LIB *dk_init(DK_STAT *statp)
{
  DK_LIB *dklib;

  dklib = malloc(sizeof(DK_LIB));
  if (!dklib) {
    if (statp) *statp = DK_STAT_NORESOURCE;
    return NULL;
  }
  dklib->md = EVP_sha1();
  if (!dklib->md) {
    if (statp) *statp = DK_STAT_INTERNAL;
    free(dklib);
    return NULL;
  }
  if (statp) *statp = DK_STAT_OK;
  return dklib;
}

/* start a new header */
static DK_STAT
dkinit_new_header(DK *dk)
{
  dk->headermax = 1024;
  dk->header = malloc(dk->headermax);
  if (!dk->header) return DKERR(DK_STAT_NORESOURCE);
  dk->headerlen = 0;
  dk->headerlinelen = 1;	/* always store the first char. */
  dk->in_headers = 1;
  dk->from = NULL;
  dk->dksign = NULL;
  return DKERR(DK_STAT_OK);
}

static DK_STAT
dkstore_char(DK *dk, char ch)
{
  if (dk->headerlen >= dk->headermax) {
    char *hp;
    hp = malloc(dk->headermax * 2 + 1024 + 1); /* leave room for null */
    if (!hp) return DKERR(DK_STAT_NORESOURCE);
    if (dk->headermax) {
      memcpy(hp, dk->header, dk->headerlen);
      free(dk->header);
    }
    dk->header = hp;
    dk->headermax = dk->headermax * 2 + 1024;
  }
  dk->header[dk->headerlen++] = ch;
  dk->headerlinelen++;
  return DKERR(DK_STAT_OK);
}

static void
dkempty(DK *dk)
{
  dk->headermax = 0;
}

/* HEADER */
/* Per-message, may be threaded.
 * Returns state structure for operation.  Consult statp before using.
 */
DK       *dk_sign(DK_LIB *dklib, DK_STAT *statp)
{
  DK *dk;
  BIO *rbio;

  dk = malloc(sizeof(DK));
  if (!dk) {
    if (statp) *statp = DKERR(DK_STAT_NORESOURCE);
    return NULL;
  }
  dk->dkmarker = DKMARK;
  dk->signing = DK_SIGNING_SIGN;
  if (dkinit_new_header(dk) != DK_STAT_OK) {
    /* couldn't malloc a header. */
    free(dk);
    if (statp) *statp = DKERR(DK_STAT_NORESOURCE);
    return NULL;
  }
  EVP_SignInit(&dk->mdctx, dklib->md);

  if (statp) *statp = DKERR(DK_STAT_OK);
  return dk;
}

/* HEADER */
/* Per-message, may be threaded.
 * Returns state structure for operation.  Consult statp before using.
 * id is printable opaque, used for printing in messages.
 */
DK      *dk_verify(DK_LIB *dklib,
                   DK_STAT *statp)
{
  DK *dk;

  dk = malloc(sizeof(DK));
  if (!dk) {
    if (statp) *statp = DKERR(DK_STAT_NORESOURCE);
    return NULL;
  }
  dk->dkmarker = DKMARK;
  dk->signing = DK_SIGNING_NOVERIFY; /* don't sign until after. */
  if (dkinit_new_header(dk) != DK_STAT_OK) {
    /* couldn't malloc a header. */
    free(dk);
    if (statp) *statp = DKERR(DK_STAT_NORESOURCE);
    return NULL;
  }
  EVP_VerifyInit(&dk->mdctx, dklib->md);

  if (statp) *statp = DKERR(DK_STAT_OK);
  return dk;
}

/* HEADER */
/* Must NOT include dots inserted for SMTP encapsulation.
 * Must NOT include CRLF.CRLF which terminates the message.
 * Otherwise must be exactly that which is sent or received over the SMTP session.
 * May be called multiple times (not necessary to read an entire message into memory).
 */
DK_STAT   dk_message(DK *dk, const unsigned char *ptr, size_t len)
{
  if (!dk) return DK_STAT_ARGS;
  if (dk->dkmarker != DKMARK) return DK_STAT_ARGS;
  if (len && !ptr) return DKERR(DK_STAT_ARGS);
  if (dk->in_headers) {
    while (len--) {

      /* parse headers */
      if (!dk->in_headers) {
	/* once we hit the end of headers, stop examining headers. */
      } else if (*ptr == '\n' && dk->headerlinelen != 0) {
	/* beginning a new line, but we can't do anything until we get a char. */
	dk->headerlinelen = 0;
      } else if (*ptr == '\r') {
	/* ignore carriage-returns, even bare ones. */
      } else {
	/* we have a char. */
	if (*ptr == ' ' || *ptr == '\t' || dk->headerlinelen != 0) {
	  /* If it's whitespace (continuation), or we're not at the beginning of a line, remember it */
	  if (dkstore_char(dk, *ptr) != DK_STAT_OK)
	    return DKERR(DK_STAT_NORESOURCE);
	} else {
	  /* we're starting a new header.  Process the previous one. */
	  dk->header[dk->headerlen] = '\0';
	  if (!strncasecmp(dk->header, "From:", 5)) {
	    /* Remember the From: and forget the current. */
	    if (dk->from) {
	      /* if we already got a From: header, fuhgeddabout it. */
	      return DKERR(DK_STAT_SYNTAX);
	    }
	    dk->from = dk->header;
	    dkempty(dk);
	    if (dk->signing == DK_SIGNING_VERIFY && !dk->dksign) {
	      /* if we got a From: prior to dksign, fuhgeddabout it. */
	      return DKERR(DK_STAT_SYNTAX);
	    }
	  } else if (!strncasecmp(dk->header, "DomainKey-Signature:", 20)) {
	    /* Remember the DomainKey-Signature: and forget the current. */
	    dk->dksign = dk->header;
	    dkempty(dk);
	    /* restart the verifying */
	    dk->signing = DK_SIGNING_VERIFY; /* the signature starts here */
	  } else if (dk->signing == DK_SIGNING_SIGN && dk->dksign) {
	    /* Once we've gotten to the header after the dksign, stop signing. */
	    dk->signing = DK_SIGNING_NOSIGN;
	  } 
	  dk->headerlen = 0;	/* restart header gathering. */
	  dk->headerlinelen = 0;

	  if (*ptr == '\n') {
	    /* blank line.  End of headers. */
	    dk->in_headers = 0;
	    if (dk->signing == DK_SIGNING_NOVERIFY && !dk->dksign) {
	      /* if we never got a dksign header, fuhgeddabout it. TC17 */
	      return DKERR(DK_STAT_NOSIG);
	    }
	    if (!dk->from) {
	      /* No From:, fuhgeddabout it.  TC11/TC16 */
	      return DKERR(DK_STAT_SYNTAX);
	    }
	  } else {
	    /* remember the first character of a new header. */
	    if (dkstore_char(dk, *ptr) != DK_STAT_OK)
	      return DKERR(DK_STAT_NORESOURCE);
	  }
	}
      }

      switch(dk->signing) {
      case DK_SIGNING_SIGN:
	/* look for the DK header and stop computing digest. */
	EVP_SignUpdate(&dk->mdctx, ptr, 1);
	break;
      case DK_SIGNING_VERIFY:
	/* look for the DK header and remember stuff about it. */
	EVP_VerifyUpdate(&dk->mdctx, ptr, 1);
	break;
      }
      ptr++;
    }
  } else {
#ifdef DO_BODY_RIGHT
    while (len--) {
      if (*ptr == '\r') dk->state++;
      else if (*ptr == '\n')
      if (dk->state && (dk->state & 1) && *ptr == '\r')
      switch(dk->state) {
      case 0:
	if (*ptr == '\r')
      }
      switch(dk->signing) {
      case DK_SIGNING_SIGN:
	EVP_SignUpdate(&dk->mdctx, ptr, 1);
	break;
      case DK_SIGNING_VERIFY:
	EVP_VerifyUpdate(&dk->mdctx, ptr, 1);
	break;
      }
      ptr++;
    }
#else /* ! DO_BODY_RIGHT */
    switch(dk->signing) {
    case DK_SIGNING_SIGN:
      EVP_SignUpdate(&dk->mdctx, ptr, len);
      break;
    case DK_SIGNING_VERIFY:
      EVP_VerifyUpdate(&dk->mdctx, ptr, len);
      break;
    }
#endif
  }
  return DKERR(DK_STAT_OK);
}

/* HEADER */
/* Returns a pointer to the domain name portion of an RFC 2822 address.
 * Inserts a null after the end of the domain name.
 * return NULL if no domain name found.
 * return NULL if no From: field has yet been found.
 * return NULL if the dk is unusable for any reason.
 * return NULL if the From: field is unusable for any reason.
 */
char *
dk_from(DK *dk)
{
  int angle = 0;		/* true if it's in angle brackets */
  char *domain = NULL;
  char *from, *to;
  int level = 1;

  if (!dk) return NULL;
  if (dk->dkmarker != DKMARK) return NULL;
  if (!dk->from) return NULL;

  from = dk->from;
  if (strncmp(from, "From:", 5)) {
    /* we've already been here and deleted the From: */
    return dk->from;
  }
  to = from;
  while (*from) {		/* nuke comments. */
    if (*from == ')') {
      return dk->from = NULL; /* unusable */
    } else if (*from == '\\' && from[1]) {
      /* skip backslash-quoted characters */
      *to++ = *from++;
      *to++ = *from++;
    } else if (*from == '"') {
      /* we have to ignore parenthesis inside quotes. */
      level = 1;
      from++;
      while (level) {
	if (*from == '\0') return dk->from = NULL; /* unusable */
	else if (*from == '"') --level;
        else if (*from == '\\' && from[1]) *to++ = *from++;
	*to++ = *from++;
      }
    } else if (*from == '(') {
      level = 1;
      from++;
      while (level) {
	if (*from == '\0') return dk->from = NULL; /* unusable */
	else if (*from == '(') ++level;
	else if (*from == ')') --level;
        else if (*from == '\\' && from[1]) ++from;
	++from;
      }
    } else if (*from == ' ') {
      ++from;
    } else if (*from == '\t') {
      ++from;
    } else {
      *to++ = *from++;
    }
  }
  *to = '\0';
  from = dk->from;
  while (*from) {
    if (*from == '@') {
      domain = from + 1;
    } else if (*from == '\\' && from[1]) {
      ++from;
    } else if (*from == '<') {
      angle = 1;
    } else if (angle && *from == '>') {
      *from = '\0';
      break;
    } else if (domain && *from == ' ') {
      *from = '\0';
      break;
    } else if (domain && *from == ';') {
      *from = '\0';
      break;
    } else if (domain && *from == '\t') {
      *from = '\0';
      break;
    }
    from++;
  }
  return dk->from = domain;
}

/* Given a list of key=value; pairs, find all the keys found in letters.
 * Store the value in the corresponding entry in values[].
 * Modifies list to insert nulls in the place of the semicolons which terminate
 * each of the values except possibly the last.
 * You can only call dkparselist() once on a given list.
 * caller must ensure that values[] is as large as strlen(letters)
 */

static DK_STAT
dkparselist(char *list, char *letters, char *values[])
{
  char key;
  int i;
  char *value;

  /* start with all args unset */
  for (i = 0; letters[i]; i++)
    values[i] = NULL;

  key = 0;
  while (*list) {
    if (*list == ' ') {
      /* ignore */
    } else if (*list == '\t') {
      /* ignore */
    } else if (*list == '=') {
      char *ws;

      ++list;
      value = list;
      ws = list;
      while (1) {
	/* copy up to null or semicolon, deleting whitespace as we go */
	*ws = *list;
        if (*list == '\t') {
	  /* ignore */
	} else if (*list == ' ') {
	  /* ignore */
	} else if (!*list) {
	  break;
	} else if (*list == ';') {
	  *ws = '\0';
	  list++;
	  break;
	} else {
	  ws++;
	}
	list++;
      }
      if (!key) return DK_STAT_SYNTAX; /* we didn't get a key. TC22 */
      /* if we find a matching letter, remember the value */
      for (i = 0; letters[i]; i++) {
	if (key == letters[i]) {
	  if (values[i]) return DK_STAT_SYNTAX; /* no duplicate keys. TC23 */
	  values[i] = value;
	}
      }
      key = 0;
      if (!*list) break;	/* if we hit the end, we're done. */
    } else {
      if (key) return DK_STAT_SYNTAX; /* they already gave us a key. TC24 */
      key = *list;
      if (!islower(key)) return DK_STAT_SYNTAX;	/* must be lowercase letter. TC25 */
    }
    list++;
  }
  return DK_STAT_OK;
}

/* HEADER */
/*
 * Called at end-of-message (before response to DATA-dot, if synchronous with SMTP session).
 * If checking, returns signature validity.
 * Flags are returned indirectly through dkf.
 * This does not calculate the signature.  Call dk_getsig() for that.
 * If you pass in NULL for dkf, the flags will be discarded.
 */
DK_STAT   dk_eom(DK *dk, DK_FLAGS *dkf)
{
  if (!dk) return DK_STAT_ARGS;
  if (dk->dkmarker != DKMARK) return DK_STAT_ARGS;
  switch (dk->signing) {
  case DK_SIGNING_SIGN:
  case DK_SIGNING_NOSIGN:
    if (!dk->from) return DKERR(DK_STAT_SYNTAX);
    return DKERR(DK_STAT_OK);
  case DK_SIGNING_VERIFY:
  case DK_SIGNING_NOVERIFY: {
    unsigned char md_value[1024];
    int md_len, i;
    int size;
    char *dksign;
    char *values[3];  /* "dsb" */
    char *domainkeys; /* malloc'ed */
    char *txtrec; /* malloc'ed */
    char *pubkeyvals[3];
    char pkey[4096]; /* FIXME: acckkkpthththththt */
    int pkeylen;
    int okay;
    char *errorstr;
    DK_STAT st;

    unsigned int siglen;
    unsigned char *sig;
    BIO *bio, *b64;
    EVP_PKEY *publickey;
    unsigned long errornum;

    if (dkf) *dkf = 0;		/* clear flags first. */

    /* make sure that we got a header */
    if (!dk->dksign)
      return DKERR(DK_STAT_NOSIG); /* TC11 */
    /* parse the dksign header .*/
    dksign = dk->dksign + 20;	/* magic number: length of header name */
    if (dkparselist(dksign, "dsb", values) != DK_STAT_OK)
      return DKERR(DK_STAT_SYNTAX);
    if (!values[1] || !values[2]) {
      /* we really do need to have a selector and key. TC21 */
      return DKERR(DK_STAT_NOSIG);
    }

    /* make sure that domain on the From: matches the d data. TC26 */
    if (strcasecmp(values[0], dk_from(dk))) {
      return DKERR(DK_STAT_SYNTAX);
    }

    /* convert their signature from base64 into binary */
    bio = BIO_new_mem_buf(values[2], -1);
    b64 = BIO_new(BIO_f_base64());
    BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
    BIO_push(b64, bio);
    md_len = BIO_read(b64, md_value, sizeof(md_value));
    BIO_free_all(bio);
    if (md_len >= sizeof(md_value)) return DKERR(DK_STAT_NORESOURCE);

    /* get the s data and the d data and lookup s._domainkey.d */
    domainkeys = malloc(strlen(values[1]) + strlen(values[0]) + strlen("._domainkey.") + 1);
    if (!domainkeys) return DKERR(DK_STAT_NORESOURCE);
    sprintf(domainkeys, "%s._domainkey.%s", values[1], values[0]);
    txtrec = dns_txt(domainkeys);
    free(domainkeys);

    if (!strcmp(txtrec,"e=perm;")) /* TC31 */
      return DKERR(DK_STAT_NOKEY);

    if (!strcmp(txtrec,"e=temp;")) /* TC30 */
      return DKERR(DK_STAT_CANTVRFY);

    if (dkparselist(txtrec, "pto", pubkeyvals) != DK_STAT_OK) {
      free(txtrec);
      return DKERR(DK_STAT_BADKEY);
    }

    if (!pubkeyvals[0]) {
      free(txtrec);
      return DKERR(DK_STAT_NOKEY); /* TC27 */
    }

    if (!*pubkeyvals[0]) {
      free(txtrec);
      return DKERR(DK_STAT_REVOKED); /* TC27 */
    }

    if (dkf) {
      /* TC35 and TC37 */
      if (pubkeyvals[1] && *pubkeyvals[1] == 'y')
	*dkf |= DK_FLAG_TESTING;
    }

    /* convert their public key from base64 into binary */
    bio = BIO_new_mem_buf(pubkeyvals[0], -1);
    if (!bio) {
      free(txtrec);
      return DKERR(DK_STAT_NORESOURCE);
    }
    b64 = BIO_new(BIO_f_base64());
    if (!b64) {
      free(txtrec);
      BIO_free(bio);
      return DKERR(DK_STAT_NORESOURCE);
    }
    BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
    BIO_push(b64, bio);
    publickey = d2i_PUBKEY_bio(b64, NULL);
    BIO_free_all(bio);
    free(txtrec);
    if (!publickey) return DKERR(DK_STAT_BADKEY);

    /* using that key, verify that the digest is properly signed */
    okay = EVP_VerifyFinal(&dk->mdctx, md_value, md_len, publickey);
    
    if (okay > 0) {
      st = DK_STAT_OK;
    } else {
      if (dkf) {
	/* TC36 */
	char *policyq, *policyr, *flags[2];

	policyq = malloc(strlen("_domainkey.") + strlen(dk_from(dk)) + 1);
	if (policyq) {
	  sprintf(policyq, "_domainkey.%s", dk_from(dk));
	  policyr = dns_txt(policyq);
	  free(policyq);
	
	  if (!strcmp(policyr,"e=perm;"))
	    ;
	  else if (!strcmp(policyr,"e=temp;"))
	    ;
	  else {
	    dkparselist(policyr, "ot", flags);

	    if (flags[0] && *flags[0] == '-')
	      *dkf |= DK_FLAG_SIGNSALL;
	    if (flags[1] && *flags[1] == 'y')
	      *dkf |= DK_FLAG_TESTING;
	    free(policyr);
	  }
	}
      }
      st = DK_STAT_BADSIG;
    }
    EVP_PKEY_free(publickey);
    return DKERR(st);
  }
  }
}


/* HEADER */
/*
 * 
 * privatekey is the private key used to create the signature; It should contain
 * the entire contents of a PEM-format private key file, thusly it will begin with
 * -----BEGIN RSA PRIVATE KEY-----.  It should be null-terminated.
 */
size_t dk_siglen(void *privatekey)
{
  BIO *bio;
  EVP_PKEY *pkey;
  size_t len;

  if (!privatekey) return 0;

  bio = BIO_new_mem_buf(privatekey, -1);
  pkey = PEM_read_bio_PrivateKey(bio, NULL, NULL, NULL);
  BIO_free(bio);

  len = (EVP_PKEY_size(pkey) + 2) / 3 * 4;
  EVP_PKEY_free(pkey);
  return len;
}


/* HEADER */
/*
 * Sets buf to a null-terminated string.
 * If the message is being signed, signature is stored in the buffer.
 * If the message is being verified, returns DK_STAT_INTERNAL.
 * privatekey is the private key used to create the signature; It should contain
 * the entire contents of a PEM-format private key file, thusly it will begin with
 * -----BEGIN RSA PRIVATE KEY-----.  It should be null-terminated.
 * If you pass in NULL for buf, you'll get back DK_STAT_NORESOURCE.
 * If len is not big enough, you'll get back DK_STAT_NORESOURCE.
 */
DK_STAT   dk_getsig(DK *dk, void *privatekey, unsigned char buf[], size_t len)
{
  if (!dk) return DK_STAT_ARGS;
  if (dk->dkmarker != DKMARK) return DK_STAT_ARGS;
  if (!privatekey) return DK_STAT_ARGS;
  if (!buf) return DKERR(DK_STAT_NORESOURCE);
  switch (dk->signing) {
  case DK_SIGNING_SIGN:
  case DK_SIGNING_NOSIGN: {
    unsigned int siglen;
    unsigned char *sig;
    int size;
    BIO *bio, *b64;
    EVP_PKEY *pkey;

    bio = BIO_new_mem_buf(privatekey, -1);
    pkey = PEM_read_bio_PrivateKey(bio, NULL, NULL, NULL);
    BIO_free(bio);

    if (!pkey) {
      /* their private key is no good TC33 */
      return DKERR(DK_STAT_BADKEY);
    }

    siglen = EVP_PKEY_size(pkey);
    sig = (unsigned char*) OPENSSL_malloc(siglen);
    EVP_SignFinal(&dk->mdctx, sig, &siglen, pkey);
    EVP_PKEY_free(pkey);
    
    bio = BIO_new(BIO_s_mem());
    if (!bio) {
      return DKERR(DK_STAT_NORESOURCE);
    }
    b64 = BIO_new(BIO_f_base64());
    if (!b64) {
      BIO_free(bio);
      return DKERR(DK_STAT_NORESOURCE);
    }
    BIO_set_flags(b64, BIO_FLAGS_BASE64_NO_NL);
    BIO_push(b64, bio);
    if (BIO_write(b64, sig, siglen) < siglen) {
      OPENSSL_free(sig);
      BIO_free_all(bio);
      return DKERR(DK_STAT_NORESOURCE);
    }
    BIO_flush(b64);
    OPENSSL_free(sig);

    size = BIO_read(bio, buf, len);
    BIO_free_all(bio);

    if (size >= len) return DKERR(DK_STAT_NORESOURCE); /* TC28 */

    buf[size] = '\0';
    return DKERR(DK_STAT_OK);
  }
  case DK_SIGNING_VERIFY:
  case DK_SIGNING_NOVERIFY:
    return DKERR(DK_STAT_INTERNAL);
  }
}


/* HEADER */
/*
 * Free all resources associated with this message.
 * dk is no longer usable.
 */
DK_STAT   dk_free(DK *dk)
{
  if (!dk) return DK_STAT_ARGS;
  if (dk->dkmarker != DKMARK) return DK_STAT_ARGS;
  if (dk->from) free(dk->from);
  if (dk->dksign) free(dk->dksign);
  free(dk->header);		/* alloc'ing dk->header is not optional. */
  dk->dkmarker = ~DKMARK;
  free(dk);
  return DK_STAT_OK;
}

