#include <stdio.h>
#include <string.h>
#include <domainkeys.h>
#include <unistd.h>

int optf = 0;

errorout(DK *dk,DK_STAT st) {
  char *errors[] = {
    "DK_STAT_OK: Function completed successfully",
    "DK_STAT_BADSIG: Signature was available but failed to verify against domain specified key",
    "DK_STAT_NOSIG: No signature available in message",
    "DK_STAT_NOKEY: No public key available (permanent failure)",
    "DK_STAT_BADKEY: Unusable key, public if verifying, private if signing.",
    "DK_STAT_CANTVRFY: Cannot get domain key to verify signature (temporary failure)",
    "DK_STAT_SYNTAX: Message is not valid syntax. Signature could not be created/checked",
    "DK_STAT_NORESOURCE: Could not get critical resource (temporary failure)",
    "DK_STAT_ARGS: Arguments are not usable.",
    "DK_STAT_REVOKED: Key has been revoked.",
    "DK_STAT_INTERNAL: cannot call this routine in this context.  Internal error.",
  };
  char *errorp;

  if (optf && dk) fprintf(stderr, "%s(%d):",dk_errfile(dk),dk_errline(dk));
  if (st >= (sizeof errors) / (sizeof errors[0]))
    fprintf(stderr, "dktest: errorout called with an unknown status %d\n", st);
  else
    fprintf(stderr, "dktest: %s\n", errors[st]);
  exit(1);
}

main(int argc, char *argv[]) {
  char inbuf[1024];
  size_t inlen;
  char advice[2048];
  size_t advicelen = sizeof(advice);
  DK *dk;
  DK_LIB *dklib;
  char *dkptr = strrchr(argv[0], 'k');
  DK_STAT st;
  char ch;
  int opts=0, optv=0, optt=0;
  char *keyfn;
  char *selector;
  char privkey[2048];
  FILE *privkeyf;
  size_t privkeylen;
  DK_FLAGS dkf;

  while (1) {
    ch = getopt(argc, argv,"s:vt:fb:");
    if (ch == -1) break;
    switch (ch) {
    case 'v':
      optv = 1;
      break;
    case 'f':
      optf = 1;
      break;
    case 's':
      opts = 1;
      keyfn = optarg;
      selector = optarg;
      while (*optarg) {
	if (*optarg == '/')
	  selector = optarg+1;
	optarg++;
      }
      break;
    case 't':
      optt = atoi(optarg);
      break;
    case 'b':
      advicelen = atoi(optarg);
      if (advicelen > sizeof(advice)) advicelen = sizeof(advice);
      break;
    }
  }

  if (opts) {
    privkeyf = fopen(keyfn, "r");
    if (!privkeyf) { /*TC10*/
      fprintf(stderr, "dktest: can't open private key file %s\n", keyfn);
      exit(1);
    }
    privkeylen = fread(privkey, 1, sizeof(privkey), privkeyf);
    if (privkeylen == sizeof(privkey)) { /* TC8,TC9 */
      fprintf(stderr, "dktest: private key buffer isn't big enough, use a smaller private key or recompile.\n");
      exit(1);
    }
    privkey[privkeylen] = '\0';
    fclose(privkeyf);
  }

  if (optt == 1) errorout(NULL,0); /*TC2*/
  if (optt == 2) errorout(NULL,32767); /*TC3*/

  dklib = dk_init(&st);
  if (st != DK_STAT_OK) errorout(NULL,st);
  if (!dklib) errorout(NULL, 200);

  if (optv) {
    dk = dk_verify(dklib, &st);
    if (st != DK_STAT_OK) errorout(dk,st);
  } else if (opts) {
    dk = dk_sign(dklib, &st);
    if (st != DK_STAT_OK) errorout(dk,st);
  } else {
    fprintf(stderr, "dktest: [-v|-s selector] [-t#]\n"); /* TC1 */
    exit(1);
  }

  if (optt == 3) errorout(dk,dk_message(NULL, "", 1)); /* TC4 */
  if (optt == 4) errorout(dk,dk_message(dk, NULL, 1)); /* TC5 */
  if (optt == 5) errorout(dk,dk_message(dk, "", 0)); /* TC6 */

  while (1) {
    char *inp;

    inlen = fread(inbuf, 1, sizeof(inbuf), stdin);
    inp = inbuf;
    while (inlen--) {
      if (*inp == '\n') st = dk_message(dk, "\r\n", 2);
      else st = dk_message(dk, inp, 1);
      if (st != DK_STAT_OK) errorout(dk,st);
      inp++;
    }
    if (inp-inbuf < sizeof(inbuf)) break;
  }
  st = dk_eom(dk, &dkf);
  if (optt == 6 && optv) {
    printf("flags: ");
    if (dkf & DK_FLAG_TESTING) printf("t");
    if (dkf & DK_FLAG_SIGNSALL) printf("s");
    printf("\n");
  } else if (optt == 6 && opts) {
    errorout(dk, dk_getsig(dk, NULL, NULL, advicelen)); /* TC14 */
  } else if (optt == 7 && opts) {
    printf("%s\n",dk_from(dk));
  } else if (optt == 8 && opts) {
    dk_getsig(dk, privkey, advice, advicelen);
    if (st != DK_STAT_OK) errorout(dk,st);
    printf("%d %d\n",dk_siglen(privkey), strlen(advice)); /* TC39 */
  } else if (opts) {
    if (st != DK_STAT_OK) errorout(dk,st);
    st = dk_getsig(dk, privkey, advice, advicelen);
    if (st != DK_STAT_OK) errorout(dk,st);
    printf("Comment: DomainKeys? See http://antispam.yahoo.com/domainkeys\n"
	   "DomainKey-Signature: a=rsa-sha1; q=dns; c=simple;\n"
	   "  s=%s; d=%s;\n"
	   "  b=%s;\n", selector, dk_from(dk), advice);
  } else if (optv) {
    char *status;

    switch(st) {
    case DK_STAT_OK: status = "good"; break;
    case DK_STAT_BADSIG: status = "bad"; break;
    case DK_STAT_NOSIG: status = "no signature"; break;
    case DK_STAT_NOKEY:
    case DK_STAT_CANTVRFY: status = "no key"; break;
    case DK_STAT_BADKEY: status = "bad key"; break;
    case DK_STAT_INTERNAL:
    case DK_STAT_ARGS:
    case DK_STAT_SYNTAX: status = "bad format"; break;
    case DK_STAT_NORESOURCE: status = "no resources"; break;
    case DK_STAT_REVOKED: status = "revoked"; break;
    }
    printf("Comment: DomainKeys? See http://antispam.yahoo.com/domainkeys\n"
	   "DomainKey-Status: %s\n", status);
    rewind(stdin);
  }
  if (st != DK_STAT_OK) errorout(dk,st);
}
