#include <stdio.h>

char *dns_txt(char *);

int main(int argc, char *argv[]) {
  char *txtrec, *cp;

  if (argc < 2) exit(1);
  txtrec = dns_txt(argv[1]);
  cp = txtrec;
  printf("%d\n", strlen(cp));
  while (*cp) {
    printf("%02x ", *cp++);
    if ((cp-txtrec) % 16 == 0)  printf("\n");
  }
  printf("\n");
  if (!strcmp(txtrec,"e=perm;"))
    exit(0);
  
  if (!strcmp(txtrec,"e=temp;"))
    exit(0);

  free(txtrec);
}
