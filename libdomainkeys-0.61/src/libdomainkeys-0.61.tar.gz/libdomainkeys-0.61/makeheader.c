#include <stdio.h>
#include <string.h>

int printing = 0;
char line[1024]; /* domainkey.c doesn't have any lines longer than 1024, so enuf. */
int linelen;

#define startswith(a,b) (!strncmp(a,b,strlen(b)))

main()
{

  printf("/* This file is automatically created from the corresponding .c file */\n");
  printf("/* Do not change this file; change the .c file instead. */\n");

  while (fgets(line, sizeof(line), stdin)) {
    if (line[strlen(line)-1] != '\n') {
      fprintf(stderr, "oops, 'line' is too short\n");
      exit(1);
    }
    if (startswith(line, "/* STARTHEAD") || startswith(line, "/* STOPPRIV")) {
      printing = 1;
    } else if (startswith(line, "/* STOPHEAD") || startswith(line, "/* STARTPRIV")) {
      printing = 0;
    } else if (startswith(line, "/* HEADER")) {
      printing = 2;
    } else if (printing == 2 && startswith(line, "{")) {
      printf(";\n");
      printing = 0;
    } else if (printing) {
      fputs(line, stdout);
    }
  }
}
