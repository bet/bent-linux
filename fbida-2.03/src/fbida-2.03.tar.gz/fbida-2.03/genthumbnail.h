int create_thumbnail(char *filename, char *dest, int max);
