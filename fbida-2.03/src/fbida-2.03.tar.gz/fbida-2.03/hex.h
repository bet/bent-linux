void hex_display(char *filename);
