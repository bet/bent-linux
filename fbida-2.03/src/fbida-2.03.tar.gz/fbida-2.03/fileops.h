void job_submit(char *op, char *filename, char *args);
