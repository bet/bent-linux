void parse_ximage(struct ida_image *dest, XImage *src);
